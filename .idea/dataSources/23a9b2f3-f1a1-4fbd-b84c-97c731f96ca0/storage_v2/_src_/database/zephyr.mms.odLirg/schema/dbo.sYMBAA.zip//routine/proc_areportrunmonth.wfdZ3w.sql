--declare @aa1 date =null 
--set @aa1=convert(VARCHAR(10),'2017-04-17',105)
--select avg(Run_9) as a from mms_aReportDay_T3 where R_Date <=@aa1


CREATE procedure [dbo].[proc_aReportRunMonth]
@A_Date date =null
as
delete  from mms_aReportRun_T7 where  ReportDate =@A_Date
declare @run1 decimal(18,4) =0
declare @run2 decimal(18,4) =0
declare @run3 decimal(18,4) =0
declare @run4 decimal(18,4) =0
declare @run5 decimal(18,4) =0
declare @run6 decimal(18,4) =0
declare @run7 decimal(18,4) =0
declare @run8 decimal(18,4) =0
declare @run9 decimal(18,4) =0
---
declare @s1run1 decimal(18,4) =0
declare @s1run2 decimal(18,4) =0
declare @s1run3 decimal(18,4) =0
declare @s1run4 decimal(18,4) =0
declare @s1run5 decimal(18,4) =0
declare @s1run6 decimal(18,4) =0
declare @s1run7 decimal(18,4) =0
declare @s1run8 decimal(18,4) =0
declare @s1run9 decimal(18,4) =0
--
declare @s2run1 decimal(18,4) =0
declare @s2run2 decimal(18,4) =0
declare @s2run3 decimal(18,4) =0
declare @s2run4 decimal(18,4) =0
declare @s2run5 decimal(18,4) =0
declare @s2run6 decimal(18,4) =0
declare @s2run7 decimal(18,4) =0
declare @s2run8 decimal(18,4) =0
declare @s2run9 decimal(18,4) =0

--declare @yk1 decimal(18,4) =0
--select SUM(Run_1) as a from mms_aReportDay_T3 where R_Date <=@aa1
			---------处理日期关系--
declare @StartDateTime datetime
if(day(@A_Date)<=25)
	select @StartDateTime = CONVERT(varchar(10), CONVERT(varchar(8),dateadd(month,-1,@A_Date),23)+'26' , 120)
if(day(@A_Date)>25)
	select @StartDateTime = convert(varchar(8),@A_Date,21)+'26'
-------------------------运行、宏发月累计----------------------------------------------------
select @s1run1=sum(a.Run_1 ),@s1run2=sum(a.Run_2 ),@s1run3=sum(a.Run_3 ),@s1run4=sum(a.Run_4 ),
			@s1run5=sum(a.Run_5 ),@s1run6=sum(a.Run_6 ),@s1run7=sum(a.Run_7 ),@s1run9=AVG(a.Run_9)
	from mms_aReportDay_T3 a inner join
mms_afmPlantRun b on a.R_Date=b.run_date and a.R_CID=b.classid
where b.minewherefrom='宏发矿' and R_Date <=@A_Date and R_Date >=@StartDateTime

select @s2run1=sum(a.Run_1 ),@s2run2=sum(a.Run_2 ),@s2run3=sum(a.Run_3 ),@s2run4=sum(a.Run_4 ),
			@s2run5=sum(a.Run_5 ),@s2run6=sum(a.Run_6 ),@s2run7=sum(a.Run_7 ),@s2run9=AVG(a.Run_9)
	from mms_aReportDay2_T3 a inner join
mms_afmPlantRun2 b on a.R_Date=b.run_date and a.R_CID=b.classid
where b.minewherefrom='宏发矿' and R_Date <=@A_Date and R_Date >=@StartDateTime

set @run1 =@s1run1+ @s2run1
set @run2 =@s1run2+ @s2run2
set @run3 =@s1run3+ @s2run3
set @run4 =@s1run4+ @s2run4
set @run5 =@s1run5+ @s2run5
set @run6 =@s1run6+ @s2run6
set @run7 =@s1run7+ @s2run7
set @run9 =(@s1run9+ @s2run9)/2

if(@run1=0)
	set @run8=0
else
	set @run8= 100*@run2/@run1

insert into mms_aReportRun_T7 values(@A_Date,1,1,@run1),
						(@A_Date,2,1,@run2),
						(@A_Date,3,1,@run3),
						(@A_Date,4,1,@run4),
						(@A_Date,5,1,@run5),
						(@A_Date,6,1,@run6),
						(@A_Date,7,1,@run7),
						(@A_Date,8,1,@run8),
						(@A_Date,9,1,@run9)

-------------------------运行、宏发年累计----------------------------------------------------
set @run1 =0
set @run2 =0
set @run3 =0
set @run4 =0
set @run5 =0
set @run6 =0
set @run7 =0
set @run8 =0
set @run9 =0
---
set @s1run1 =0
set @s1run2 =0
set @s1run3 =0
set @s1run4 =0
set @s1run5 =0
set @s1run6 =0
set @s1run7 =0
set @s1run8 =0
set @s1run9 =0
--
set @s2run1 =0
set @s2run2 =0
set @s2run3 =0
set @s2run4 =0
set @s2run5 =0
set @s2run6 =0
set @s2run7 =0
set @s2run8 =0
set @s2run9 =0
select @s1run1=sum(a.Run_1 ),@s1run2=sum(a.Run_2 ),@s1run3=sum(a.Run_3 ),@s1run4=sum(a.Run_4 ),
			@s1run5=sum(a.Run_5 ),@s1run6=sum(a.Run_6 ),@s1run7=sum(a.Run_7 ),@s1run9=AVG(a.Run_9)
	from mms_aReportDay_T3 a inner join
mms_afmPlantRun b on a.R_Date=b.run_date and a.R_CID=b.classid
where b.minewherefrom='宏发矿' and R_Date <=@A_Date and year(R_Date)=year(@A_Date)

select @s2run1=sum(a.Run_1 ),@s2run2=sum(a.Run_2 ),@s2run3=sum(a.Run_3 ),@s2run4=sum(a.Run_4 ),
			@s2run5=sum(a.Run_5 ),@s2run6=sum(a.Run_6 ),@s2run7=sum(a.Run_7 ),@s2run9=AVG(a.Run_9)
	from mms_aReportDay2_T3 a inner join
mms_afmPlantRun2 b on a.R_Date=b.run_date and a.R_CID=b.classid
where b.minewherefrom='宏发矿' and R_Date <=@A_Date and year(R_Date)=year(@A_Date)

set @run1 =@s1run1+ @s2run1
set @run2 =@s1run2+ @s2run2
set @run3 =@s1run3+ @s2run3
set @run4 =@s1run4+ @s2run4
set @run5 =@s1run5+ @s2run5
set @run6 =@s1run6+ @s2run6
set @run7 =@s1run7+ @s2run7
set @run9 =(@s1run9+ @s2run9)/2

if(@run1=0)
	set @run8=0
else
	set @run8= 100*@run2/@run1	

insert into mms_aReportRun_T7 values(@A_Date,1,2,@run1),
						(@A_Date,2,2,@run2),
						(@A_Date,3,2,@run3),
						(@A_Date,4,2,@run4),
						(@A_Date,5,2,@run5),
						(@A_Date,6,2,@run6),
						(@A_Date,7,2,@run7),
						(@A_Date,8,2,@run8),
						(@A_Date,9,2,@run9)


---------------------------------------------------------------------------------------------------------------------
-------------------------运行、高椅山月累计--------高椅山矿--------------------------------------------
set @run1 =0
set @run2 =0
set @run3 =0
set @run4 =0
set @run5 =0
set @run6 =0
set @run7 =0
set @run8 =0
set @run9 =0
---
set @s1run1 =0
set @s1run2 =0
set @s1run3 =0
set @s1run4 =0
set @s1run5 =0
set @s1run6 =0
set @s1run7 =0
set @s1run8 =0
set @s1run9 =0
--
set @s2run1 =0
set @s2run2 =0
set @s2run3 =0
set @s2run4 =0
set @s2run5 =0
set @s2run6 =0
set @s2run7 =0
set @s2run8 =0
set @s2run9 =0
select @s1run1=sum(a.Run_1 ),@s1run2=sum(a.Run_2 ),@s1run3=sum(a.Run_3 ),@s1run4=sum(a.Run_4 ),
			@s1run5=sum(a.Run_5 ),@s1run6=sum(a.Run_6 ),@s1run7=sum(a.Run_7 ),@s1run9=AVG(a.Run_9)
	from mms_aReportDay_T3 a inner join
mms_afmPlantRun b on a.R_Date=b.run_date and a.R_CID=b.classid
where b.minewherefrom='高椅山矿' and R_Date <=@A_Date and R_Date >=@StartDateTime

select @s2run1=sum(a.Run_1 ),@s2run2=sum(a.Run_2 ),@s2run3=sum(a.Run_3 ),@s2run4=sum(a.Run_4 ),
			@s2run5=sum(a.Run_5 ),@s2run6=sum(a.Run_6 ),@s2run7=sum(a.Run_7 ),@s2run9=AVG(a.Run_9)
	from mms_aReportDay2_T3 a inner join
mms_afmPlantRun2 b on a.R_Date=b.run_date and a.R_CID=b.classid
where b.minewherefrom='高椅山矿' and R_Date <=@A_Date and R_Date >=@StartDateTime

set @run1 =@s1run1+ @s2run1
set @run2 =@s1run2+ @s2run2
set @run3 =@s1run3+ @s2run3
set @run4 =@s1run4+ @s2run4
set @run5 =@s1run5+ @s2run5
set @run6 =@s1run6+ @s2run6
set @run7 =@s1run7+ @s2run7
set @run9 =(@s1run9+ @s2run9)/2

if(@run1=0)
	set @run8=0
else
	set @run8= 100*@run2/@run1
insert into mms_aReportRun_T7 values(@A_Date,1,3,@run1),
						(@A_Date,2,3,@run2),
						(@A_Date,3,3,@run3),
						(@A_Date,4,3,@run4),
						(@A_Date,5,3,@run5),
						(@A_Date,6,3,@run6),
						(@A_Date,7,3,@run7),
						(@A_Date,8,3,@run8),
						(@A_Date,9,3,@run9)

-------------------------运行、高椅山年累计---------高椅山矿-------------------------------------------
set @run1 =0
set @run2 =0
set @run3 =0
set @run4 =0
set @run5 =0
set @run6 =0
set @run7 =0
set @run8 =0
set @run9 =0
---
set @s1run1 =0
set @s1run2 =0
set @s1run3 =0
set @s1run4 =0
set @s1run5 =0
set @s1run6 =0
set @s1run7 =0
set @s1run8 =0
set @s1run9 =0
--
set @s2run1 =0
set @s2run2 =0
set @s2run3 =0
set @s2run4 =0
set @s2run5 =0
set @s2run6 =0
set @s2run7 =0
set @s2run8 =0
set @s2run9 =0
select @s1run1=sum(a.Run_1 ),@s1run2=sum(a.Run_2 ),@s1run3=sum(a.Run_3 ),@s1run4=sum(a.Run_4 ),
			@s1run5=sum(a.Run_5 ),@s1run6=sum(a.Run_6 ),@s1run7=sum(a.Run_7 ),@s1run9=AVG(a.Run_9)
	from mms_aReportDay_T3 a inner join
mms_afmPlantRun b on a.R_Date=b.run_date and a.R_CID=b.classid
where b.minewherefrom='高椅山矿' and R_Date <=@A_Date and year(R_Date)=year(@A_Date)

select @s2run1=sum(a.Run_1 ),@s2run2=sum(a.Run_2 ),@s2run3=sum(a.Run_3 ),@s2run4=sum(a.Run_4 ),
			@s2run5=sum(a.Run_5 ),@s2run6=sum(a.Run_6 ),@s2run7=sum(a.Run_7 ),@s2run9=AVG(a.Run_9)
	from mms_aReportDay2_T3 a inner join
mms_afmPlantRun2 b on a.R_Date=b.run_date and a.R_CID=b.classid
where b.minewherefrom='高椅山矿' and R_Date <=@A_Date and year(R_Date)=year(@A_Date)

set @run1 =@s1run1+ @s2run1
set @run2 =@s1run2+ @s2run2
set @run3 =@s1run3+ @s2run3
set @run4 =@s1run4+ @s2run4
set @run5 =@s1run5+ @s2run5
set @run6 =@s1run6+ @s2run6
set @run7 =@s1run7+ @s2run7
set @run9 =(@s1run9+ @s2run9)/2

if(@run1=0)
	set @run8=0
else
	set @run8= 100*@run2/@run1	
insert into mms_aReportRun_T7 values(@A_Date,1,4,@run1),
						(@A_Date,2,4,@run2),
						(@A_Date,3,4,@run3),
						(@A_Date,4,4,@run4),
						(@A_Date,5,4,@run5),
						(@A_Date,6,4,@run6),
						(@A_Date,7,4,@run7),
						(@A_Date,8,4,@run8),
						(@A_Date,9,4,@run9)



---------------------------------------------------------------------------------------------------------------------
-------------------------运行、易鑫月累计-----------------易鑫矿-----------------------------------
set @run1 =0
set @run2 =0
set @run3 =0
set @run4 =0
set @run5 =0
set @run6 =0
set @run7 =0
set @run8 =0
set @run9 =0
---
set @s1run1 =0
set @s1run2 =0
set @s1run3 =0
set @s1run4 =0
set @s1run5 =0
set @s1run6 =0
set @s1run7 =0
set @s1run8 =0
set @s1run9 =0
--
set @s2run1 =0
set @s2run2 =0
set @s2run3 =0
set @s2run4 =0
set @s2run5 =0
set @s2run6 =0
set @s2run7 =0
set @s2run8 =0
set @s2run9 =0
select @s1run1=sum(a.Run_1 ),@s1run2=sum(a.Run_2 ),@s1run3=sum(a.Run_3 ),@s1run4=sum(a.Run_4 ),
			@s1run5=sum(a.Run_5 ),@s1run6=sum(a.Run_6 ),@s1run7=sum(a.Run_7 ),@s1run9=AVG(a.Run_9)
	from mms_aReportDay_T3 a inner join
mms_afmPlantRun b on a.R_Date=b.run_date and a.R_CID=b.classid
where b.minewherefrom='易鑫矿' and R_Date <=@A_Date and R_Date >=@StartDateTime

select @s2run1=sum(a.Run_1 ),@s2run2=sum(a.Run_2 ),@s2run3=sum(a.Run_3 ),@s2run4=sum(a.Run_4 ),
			@s2run5=sum(a.Run_5 ),@s2run6=sum(a.Run_6 ),@s2run7=sum(a.Run_7 ),@s2run9=AVG(a.Run_9)
	from mms_aReportDay2_T3 a inner join
mms_afmPlantRun2 b on a.R_Date=b.run_date and a.R_CID=b.classid
where b.minewherefrom='易鑫矿' and R_Date <=@A_Date and R_Date >=@StartDateTime

set @run1 =@s1run1+ @s2run1
set @run2 =@s1run2+ @s2run2
set @run3 =@s1run3+ @s2run3
set @run4 =@s1run4+ @s2run4
set @run5 =@s1run5+ @s2run5
set @run6 =@s1run6+ @s2run6
set @run7 =@s1run7+ @s2run7
set @run9 =(@s1run9+ @s2run9)/2

if(@run1=0)
	set @run8=0
else
	set @run8= 100*@run2/@run1
insert into mms_aReportRun_T7 values(@A_Date,1,5,@run1),
						(@A_Date,2,5,@run2),
						(@A_Date,3,5,@run3),
						(@A_Date,4,5,@run4),
						(@A_Date,5,5,@run5),
						(@A_Date,6,5,@run6),
						(@A_Date,7,5,@run7),
						(@A_Date,8,5,@run8),
						(@A_Date,9,5,@run9)

-------------------------运行、易鑫年累计--------------易鑫矿--------------------------------------
set @run1 =0
set @run2 =0
set @run3 =0
set @run4 =0
set @run5 =0
set @run6 =0
set @run7 =0
set @run8 =0
set @run9 =0
---
set @s1run1 =0
set @s1run2 =0
set @s1run3 =0
set @s1run4 =0
set @s1run5 =0
set @s1run6 =0
set @s1run7 =0
set @s1run8 =0
set @s1run9 =0
--
set @s2run1 =0
set @s2run2 =0
set @s2run3 =0
set @s2run4 =0
set @s2run5 =0
set @s2run6 =0
set @s2run7 =0
set @s2run8 =0
set @s2run9 =0
select @s1run1=sum(a.Run_1 ),@s1run2=sum(a.Run_2 ),@s1run3=sum(a.Run_3 ),@s1run4=sum(a.Run_4 ),
			@s1run5=sum(a.Run_5 ),@s1run6=sum(a.Run_6 ),@s1run7=sum(a.Run_7 ),@s1run9=AVG(a.Run_9)
	from mms_aReportDay_T3 a inner join
mms_afmPlantRun b on a.R_Date=b.run_date and a.R_CID=b.classid
where b.minewherefrom='易鑫矿' and R_Date <=@A_Date and year(R_Date)=year(@A_Date)

select @s2run1=sum(a.Run_1 ),@s2run2=sum(a.Run_2 ),@s2run3=sum(a.Run_3 ),@s2run4=sum(a.Run_4 ),
			@s2run5=sum(a.Run_5 ),@s2run6=sum(a.Run_6 ),@s2run7=sum(a.Run_7 ),@s2run9=AVG(a.Run_9)
	from mms_aReportDay2_T3 a inner join
mms_afmPlantRun2 b on a.R_Date=b.run_date and a.R_CID=b.classid
where b.minewherefrom='易鑫矿' and R_Date <=@A_Date and year(R_Date)=year(@A_Date)

set @run1 =@s1run1+ @s2run1
set @run2 =@s1run2+ @s2run2
set @run3 =@s1run3+ @s2run3
set @run4 =@s1run4+ @s2run4
set @run5 =@s1run5+ @s2run5
set @run6 =@s1run6+ @s2run6
set @run7 =@s1run7+ @s2run7
set @run9 =(@s1run9+ @s2run9)/2

if(@run1=0)
	set @run8=0
else
	set @run8= 100*@run2/@run1	
insert into mms_aReportRun_T7 values(@A_Date,1,6,@run1),
						(@A_Date,2,6,@run2),
						(@A_Date,3,6,@run3),
						(@A_Date,4,6,@run4),
						(@A_Date,5,6,@run5),
						(@A_Date,6,6,@run6),
						(@A_Date,7,6,@run7),
						(@A_Date,8,6,@run8),
						(@A_Date,9,6,@run9)

--------------------------------------------------------------------------------------------------------------------
-------------------------运行、月累计----------------------------------------------------
set @run1 =0
set @run2 =0
set @run3 =0
set @run4 =0
set @run5 =0
set @run6 =0
set @run7 =0
set @run8 =0
set @run9 =0
---
set @s1run1 =0
set @s1run2 =0
set @s1run3 =0
set @s1run4 =0
set @s1run5 =0
set @s1run6 =0
set @s1run7 =0
set @s1run8 =0
set @s1run9 =0
--
set @s2run1 =0
set @s2run2 =0
set @s2run3 =0
set @s2run4 =0
set @s2run5 =0
set @s2run6 =0
set @s2run7 =0
set @s2run8 =0
set @s2run9 =0

select @s1run1=sum(a.Run_1 ),@s1run2=sum(a.Run_2 ),@s1run3=sum(a.Run_3 ),@s1run4=sum(a.Run_4 ),
			@s1run5=sum(a.Run_5 ),@s1run6=sum(a.Run_6 ),@s1run7=sum(a.Run_7 ),@s1run9=AVG(a.Run_9)
	from mms_aReportDay_T3 a 
where R_Date <=@A_Date and R_Date >=@StartDateTime

select @s2run1=sum(a.Run_1 ),@s2run2=sum(a.Run_2 ),@s2run3=sum(a.Run_3 ),@s2run4=sum(a.Run_4 ),
			@s2run5=sum(a.Run_5 ),@s2run6=sum(a.Run_6 ),@s2run7=sum(a.Run_7 ),@s2run9=AVG(a.Run_9)
	from mms_aReportDay2_T3 a
where R_Date <=@A_Date and R_Date >=@StartDateTime

set @run1 =@s1run1+ @s2run1
set @run2 =@s1run2+ @s2run2
set @run3 =@s1run3+ @s2run3
set @run4 =@s1run4+ @s2run4
set @run5 =@s1run5+ @s2run5
set @run6 =@s1run6+ @s2run6
set @run7 =@s1run7+ @s2run7
set @run9 =(@s1run9+ @s2run9)/2

if(@run1=0)
	set @run8=0
else
	set @run8= 100*@run2/@run1
	
insert into mms_aReportRun_T7 values(@A_Date,1,7,@run1),
						(@A_Date,2,7,@run2),
						(@A_Date,3,7,@run3),
						(@A_Date,4,7,@run4),
						(@A_Date,5,7,@run5),
						(@A_Date,6,7,@run6),
						(@A_Date,7,7,@run7),
						(@A_Date,8,7,@run8),
						(@A_Date,9,7,@run9)
						
-------------------------运行、年累计----------------------------------------------------

set @run1 =0
set @run2 =0
set @run3 =0
set @run4 =0
set @run5 =0
set @run6 =0
set @run7 =0
set @run8 =0
set @run9 =0
---
set @s1run1 =0
set @s1run2 =0
set @s1run3 =0
set @s1run4 =0
set @s1run5 =0
set @s1run6 =0
set @s1run7 =0
set @s1run8 =0
set @s1run9 =0
--
set @s2run1 =0
set @s2run2 =0
set @s2run3 =0
set @s2run4 =0
set @s2run5 =0
set @s2run6 =0
set @s2run7 =0
set @s2run8 =0
set @s2run9 =0
select @s1run1=sum(a.Run_1 ),@s1run2=sum(a.Run_2 ),@s1run3=sum(a.Run_3 ),@s1run4=sum(a.Run_4 ),
			@s1run5=sum(a.Run_5 ),@s1run6=sum(a.Run_6 ),@s1run7=sum(a.Run_7 ),@s1run9=AVG(a.Run_9)
	from mms_aReportDay_T3 a 
where R_Date <=@A_Date and year(R_Date)=year(@A_Date)

select @s2run1=sum(a.Run_1 ),@s2run2=sum(a.Run_2 ),@s2run3=sum(a.Run_3 ),@s2run4=sum(a.Run_4 ),
			@s2run5=sum(a.Run_5 ),@s2run6=sum(a.Run_6 ),@s2run7=sum(a.Run_7 ),@s2run9=AVG(a.Run_9)
	from mms_aReportDay2_T3 a 
where R_Date <=@A_Date and year(R_Date)=year(@A_Date)

set @run1 =@s1run1+ @s2run1
set @run2 =@s1run2+ @s2run2
set @run3 =@s1run3+ @s2run3
set @run4 =@s1run4+ @s2run4
set @run5 =@s1run5+ @s2run5
set @run6 =@s1run6+ @s2run6
set @run7 =@s1run7+ @s2run7
set @run9 =(@s1run9+ @s2run9)/2

if(@run1=0)
	set @run8=0
else
	set @run8= 100*@run2/@run1	
 
insert into mms_aReportRun_T7 values(@A_Date,1,8,@run1),
						(@A_Date,2,8,@run2),
						(@A_Date,3,8,@run3),
						(@A_Date,4,8,@run4),
						(@A_Date,5,8,@run5),
						(@A_Date,6,8,@run6),
						(@A_Date,7,8,@run7),
						(@A_Date,8,8,@run8),
						(@A_Date,9,8,@run9)
go

