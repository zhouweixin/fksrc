CREATE VIEW dbo._VDosingCalc_MonthSum
AS
SELECT     MedicamentType, SUM(value) AS MonthValue, CONVERT(varchar(7), CONVERT(DATETIME, CONVERT(VARCHAR, cs2date)), 120) AS dMonth
FROM         (SELECT     DosingLocation, MedicamentType, value, maxValue, minValue, cs2date, hh
                       FROM          dbo._VDosingCalc_Step2) AS a
GROUP BY MedicamentType, CONVERT(varchar(7), CONVERT(DATETIME, CONVERT(VARCHAR, cs2date)), 120)
go

