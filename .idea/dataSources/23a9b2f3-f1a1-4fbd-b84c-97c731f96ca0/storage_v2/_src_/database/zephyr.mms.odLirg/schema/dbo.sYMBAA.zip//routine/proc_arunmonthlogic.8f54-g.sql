create procedure proc_aRunMonthLogic

as
declare @aa datetime =null
set @aa =SYSDATETIME()
insert into mms_afmAtestproc values(@aa,13,14,15)
go

