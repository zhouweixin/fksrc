create trigger Trig_T5ForT5Acc_Delete on mms_aReportDay_T5
for delete
as
declare @L_date date =null
select @L_date =R_Date      from deleted    
exec proc_aReportDay_AccStatus @L_date,3,2
go

