create trigger [dbo].[Trig_SheetB2ForT1_3] on dbo.mms_afmLaboratorySheetB2
for delete
as
declare @L_date date =null
declare @C_ID nvarchar(50) =''
select @L_date =ls_Date   ,@C_ID =classid   from deleted   
exec proc_aReportDay2_P1 @L_date,@C_ID,3
go

