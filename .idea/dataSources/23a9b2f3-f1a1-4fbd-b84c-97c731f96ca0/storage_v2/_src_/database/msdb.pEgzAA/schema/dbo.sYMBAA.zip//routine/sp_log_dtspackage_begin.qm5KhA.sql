CREATE PROCEDURE sp_log_dtspackage_begin
  @name        sysname,
  @description    NVARCHAR(1000),
  @id       UNIQUEIDENTIFIER,
  @versionid      UNIQUEIDENTIFIER,
  @lineagefull    UNIQUEIDENTIFIER,
  @lineageshort      INT,
  @starttime      DATETIME,
  @computer    sysname,
  @operator    sysname
AS
  SET NOCOUNT ON

  INSERT sysdtspackagelog (
    name,
    description,
    id,
    versionid,
    lineagefull,
    lineageshort,
    starttime,
    computer,
    operator
  ) VALUES (
    @name,
    @description,
    @id,
    @versionid,
    @lineagefull,
    @lineageshort,
    @starttime,
    @computer,
    @operator
  )
  RETURN 0    -- SUCCESS
go

