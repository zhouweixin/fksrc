CREATE procedure [dbo].[proc_aReportDay_AccAfectAction]
@A_Date date =null
as
-------------读取T4表，和计算-------------------------------------
declare @yk1 decimal(18,4) =0
declare @yk2 decimal(18,4) =0
declare @yk3 decimal(18,4) =0
declare @yk4 decimal(18,4) =0
declare @yk5 decimal(18,4) =0
declare @yk6 decimal(18,4) =0
declare @yk7 decimal(18,4) =0
declare @yk8 decimal(18,4) =0
declare @yk9 decimal(18,4) =0
declare @pbsb1 decimal(18,4) =0
declare @pbsb2 decimal(18,4) =0
declare @pbsb3 decimal(18,4) =0
declare @pbsb4 decimal(18,4) =0
declare @pbsb5 decimal(18,4) =0
declare @pbsb6 decimal(18,4) =0
declare @pbsb7 decimal(18,4) =0
declare @zn1 decimal(18,4) =0
declare @zn2 decimal(18,4) =0
declare @zn3 decimal(18,4) =0
declare @zn4 decimal(18,4) =0

select @yk1=SUM(YK_1),@yk3=SUM(YK_3),@yk5=SUM(YK_5),@yk7=SUM(YK_7),@yk9=SUM(YK_9),
@pbsb1=SUM(PbSb_1),@pbsb3=SUM(PbSb_3),@pbsb6=SUM(PbSb_6),
@zn1=SUM(Zn_1),@zn3=SUM(Zn_3)
  from mms_aReportDay_T4 where R_Date <=@A_Date and MONTH(R_Date)=MONTH(@A_Date)
  if(@yk1 =0)
	begin
		set @yk2=0
		set @yk4=0
		set @yk6=0
		set @yk8=0 
	end
  else
	begin
		set @yk2=100*@yk3/@yk1
		set @yk4=100*@yk5/@yk1
		set @yk6=100*@yk7/@yk1
		set @yk8=100*@yk9/@yk1 
	end
	
	if(@pbsb1=0)
		begin
			set @pbsb2=0
			set @pbsb5=0		
		end
	else
		begin
			set @pbsb2=100*@pbsb3/@pbsb1
			set @pbsb5=100*@pbsb6/@pbsb1	
		end
	
	if(@yk3=0)
		set @pbsb4=0
	else
		set @pbsb4=100*@pbsb3/@yk3
	
	if(@yk7=0)
		set @pbsb7=0
	else
		set @pbsb7=100*@pbsb6/@yk7	

	if(@zn1=0)
		set @zn2=0
	else
		set @zn2=100*@zn3/@zn1
	
	if(@yk5=0)
		set @zn4=0
	else
		set @zn4 =100*@zn3 /@yk5
-------------读取T5表，和计算------------------------------------- 
declare @sn_xn1 decimal(18,4) =0
declare @sn_xn2 decimal(18,4) =0
declare @sn_xn3 decimal(18,4) =0
declare @sn_xn4 decimal(18,4) =0
declare @sn_zx1 decimal(18,4) =0
declare @sn_zx2 decimal(18,4) =0
declare @sn_zx3 decimal(18,4) =0
declare @sn_zx4 decimal(18,4) =0
declare @yk_sn decimal(18,4) =0
select @sn_xn1 =SUM(Sn_XN_1),@sn_xn3 =SUM(Sn_XN_3),@sn_zx1 =SUM(Sn_ZX_1),@sn_zx3 =SUM(Sn_ZX_3)
	 from mms_aReportDay_T5 where R_Date <=@A_Date	and MONTH(R_Date)=MONTH(@A_Date)			

if(@sn_xn1=0)
	set @sn_xn2=0
else
	set @sn_xn2 =100*@sn_xn3/@sn_xn1
	
if(@sn_zx1=0)
	set @sn_zx2=0
else
	set @sn_zx2 =100*@sn_zx3/@sn_zx1
	
if(@yk9 =0)
	begin
		set @sn_xn4=0
		set @sn_zx4=0
	end
else
	begin
		set @sn_xn4 =100*@sn_xn3/@yk9	
		set @sn_zx4 =100*@sn_zx3/@yk9
	end
-------------读取T6表，和计算------------------------------------- 	
declare @run1 decimal(18,4) =0
declare @run2 decimal(18,4) =0
declare @run3 decimal(18,4) =0
declare @run4 decimal(18,4) =0
declare @run5 decimal(18,4) =0
declare @run6 decimal(18,4) =0
declare @run7 decimal(18,4) =0
declare @run8 decimal(18,4) =0
declare @run9 decimal(18,4) =0
select @run1=sum(Run_1 ),@run2=sum(Run_2 ),@run3=sum(Run_3 ),@run4=sum(Run_4 ),
			@run5=sum(Run_5 ),@run6=sum(Run_6 ),@run7=sum(Run_7 )
 from mms_aReportDay_T6 where R_Date <=@A_Date and MONTH(R_Date)=MONTH(@A_Date)
 
 if(@run1=0)
	set @run8=0
 else 
	set @run8= 100*@run2/@run1
	
 if(@run2=0)
	set @run9=0
 else
	set @run9= @run1*@yk1/@run2
 
------------------------------T4_Acc、T7更新----------------------------------------	
	update mms_aReportDay_T4_Acc
		  set YK_1 =@yk1 ,
			YK_2 =@yk2 ,
			YK_3 =@yk3 ,
			YK_4 =@yk4 ,
			YK_5 =@yk5 ,
			YK_6 =@yk6 ,
			YK_7 =@yk7 ,
			YK_8 =@yk8 ,
			YK_9 =@yk9 ,
			PbSb_1 =@pbsb1 ,
			PbSb_2 =@pbsb2 ,
			PbSb_3 =@pbsb3 ,
			PbSb_4 =@pbsb4 ,
			PbSb_5 =@pbsb5 ,
			PbSb_6 =@pbsb6 ,
			PbSb_7 =@pbsb7 ,
			Zn_1 =@zn1 ,
			Zn_2 =@zn2 ,
			Zn_3 =@zn3 ,
			Zn_4 =@zn4 
		where R_Date =@A_Date
		
		update mms_aReportDay_T7 
			set ReportValue =@yk1
		where ReportDate =@A_Date and R_Rows =1 and R_Cols =5
		update mms_aReportDay_T7 
			set ReportValue =@yk2
		where ReportDate =@A_Date and R_Rows =2 and R_Cols =5
		update mms_aReportDay_T7 
			set ReportValue =@yk3
		where ReportDate =@A_Date and R_Rows =3 and R_Cols =5
		update mms_aReportDay_T7 
			set ReportValue =@yk4
		where ReportDate =@A_Date and R_Rows =4 and R_Cols =5
		update mms_aReportDay_T7 
			set ReportValue =@yk5
		where ReportDate =@A_Date and R_Rows =5 and R_Cols =5
		update mms_aReportDay_T7 
			set ReportValue =@yk6
		where ReportDate =@A_Date and R_Rows =6 and R_Cols =5
		update mms_aReportDay_T7 
			set ReportValue =@yk7
		where ReportDate =@A_Date and R_Rows =7 and R_Cols =5
		update mms_aReportDay_T7 
			set ReportValue =@yk8
		where ReportDate =@A_Date and R_Rows =8 and R_Cols =5
		update mms_aReportDay_T7 
			set ReportValue =@yk9
		where ReportDate =@A_Date and R_Rows =9 and R_Cols =5
		update mms_aReportDay_T7 
			set ReportValue =@pbsb1 
		where ReportDate =@A_Date and R_Rows =10 and R_Cols =5
		update mms_aReportDay_T7 
			set ReportValue =@pbsb2
		where ReportDate =@A_Date and R_Rows =11 and R_Cols =5
		update mms_aReportDay_T7 
			set ReportValue =@pbsb3
		where ReportDate =@A_Date and R_Rows =12 and R_Cols =5
		update mms_aReportDay_T7 
			set ReportValue =@pbsb4
		where ReportDate =@A_Date and R_Rows =13 and R_Cols =5
		update mms_aReportDay_T7 
			set ReportValue =@pbsb5
		where ReportDate =@A_Date and R_Rows =14 and R_Cols =5
		update mms_aReportDay_T7 
			set ReportValue =@pbsb6
		where ReportDate =@A_Date and R_Rows =15 and R_Cols =5
		update mms_aReportDay_T7 
			set ReportValue =@pbsb7
		where ReportDate =@A_Date and R_Rows =16 and R_Cols =5
		update mms_aReportDay_T7 
			set ReportValue =@zn1 
		where ReportDate =@A_Date and R_Rows =17 and R_Cols =5
		update mms_aReportDay_T7 
			set ReportValue =@zn2 
		where ReportDate =@A_Date and R_Rows =18 and R_Cols =5
		update mms_aReportDay_T7 
			set ReportValue =@zn3 
		where ReportDate =@A_Date and R_Rows =19 and R_Cols =5
		update mms_aReportDay_T7 
			set ReportValue =@zn4 
		where ReportDate =@A_Date and R_Rows =20 and R_Cols =5
------------------------------T5_Acc、T7更新----------------------------------------
		update mms_aReportDay_T5_Acc 
			set Sn_XN_1=@sn_xn1,
			Sn_XN_2=@sn_xn2,
			Sn_XN_3=@sn_xn3,
			Sn_XN_4=@sn_xn4,
			Sn_ZX_1=@sn_zx1,
			Sn_ZX_2=@sn_zx2,
			Sn_ZX_3=@sn_zx3,
			Sn_ZX_4=@sn_zx4
		where R_Date =@A_Date 
		update mms_aReportDay_T7
			set ReportValue =@sn_xn1
		where ReportDate =@A_Date and R_Rows =21 and R_Cols =5
		update mms_aReportDay_T7
			set ReportValue =@sn_xn2
		where ReportDate =@A_Date and R_Rows =22 and R_Cols =5
		update mms_aReportDay_T7
			set ReportValue =@sn_xn3
		where ReportDate =@A_Date and R_Rows =23 and R_Cols =5
		update mms_aReportDay_T7
			set ReportValue =@sn_xn4
		where ReportDate =@A_Date and R_Rows =24 and R_Cols =5
		update mms_aReportDay_T7
			set ReportValue =@sn_zx1
		where ReportDate =@A_Date and R_Rows =25 and R_Cols =5
		update mms_aReportDay_T7
			set ReportValue =@sn_zx2
		where ReportDate =@A_Date and R_Rows =26 and R_Cols =5
		update mms_aReportDay_T7
			set ReportValue =@sn_zx3
		where ReportDate =@A_Date and R_Rows =27 and R_Cols =5
		update mms_aReportDay_T7
			set ReportValue =@sn_zx4
		where ReportDate =@A_Date and R_Rows =28 and R_Cols =5		
------------------------------T6_Acc、T7更新----------------------------------------	
		update mms_aReportDay_T6_Acc 
			set Run_1 =@run1,
			Run_2=@run2,
			Run_3=@run3,
			Run_4=@run4,
			Run_5=@run5,
			Run_6=@run6,
			Run_7=@run7,
			Run_8=@run8,
			Run_9=@run9
		where R_Date =@A_Date
		 
		update mms_aReportDay_T7
			set ReportValue =@run1
		where ReportDate =@A_Date and R_Rows =29 and R_Cols =5
		update mms_aReportDay_T7
			set ReportValue =@run2
		where ReportDate =@A_Date and R_Rows =30 and R_Cols =5	
		update mms_aReportDay_T7
			set ReportValue =@run3
		where ReportDate =@A_Date and R_Rows =31 and R_Cols =5	
		update mms_aReportDay_T7
			set ReportValue =@run4
		where ReportDate =@A_Date and R_Rows =32 and R_Cols =5	
		update mms_aReportDay_T7
			set ReportValue =@run5
		where ReportDate =@A_Date and R_Rows =33 and R_Cols =5	
		update mms_aReportDay_T7
			set ReportValue =@run6
		where ReportDate =@A_Date and R_Rows =34 and R_Cols =5	
		update mms_aReportDay_T7
			set ReportValue =@run7
		where ReportDate =@A_Date and R_Rows =35 and R_Cols =5	
		update mms_aReportDay_T7
			set ReportValue =@run8
		where ReportDate =@A_Date and R_Rows =36 and R_Cols =5	
		update mms_aReportDay_T7
			set ReportValue =@run9
		where ReportDate =@A_Date and R_Rows =37 and R_Cols =5

go

