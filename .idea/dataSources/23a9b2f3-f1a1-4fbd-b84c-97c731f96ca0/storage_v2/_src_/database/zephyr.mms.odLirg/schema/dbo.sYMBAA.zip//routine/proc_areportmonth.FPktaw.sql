create PROCEDURE proc_aReportMonth
@M_Date date =null
as

declare @t_count int =0
set @t_count =1
while @t_count <=16
	begin
		--print @t_count
		exec proc_aReportMonth_S2 @M_Date,@t_count
		set @t_count =@t_count+1	
	end
go

