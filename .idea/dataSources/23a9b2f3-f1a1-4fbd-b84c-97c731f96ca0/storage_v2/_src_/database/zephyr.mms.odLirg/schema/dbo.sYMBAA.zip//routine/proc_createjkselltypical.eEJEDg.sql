CREATE procedure [dbo].[proc_CreateJKSellTypical]
@A_Date datetime =null
as
declare @c_count int =0
select @c_count=COUNT(*) from mms_aTypicalProductSell where MonthChar=convert(varchar(7),@A_Date,120)
if(@c_count=0)
begin
	insert into mms_aTypicalProductSell values(convert(varchar(7),@A_Date,120),'0101','铅锑精矿','销售量','吨',0,0,0,0,0),                  
		(convert(varchar(7),@A_Date,120),'0102','铅锑精矿','干重','吨',0,0,0,0,0),                   
		(convert(varchar(7),@A_Date,120),'0103','铅锑精矿','铅品位','%',0,0,0,0,0),                  
		(convert(varchar(7),@A_Date,120),'0104','铅锑精矿','锑品位','%',0,0,0,0,0),                  
		(convert(varchar(7),@A_Date,120),'0105','铅锑精矿','精矿含银','千克/吨',0,0,0,0,0),           
		(convert(varchar(7),@A_Date,120),'0106','铅锑精矿','铅含量','吨',0,0,0,0,0),                  
		(convert(varchar(7),@A_Date,120),'0107','铅锑精矿','锑含量','吨',0,0,0,0,0),                  
		(convert(varchar(7),@A_Date,120),'0108','铅锑精矿','含银','公斤',0,0,0,0,0),                  
		(convert(varchar(7),@A_Date,120),'0201','锌精矿','销售量','吨',0,0,0,0,0),                   
		(convert(varchar(7),@A_Date,120),'0202','锌精矿','干重','吨',0,0,0,0,0),                     
		(convert(varchar(7),@A_Date,120),'0203','锌精矿','锌品位','%',0,0,0,0,0),                    
		(convert(varchar(7),@A_Date,120),'0204','锌精矿','锌含量','吨',0,0,0,0,0),                   
		(convert(varchar(7),@A_Date,120),'0301','锡精矿','销售量','吨',0,0,0,0,0),                   
		(convert(varchar(7),@A_Date,120),'0302','锡精矿','干重','吨',0,0,0,0,0),                     
		(convert(varchar(7),@A_Date,120),'0303','锡精矿','锡品位','%',0,0,0,0,0),                    
		(convert(varchar(7),@A_Date,120),'0304','锡精矿','锡含量','吨',0,0,0,0,0),                   
		(convert(varchar(7),@A_Date,120),'0401','硫精矿','合计','吨',0,0,0,0,0),                     
		(convert(varchar(7),@A_Date,120),'0402','硫精矿','其中：廖老板','吨',0,0,0,0,0),              
		(convert(varchar(7),@A_Date,120),'0403','硫精矿','周老板','吨',0,0,0,0,0),                   
		(convert(varchar(7),@A_Date,120),'0404','硫精矿','周蓝山','吨',0,0,0,0,0),                   
		(convert(varchar(7),@A_Date,120),'0405','硫精矿','孙老板','吨',0,0,0,0,0),                   
		(convert(varchar(7),@A_Date,120),'0501','销售折合锡精矿','销售折合锡精矿','吨',0,0,0,0,0)     
	end
go

