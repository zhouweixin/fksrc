
CREATE procedure [dbo].[proc_aReportDay_WhereFromAcc_Logic]
@W_date date =null,
@U_Mode int =0  --t1、t2、t3触发调用 值为0 ；AfectLogic 调用值为2
as
declare @temp_t1 int =0
declare @temp_t2 int =0
declare @temp_t3 int =0
set @temp_t1 =(select COUNT(*) from mms_aReportDay_T1 where R_Date =@W_date)
set @temp_t2 =(select COUNT(*) from mms_aReportDay_T2 where R_Date =@W_date)
set @temp_t3 =(select COUNT(*) from mms_aReportDay_T3 where R_Date =@W_date)

if(@temp_t1+@temp_t2+@temp_t3=9)
	begin
		exec proc_aReportDay_WhereFromAcc_Action @W_date,'宏发矿'
		exec proc_aReportDay_WhereFromAcc_Action @W_date,'高椅山矿'	
		exec proc_aReportDay_WhereFromAcc_Action @W_date,'易鑫矿'	
		if(@U_Mode =0)
			exec proc_aReportDay_AccWhereFromAfectLogic @W_date
	end
go

