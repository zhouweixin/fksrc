create function [dbo].[fn_getPlantRun2NewID]()
returns nvarchar(50) as
begin
	declare @aa nvarchar(50) =''
	select top 1 @aa=ID  from mms_afmPlantRun2  order by ID desc
	declare @bb int =0
	set @bb =CONVERT(int,@aa)
	set @bb=@bb+1

	set @aa = right('000000'+convert(varchar(10),@bb),6)
	return @aa   
end
go

