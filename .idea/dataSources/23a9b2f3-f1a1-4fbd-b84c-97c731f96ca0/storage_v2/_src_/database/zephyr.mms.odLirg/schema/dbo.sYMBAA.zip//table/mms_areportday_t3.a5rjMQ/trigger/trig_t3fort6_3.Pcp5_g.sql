create trigger Trig_T3ForT6_3 on dbo.mms_aReportDay_T3
for delete
as
declare @L_date date =null
select @L_date =R_Date  from deleted     
exec proc_aReportDay_P6 @L_date,3
go

