create trigger Trig_status_aReportDay_Insert on status_aReportDay
for insert, update
as 
declare @R_date date =null
select @R_date =R_Date  from inserted 
exec proc_aReportDay_Acc @R_date
go

