create trigger [dbo].[Trig_T62ForT62Acc_update] on [dbo].[mms_aReportDay2_T6]
for update
as
declare @L_date date =null
select @L_date =R_Date  from inserted   
exec proc_aReportDay2_AccStatus @L_date,2,3
--exec proc_aReportRunMonth_Logic @L_date
go

