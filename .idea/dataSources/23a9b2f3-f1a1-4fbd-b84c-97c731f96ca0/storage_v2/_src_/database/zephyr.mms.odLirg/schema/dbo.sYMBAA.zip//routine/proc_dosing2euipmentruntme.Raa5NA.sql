CREATE procedure [dbo].[proc_Dosing2EuipmentRunTme]
@ID int =null,
@ValueID nvarchar(50) ='',
@A_Value decimal(18,2) =0,
@A_datetime datetime =null
as
if(@ValueID >= 609 and @ValueID<=613)
begin
	insert into mms_afmEquipmentRunTime values(@ValueID ,@A_Value ,@A_datetime)
	delete from mms_afmDosing where ID =@ID 
end
go

