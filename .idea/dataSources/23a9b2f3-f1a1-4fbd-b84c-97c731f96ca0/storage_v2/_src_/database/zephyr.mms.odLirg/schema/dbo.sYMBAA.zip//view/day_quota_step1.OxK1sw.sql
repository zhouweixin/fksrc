CREATE VIEW dbo.Day_Quota_Step1
AS
SELECT     dbo.Class_Calc_Step1.date AS day_date, SUM(dbo.Class_Calc_Step1.Yk_ZL + 0.000001) AS day_YK_ZL, SUM(dbo.Class_Calc_Step1.c4) AS day_PS_RunTime, SUM(dbo.Class_Calc_Step1.c5) 
                      AS day_QM_RunTime, SUM(dbo.Class_Calc_Step1.c6) AS day_PS_CLL, SUM(dbo.Class_Calc_Step1.c7) AS day_YK_SZL, SUM(dbo.Class_Calc_Step2.YK_Pb_JSL) AS day_YK_Pb_JSL, 
                      SUM(dbo.Class_Calc_Step2.YK_Zn_JSL) AS day_YK_Zn_JSL, SUM(dbo.Class_Calc_Step2.YK_Ag_JSL) AS day_YK_Ag_JSL, SUM(dbo.Class_Calc_Step2.JKZL_Pb + 0.000001) AS day_JKZL_Pb, 
                      SUM(dbo.Class_Calc_Step2.Pb_Pb_JSL) AS day_Pb_Pb_JSL, SUM(dbo.Class_Calc_Step2.Pb_Zn_JSL) AS day_Pb_Zn_JSL, SUM(dbo.Class_Calc_Step2.Pb_Ag_JSL) AS day_Pb_Ag_JSL, 
                      SUM(dbo.Class_Calc_Step2.JKZL_Zn + 0.000001) AS day_JKZL_Zn, SUM(dbo.Class_Calc_Step2.Zn_Pb_JSL) AS day_Zn_Pb_JSL, SUM(dbo.Class_Calc_Step2.Zn_Zn_JSL) AS day_Zn_Zn_JSL, 
                      SUM(dbo.Class_Calc_Step2.Zn_Ag_JSL) AS day_Zn_Ag_JSL, SUM(dbo.Class_Calc_Step2.Wk_ZL + 0.000001) AS day_Wk_ZL, SUM(dbo.Class_Calc_Step2.P75_L) AS day_P75_L, 
                      SUM(dbo.Class_Calc_Step2.P38_L) AS day_P38_L
FROM         dbo.Class_Calc_Step1 INNER JOIN
                      dbo.Class_Calc_Step2 ON dbo.Class_Calc_Step1.date = dbo.Class_Calc_Step2.s2date AND dbo.Class_Calc_Step1.c1 = dbo.Class_Calc_Step2.s2c1 INNER JOIN
                      dbo.Class_Calc_Step3 ON dbo.Class_Calc_Step1.date = dbo.Class_Calc_Step3.s3date AND dbo.Class_Calc_Step1.c1 = dbo.Class_Calc_Step3.s3c1
GROUP BY dbo.Class_Calc_Step1.date
go

