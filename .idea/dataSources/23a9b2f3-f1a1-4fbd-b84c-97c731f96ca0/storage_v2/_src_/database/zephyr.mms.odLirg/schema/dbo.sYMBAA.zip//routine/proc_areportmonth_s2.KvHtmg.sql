CREATE PROCEDURE [dbo].[proc_aReportMonth_S2]
@M_Date date =null,
@M_Cols int =0
as
delete from mms_aReportMonth_T7 where ReportDate =@M_Date and R_Cols=@M_Cols 
declare @yk_1 DECIMAL(18,4) =0
declare @yk_2 DECIMAL(18,4) =0
declare @yk_3 DECIMAL(18,4) =0
declare @yk_4 DECIMAL(18,4) =0
declare @yk_5 DECIMAL(18,4) =0
declare @yk_6 DECIMAL(18,4) =0
declare @yk_7 DECIMAL(18,4) =0
declare @yk_8 DECIMAL(18,4) =0
declare @yk_9 DECIMAL(18,4) =0
declare @pbsb_1 DECIMAL(18,4) =0
declare @pbsb_2 DECIMAL(18,4) =0
declare @pbsb_3 DECIMAL(18,4) =0
declare @pbsb_4 DECIMAL(18,4) =0
declare @pbsb_5 DECIMAL(18,4) =0
declare @pbsb_6 DECIMAL(18,4) =0
declare @pbsb_7 DECIMAL(18,4) =0

declare @sn_XN_1 DECIMAL(18,4) =0
declare @sn_XN_2 DECIMAL(18,4) =0
declare @sn_XN_3 DECIMAL(18,4) =0
declare @sn_XN_4 DECIMAL(18,4) =0
declare @sn_ZX_1 DECIMAL(18,4) =0
declare @sn_ZX_2 DECIMAL(18,4) =0
declare @sn_ZX_3 DECIMAL(18,4) =0
declare @sn_ZX_4 DECIMAL(18,4) =0

declare @sn_HJ_1 DECIMAL(18,4) =0
declare @sn_HJ_2 DECIMAL(18,4) =0
declare @sn_HJ_3 DECIMAL(18,4) =0
declare @sn_HJ_4 DECIMAL(18,4) =0

declare @ZH_Sn DECIMAL(18,4) =0

declare @zn_1 DECIMAL(18,4) =0
declare @zn_2 DECIMAL(18,4) =0
declare @zn_3 DECIMAL(18,4) =0
declare @zn_4 DECIMAL(18,4) =0

---
declare @s1yk_1 DECIMAL(18,4) =0
declare @s1yk_2 DECIMAL(18,4) =0
declare @s1yk_3 DECIMAL(18,4) =0
declare @s1yk_4 DECIMAL(18,4) =0
declare @s1yk_5 DECIMAL(18,4) =0
declare @s1yk_6 DECIMAL(18,4) =0
declare @s1yk_7 DECIMAL(18,4) =0
declare @s1yk_8 DECIMAL(18,4) =0
declare @s1yk_9 DECIMAL(18,4) =0
declare @s1pbsb_1 DECIMAL(18,4) =0
declare @s1pbsb_2 DECIMAL(18,4) =0
declare @s1pbsb_3 DECIMAL(18,4) =0
declare @s1pbsb_4 DECIMAL(18,4) =0
declare @s1pbsb_5 DECIMAL(18,4) =0
declare @s1pbsb_6 DECIMAL(18,4) =0
declare @s1pbsb_7 DECIMAL(18,4) =0

declare @s1sn_XN_1 DECIMAL(18,4) =0
declare @s1sn_XN_2 DECIMAL(18,4) =0
declare @s1sn_XN_3 DECIMAL(18,4) =0
declare @s1sn_XN_4 DECIMAL(18,4) =0
declare @s1sn_ZX_1 DECIMAL(18,4) =0
declare @s1sn_ZX_2 DECIMAL(18,4) =0
declare @s1sn_ZX_3 DECIMAL(18,4) =0
declare @s1sn_ZX_4 DECIMAL(18,4) =0

declare @s1sn_HJ_1 DECIMAL(18,4) =0
declare @s1sn_HJ_2 DECIMAL(18,4) =0
declare @s1sn_HJ_3 DECIMAL(18,4) =0
declare @s1sn_HJ_4 DECIMAL(18,4) =0

declare @s1ZH_Sn DECIMAL(18,4) =0

declare @s1zn_1 DECIMAL(18,4) =0
declare @s1zn_2 DECIMAL(18,4) =0
declare @s1zn_3 DECIMAL(18,4) =0
declare @s1zn_4 DECIMAL(18,4) =0
---
declare @s2yk_1 DECIMAL(18,4) =0
declare @s2yk_2 DECIMAL(18,4) =0
declare @s2yk_3 DECIMAL(18,4) =0
declare @s2yk_4 DECIMAL(18,4) =0
declare @s2yk_5 DECIMAL(18,4) =0
declare @s2yk_6 DECIMAL(18,4) =0
declare @s2yk_7 DECIMAL(18,4) =0
declare @s2yk_8 DECIMAL(18,4) =0
declare @s2yk_9 DECIMAL(18,4) =0
declare @s2pbsb_1 DECIMAL(18,4) =0
declare @s2pbsb_2 DECIMAL(18,4) =0
declare @s2pbsb_3 DECIMAL(18,4) =0
declare @s2pbsb_4 DECIMAL(18,4) =0
declare @s2pbsb_5 DECIMAL(18,4) =0
declare @s2pbsb_6 DECIMAL(18,4) =0
declare @s2pbsb_7 DECIMAL(18,4) =0

declare @s2sn_XN_1 DECIMAL(18,4) =0
declare @s2sn_XN_2 DECIMAL(18,4) =0
declare @s2sn_XN_3 DECIMAL(18,4) =0
declare @s2sn_XN_4 DECIMAL(18,4) =0
declare @s2sn_ZX_1 DECIMAL(18,4) =0
declare @s2sn_ZX_2 DECIMAL(18,4) =0
declare @s2sn_ZX_3 DECIMAL(18,4) =0
declare @s2sn_ZX_4 DECIMAL(18,4) =0

declare @s2sn_HJ_1 DECIMAL(18,4) =0
declare @s2sn_HJ_2 DECIMAL(18,4) =0
declare @s2sn_HJ_3 DECIMAL(18,4) =0
declare @s2sn_HJ_4 DECIMAL(18,4) =0

declare @s2ZH_Sn DECIMAL(18,4) =0

declare @s2zn_1 DECIMAL(18,4) =0
declare @s2zn_2 DECIMAL(18,4) =0
declare @s2zn_3 DECIMAL(18,4) =0
declare @s2zn_4 DECIMAL(18,4) =0
-----------------------------计算23冶-------------------------------------------------------------
--declare @temp int =0
--set @temp =(select COUNT(*) from mms_aReportDay_T1 a inner join
--mms_aReportDay_T2 b on a.R_Date =b.R_Date and a.R_CID =b.R_CID  inner join 
--mms_afmPlantRun d on a.R_Date=d.run_date and a.R_CID=d.classid
--where self23 ='23冶'  and a.R_Date <=@M_Date and MONTH(a.R_Date)=MONTH(a.R_Date) )

--if(@temp >0)
--	begin
		declare @StartDateTime datetime	
		if(day(@M_Date)<=25)
			select @StartDateTime = CONVERT(varchar(10), CONVERT(varchar(8),dateadd(month,-1,@M_Date),23)+'26' , 120)
		if(day(@M_Date)>25)
			select @StartDateTime = convert(varchar(8),@M_Date,21)+'26'
		if(@M_Cols=1)
			begin
				select @s1yk_1=SUM(a.YK_1) , @s1yk_3=SUM(a.YK_3) , @s1yk_5=SUM(a.YK_5) , @s1yk_7=SUM(a.YK_7) , @s1yk_9=SUM(a.YK_9) , 
				@s1pbsb_1 =SUM(a.PbSb_1 ) ,@s1pbsb_3 =SUM(a.PbSb_3 ) ,@s1pbsb_6 =SUM(a.PbSb_6 ) ,
				@s1zn_1 =SUM(a.Zn_1) ,@s1zn_3 =SUM(a.Zn_3) ,
				@s1sn_XN_1=SUM(b.Sn_XN_1) ,@s1sn_XN_3=SUM(b.Sn_XN_3) ,
				@s1sn_ZX_1=SUM(b.Sn_ZX_1) ,@s1sn_ZX_3=SUM(b.Sn_ZX_3) 		
				from mms_aReportDay_T1 a inner join
					mms_aReportDay_T2 b on a.R_Date =b.R_Date and a.R_CID =b.R_CID  inner join 
					mms_afmPlantRun d on a.R_Date=d.run_date and a.R_CID=d.classid
					where d.self23 ='23冶'  and a.R_Date <=@M_Date and a.R_Date >=@StartDateTime
				select @s2yk_1=SUM(a.YK_1) , @s2yk_3=SUM(a.YK_3) , @s2yk_5=SUM(a.YK_5) , @s2yk_7=SUM(a.YK_7) , @s2yk_9=SUM(a.YK_9) , 
				@s2pbsb_1 =SUM(a.PbSb_1 ) ,@s2pbsb_3 =SUM(a.PbSb_3 ) ,@s2pbsb_6 =SUM(a.PbSb_6 ) ,
				@s2zn_1 =SUM(a.Zn_1) ,@s2zn_3 =SUM(a.Zn_3) ,
				@s2sn_XN_1=SUM(b.Sn_XN_1) ,@s2sn_XN_3=SUM(b.Sn_XN_3) ,
				@s2sn_ZX_1=SUM(b.Sn_ZX_1) ,@s2sn_ZX_3=SUM(b.Sn_ZX_3) 		
				from mms_aReportDay2_T1 a inner join
					mms_aReportDay2_T2 b on a.R_Date =b.R_Date and a.R_CID =b.R_CID  inner join 
					mms_afmPlantRun2 d on a.R_Date=d.run_date and a.R_CID=d.classid
					where d.self23 ='23冶'  and a.R_Date <=@M_Date and a.R_Date >=@StartDateTime
			end
		if(@M_Cols=2)
			begin
				select @s1yk_1=SUM(a.YK_1) , @s1yk_3=SUM(a.YK_3) , @s1yk_5=SUM(a.YK_5) , @s1yk_7=SUM(a.YK_7) , @s1yk_9=SUM(a.YK_9) , 
				@s1pbsb_1 =SUM(a.PbSb_1 ) ,@s1pbsb_3 =SUM(a.PbSb_3 ) ,@s1pbsb_6 =SUM(a.PbSb_6 ) ,
				@s1zn_1 =SUM(a.Zn_1) ,@s1zn_3 =SUM(a.Zn_3) ,
				@s1sn_XN_1=SUM(b.Sn_XN_1) ,@s1sn_XN_3=SUM(b.Sn_XN_3) ,
				@s1sn_ZX_1=SUM(b.Sn_ZX_1) ,@s1sn_ZX_3=SUM(b.Sn_ZX_3) 		
				from mms_aReportDay_T1 a inner join
					mms_aReportDay_T2 b on a.R_Date =b.R_Date and a.R_CID =b.R_CID  inner join 
					mms_afmPlantRun d on a.R_Date=d.run_date and a.R_CID=d.classid
					where d.self23 ='23冶'  and a.R_Date <=@M_Date and year(a.R_Date)=year(@M_Date)
				select @s2yk_1=SUM(a.YK_1) , @s2yk_3=SUM(a.YK_3) , @s2yk_5=SUM(a.YK_5) , @s2yk_7=SUM(a.YK_7) , @s2yk_9=SUM(a.YK_9) , 
				@s2pbsb_1 =SUM(a.PbSb_1 ) ,@s2pbsb_3 =SUM(a.PbSb_3 ) ,@s2pbsb_6 =SUM(a.PbSb_6 ) ,
				@s2zn_1 =SUM(a.Zn_1) ,@s2zn_3 =SUM(a.Zn_3) ,
				@s2sn_XN_1=SUM(b.Sn_XN_1) ,@s2sn_XN_3=SUM(b.Sn_XN_3) ,
				@s2sn_ZX_1=SUM(b.Sn_ZX_1) ,@s2sn_ZX_3=SUM(b.Sn_ZX_3) 		
				from mms_aReportDay2_T1 a inner join
					mms_aReportDay2_T2 b on a.R_Date =b.R_Date and a.R_CID =b.R_CID  inner join 
					mms_afmPlantRun2 d on a.R_Date=d.run_date and a.R_CID=d.classid
					where d.self23 ='23冶'  and a.R_Date <=@M_Date and year(a.R_Date)=year(@M_Date)
			end
		if(@M_Cols=3)
			begin
				select @s1yk_1=SUM(a.YK_1) , @s1yk_3=SUM(a.YK_3) , @s1yk_5=SUM(a.YK_5) , @s1yk_7=SUM(a.YK_7) , @s1yk_9=SUM(a.YK_9) , 
				@s1pbsb_1 =SUM(a.PbSb_1 ) ,@s1pbsb_3 =SUM(a.PbSb_3 ) ,@s1pbsb_6 =SUM(a.PbSb_6 ) ,
				@s1zn_1 =SUM(a.Zn_1) ,@s1zn_3 =SUM(a.Zn_3) ,
				@s1sn_XN_1=SUM(b.Sn_XN_1) ,@s1sn_XN_3=SUM(b.Sn_XN_3) ,
				@s1sn_ZX_1=SUM(b.Sn_ZX_1) ,@s1sn_ZX_3=SUM(b.Sn_ZX_3) 	
				from mms_aReportDay_T1 a inner join
					mms_aReportDay_T2 b on a.R_Date =b.R_Date and a.R_CID =b.R_CID  inner join 
					mms_afmPlantRun d on a.R_Date=d.run_date and a.R_CID=d.classid
					where d.self23 ='23冶' and d.minewherefrom='宏发矿'  and a.R_Date <=@M_Date and a.R_Date >=@StartDateTime
				select @s2yk_1=SUM(a.YK_1) , @s2yk_3=SUM(a.YK_3) , @s2yk_5=SUM(a.YK_5) , @s2yk_7=SUM(a.YK_7) , @s2yk_9=SUM(a.YK_9) , 
				@s2pbsb_1 =SUM(a.PbSb_1 ) ,@s2pbsb_3 =SUM(a.PbSb_3 ) ,@s2pbsb_6 =SUM(a.PbSb_6 ) ,
				@s2zn_1 =SUM(a.Zn_1) ,@s2zn_3 =SUM(a.Zn_3) ,
				@s2sn_XN_1=SUM(b.Sn_XN_1) ,@s2sn_XN_3=SUM(b.Sn_XN_3) ,
				@s2sn_ZX_1=SUM(b.Sn_ZX_1) ,@s2sn_ZX_3=SUM(b.Sn_ZX_3)	
				from mms_aReportDay2_T1 a inner join
					mms_aReportDay2_T2 b on a.R_Date =b.R_Date and a.R_CID =b.R_CID  inner join 
					mms_afmPlantRun2 d on a.R_Date=d.run_date and a.R_CID=d.classid
					where d.self23 ='23冶' and d.minewherefrom='宏发矿'  and a.R_Date <=@M_Date and a.R_Date >=@StartDateTime
			end
		if(@M_Cols=4)
			begin
				select @s1yk_1=SUM(a.YK_1) , @s1yk_3=SUM(a.YK_3) , @s1yk_5=SUM(a.YK_5) , @s1yk_7=SUM(a.YK_7) , @s1yk_9=SUM(a.YK_9) , 
				@s1pbsb_1 =SUM(a.PbSb_1 ) ,@s1pbsb_3 =SUM(a.PbSb_3 ) ,@s1pbsb_6 =SUM(a.PbSb_6 ) ,
				@s1zn_1 =SUM(a.Zn_1) ,@s1zn_3 =SUM(a.Zn_3) ,
				@s1sn_XN_1=SUM(b.Sn_XN_1) ,@s1sn_XN_3=SUM(b.Sn_XN_3) ,
				@s1sn_ZX_1=SUM(b.Sn_ZX_1) ,@s1sn_ZX_3=SUM(b.Sn_ZX_3) 			
				from mms_aReportDay_T1 a inner join
					mms_aReportDay_T2 b on a.R_Date =b.R_Date and a.R_CID =b.R_CID  inner join 
					mms_afmPlantRun d on a.R_Date=d.run_date and a.R_CID=d.classid
					where d.self23 ='23冶' and d.minewherefrom='宏发矿'   and a.R_Date <=@M_Date and year(a.R_Date)=year(@M_Date)
				select @s2yk_1=SUM(a.YK_1) , @s2yk_3=SUM(a.YK_3) , @s2yk_5=SUM(a.YK_5) , @s2yk_7=SUM(a.YK_7) , @s2yk_9=SUM(a.YK_9) , 
				@s2pbsb_1 =SUM(a.PbSb_1 ) ,@s2pbsb_3 =SUM(a.PbSb_3 ) ,@s2pbsb_6 =SUM(a.PbSb_6 ) ,
				@s2zn_1 =SUM(a.Zn_1) ,@s2zn_3 =SUM(a.Zn_3) ,
				@s2sn_XN_1=SUM(b.Sn_XN_1) ,@s2sn_XN_3=SUM(b.Sn_XN_3) ,
				@s2sn_ZX_1=SUM(b.Sn_ZX_1) ,@s2sn_ZX_3=SUM(b.Sn_ZX_3)			
				from mms_aReportDay2_T1 a inner join
					mms_aReportDay2_T2 b on a.R_Date =b.R_Date and a.R_CID =b.R_CID  inner join 
					mms_afmPlantRun2 d on a.R_Date=d.run_date and a.R_CID=d.classid
					where d.self23 ='23冶' and d.minewherefrom='宏发矿'   and a.R_Date <=@M_Date and year(a.R_Date)=year(@M_Date)
			end
		if(@M_Cols=5)
			begin
				select @s1yk_1=SUM(a.YK_1) , @s1yk_3=SUM(a.YK_3) , @s1yk_5=SUM(a.YK_5) , @s1yk_7=SUM(a.YK_7) , @s1yk_9=SUM(a.YK_9) , 
				@s1pbsb_1 =SUM(a.PbSb_1 ) ,@s1pbsb_3 =SUM(a.PbSb_3 ) ,@s1pbsb_6 =SUM(a.PbSb_6 ) ,
				@s1zn_1 =SUM(a.Zn_1) ,@s1zn_3 =SUM(a.Zn_3) ,
				@s1sn_XN_1=SUM(b.Sn_XN_1) ,@s1sn_XN_3=SUM(b.Sn_XN_3) ,
				@s1sn_ZX_1=SUM(b.Sn_ZX_1) ,@s1sn_ZX_3=SUM(b.Sn_ZX_3) 		
				from mms_aReportDay_T1 a inner join
					mms_aReportDay_T2 b on a.R_Date =b.R_Date and a.R_CID =b.R_CID  inner join 
					mms_afmPlantRun d on a.R_Date=d.run_date and a.R_CID=d.classid
					where d.self23 ='23冶' and d.minewherefrom='易鑫矿'   and a.R_Date <=@M_Date and a.R_Date >=@StartDateTime
				select @s2yk_1=SUM(a.YK_1) , @s2yk_3=SUM(a.YK_3) , @s2yk_5=SUM(a.YK_5) , @s2yk_7=SUM(a.YK_7) , @s2yk_9=SUM(a.YK_9) , 
				@s2pbsb_1 =SUM(a.PbSb_1 ) ,@s2pbsb_3 =SUM(a.PbSb_3 ) ,@s2pbsb_6 =SUM(a.PbSb_6 ) ,
				@s2zn_1 =SUM(a.Zn_1) ,@s2zn_3 =SUM(a.Zn_3) ,
				@s2sn_XN_1=SUM(b.Sn_XN_1) ,@s2sn_XN_3=SUM(b.Sn_XN_3) ,
				@s2sn_ZX_1=SUM(b.Sn_ZX_1) ,@s2sn_ZX_3=SUM(b.Sn_ZX_3)		
				from mms_aReportDay2_T1 a inner join
					mms_aReportDay2_T2 b on a.R_Date =b.R_Date and a.R_CID =b.R_CID  inner join 
					mms_afmPlantRun2 d on a.R_Date=d.run_date and a.R_CID=d.classid
					where d.self23 ='23冶' and d.minewherefrom='易鑫矿'   and a.R_Date <=@M_Date and a.R_Date >=@StartDateTime					
			end
		if(@M_Cols=6)
			begin
				select @s1yk_1=SUM(a.YK_1) , @s1yk_3=SUM(a.YK_3) , @s1yk_5=SUM(a.YK_5) , @s1yk_7=SUM(a.YK_7) , @s1yk_9=SUM(a.YK_9) , 
				@s1pbsb_1 =SUM(a.PbSb_1 ) ,@s1pbsb_3 =SUM(a.PbSb_3 ) ,@s1pbsb_6 =SUM(a.PbSb_6 ) ,
				@s1zn_1 =SUM(a.Zn_1) ,@s1zn_3 =SUM(a.Zn_3) ,
				@s1sn_XN_1=SUM(b.Sn_XN_1) ,@s1sn_XN_3=SUM(b.Sn_XN_3) ,
				@s1sn_ZX_1=SUM(b.Sn_ZX_1) ,@s1sn_ZX_3=SUM(b.Sn_ZX_3) 		
				from mms_aReportDay_T1 a inner join
					mms_aReportDay_T2 b on a.R_Date =b.R_Date and a.R_CID =b.R_CID  inner join 
					mms_afmPlantRun d on a.R_Date=d.run_date and a.R_CID=d.classid
					where d.self23 ='23冶' and d.minewherefrom='易鑫矿'   and a.R_Date <=@M_Date and year(a.R_Date)=year(@M_Date)
				select @s2yk_1=SUM(a.YK_1) , @s2yk_3=SUM(a.YK_3) , @s2yk_5=SUM(a.YK_5) , @s2yk_7=SUM(a.YK_7) , @s2yk_9=SUM(a.YK_9) , 
				@s2pbsb_1 =SUM(a.PbSb_1 ) ,@s2pbsb_3 =SUM(a.PbSb_3 ) ,@s2pbsb_6 =SUM(a.PbSb_6 ) ,
				@s2zn_1 =SUM(a.Zn_1) ,@s2zn_3 =SUM(a.Zn_3) ,
				@s2sn_XN_1=SUM(b.Sn_XN_1) ,@s2sn_XN_3=SUM(b.Sn_XN_3) ,
				@s2sn_ZX_1=SUM(b.Sn_ZX_1) ,@s2sn_ZX_3=SUM(b.Sn_ZX_3)
				from mms_aReportDay2_T1 a inner join
					mms_aReportDay2_T2 b on a.R_Date =b.R_Date and a.R_CID =b.R_CID  inner join 
					mms_afmPlantRun2 d on a.R_Date=d.run_date and a.R_CID=d.classid
					where d.self23 ='23冶' and d.minewherefrom='易鑫矿'   and a.R_Date <=@M_Date and year(a.R_Date)=year(@M_Date)					
			end
		if(@M_Cols=7)
			begin
				select @s1yk_1=SUM(a.YK_1) , @s1yk_3=SUM(a.YK_3) , @s1yk_5=SUM(a.YK_5) , @s1yk_7=SUM(a.YK_7) , @s1yk_9=SUM(a.YK_9) , 
				@s1pbsb_1 =SUM(a.PbSb_1 ) ,@s1pbsb_3 =SUM(a.PbSb_3 ) ,@s1pbsb_6 =SUM(a.PbSb_6 ) ,
				@s1zn_1 =SUM(a.Zn_1) ,@s1zn_3 =SUM(a.Zn_3) ,
				@s1sn_XN_1=SUM(b.Sn_XN_1) ,@s1sn_XN_3=SUM(b.Sn_XN_3) ,
				@s1sn_ZX_1=SUM(b.Sn_ZX_1) ,@s1sn_ZX_3=SUM(b.Sn_ZX_3) 		
				from mms_aReportDay_T1 a inner join
					mms_aReportDay_T2 b on a.R_Date =b.R_Date and a.R_CID =b.R_CID  inner join 
					mms_afmPlantRun d on a.R_Date=d.run_date and a.R_CID=d.classid
					where d.self23 ='23冶' and d.minewherefrom='高椅山矿'  and a.R_Date <=@M_Date and  a.R_Date >=@StartDateTime
				select @s2yk_1=SUM(a.YK_1) , @s2yk_3=SUM(a.YK_3) , @s2yk_5=SUM(a.YK_5) , @s2yk_7=SUM(a.YK_7) , @s2yk_9=SUM(a.YK_9) , 
				@s2pbsb_1 =SUM(a.PbSb_1 ) ,@s2pbsb_3 =SUM(a.PbSb_3 ) ,@s2pbsb_6 =SUM(a.PbSb_6 ) ,
				@s2zn_1 =SUM(a.Zn_1) ,@s2zn_3 =SUM(a.Zn_3) ,
				@s2sn_XN_1=SUM(b.Sn_XN_1) ,@s2sn_XN_3=SUM(b.Sn_XN_3) ,
				@s2sn_ZX_1=SUM(b.Sn_ZX_1) ,@s2sn_ZX_3=SUM(b.Sn_ZX_3)
				from mms_aReportDay2_T1 a inner join
					mms_aReportDay2_T2 b on a.R_Date =b.R_Date and a.R_CID =b.R_CID  inner join 
					mms_afmPlantRun2 d on a.R_Date=d.run_date and a.R_CID=d.classid
					where d.self23 ='23冶' and d.minewherefrom='高椅山矿'  and a.R_Date <=@M_Date and  a.R_Date >=@StartDateTime					
			end
		if(@M_Cols=8)
			begin
				select @s1yk_1=SUM(a.YK_1) , @s1yk_3=SUM(a.YK_3) , @s1yk_5=SUM(a.YK_5) , @s1yk_7=SUM(a.YK_7) , @s1yk_9=SUM(a.YK_9) , 
				@s1pbsb_1 =SUM(a.PbSb_1 ) ,@s1pbsb_3 =SUM(a.PbSb_3 ) ,@s1pbsb_6 =SUM(a.PbSb_6 ) ,
				@s1zn_1 =SUM(a.Zn_1) ,@s1zn_3 =SUM(a.Zn_3) ,
				@s1sn_XN_1=SUM(b.Sn_XN_1) ,@s1sn_XN_3=SUM(b.Sn_XN_3) ,
				@s1sn_ZX_1=SUM(b.Sn_ZX_1) ,@s1sn_ZX_3=SUM(b.Sn_ZX_3) 	
				from mms_aReportDay_T1 a inner join
					mms_aReportDay_T2 b on a.R_Date =b.R_Date and a.R_CID =b.R_CID  inner join 
					mms_afmPlantRun d on a.R_Date=d.run_date and a.R_CID=d.classid
					where d.self23 ='23冶' and d.minewherefrom='高椅山矿'   and a.R_Date <=@M_Date and year(a.R_Date)=year(@M_Date)
				select @s2yk_1=SUM(a.YK_1) , @s2yk_3=SUM(a.YK_3) , @s2yk_5=SUM(a.YK_5) , @s2yk_7=SUM(a.YK_7) , @s2yk_9=SUM(a.YK_9) , 
				@s2pbsb_1 =SUM(a.PbSb_1 ) ,@s2pbsb_3 =SUM(a.PbSb_3 ) ,@s2pbsb_6 =SUM(a.PbSb_6 ) ,
				@s2zn_1 =SUM(a.Zn_1) ,@s2zn_3 =SUM(a.Zn_3) ,
				@s2sn_XN_1=SUM(b.Sn_XN_1) ,@s2sn_XN_3=SUM(b.Sn_XN_3) ,
				@s2sn_ZX_1=SUM(b.Sn_ZX_1) ,@s2sn_ZX_3=SUM(b.Sn_ZX_3)
				from mms_aReportDay2_T1 a inner join
					mms_aReportDay2_T2 b on a.R_Date =b.R_Date and a.R_CID =b.R_CID  inner join 
					mms_afmPlantRun2 d on a.R_Date=d.run_date and a.R_CID=d.classid
					where d.self23 ='23冶' and d.minewherefrom='高椅山矿'   and a.R_Date <=@M_Date and year(a.R_Date)=year(@M_Date)					
			end
		if(@M_Cols=9)
			begin
				select  @s1yk_1=SUM(a.YK_1) , @s1yk_3=SUM(a.YK_3) , @s1yk_5=SUM(a.YK_5) , @s1yk_7=SUM(a.YK_7) , @s1yk_9=SUM(a.YK_9) , 
				@s1pbsb_1 =SUM(a.PbSb_1 ) ,@s1pbsb_3 =SUM(a.PbSb_3 ) ,@s1pbsb_6 =SUM(a.PbSb_6 ) ,
				@s1zn_1 =SUM(a.Zn_1) ,@s1zn_3 =SUM(a.Zn_3) ,
				@s1sn_XN_1=SUM(b.Sn_XN_1) ,@s1sn_XN_3=SUM(b.Sn_XN_3) ,
				@s1sn_ZX_1=SUM(b.Sn_ZX_1) ,@s1sn_ZX_3=SUM(b.Sn_ZX_3) 		
				from mms_aReportDay_T1 a inner join
					mms_aReportDay_T2 b on a.R_Date =b.R_Date and a.R_CID =b.R_CID  inner join 
					mms_afmPlantRun d on a.R_Date=d.run_date and a.R_CID=d.classid
					where d.self23 ='自产'  and a.R_Date <=@M_Date and a.R_Date >=@StartDateTime
				select  @s2yk_1=SUM(a.YK_1) , @s2yk_3=SUM(a.YK_3) , @s2yk_5=SUM(a.YK_5) , @s2yk_7=SUM(a.YK_7) , @s2yk_9=SUM(a.YK_9) , 
				@s2pbsb_1 =SUM(a.PbSb_1 ) ,@s2pbsb_3 =SUM(a.PbSb_3 ) ,@s2pbsb_6 =SUM(a.PbSb_6 ) ,
				@s2zn_1 =SUM(a.Zn_1) ,@s2zn_3 =SUM(a.Zn_3) ,
				@s2sn_XN_1=SUM(b.Sn_XN_1) ,@s2sn_XN_3=SUM(b.Sn_XN_3) ,
				@s2sn_ZX_1=SUM(b.Sn_ZX_1) ,@s2sn_ZX_3=SUM(b.Sn_ZX_3)	
				from mms_aReportDay2_T1 a inner join
					mms_aReportDay2_T2 b on a.R_Date =b.R_Date and a.R_CID =b.R_CID  inner join 
					mms_afmPlantRun2 d on a.R_Date=d.run_date and a.R_CID=d.classid
					where d.self23 ='自产'  and a.R_Date <=@M_Date and a.R_Date >=@StartDateTime					
			end
		if(@M_Cols=10)
			begin
				select @s1yk_1=SUM(a.YK_1) , @s1yk_3=SUM(a.YK_3) , @s1yk_5=SUM(a.YK_5) , @s1yk_7=SUM(a.YK_7) , @s1yk_9=SUM(a.YK_9) , 
				@s1pbsb_1 =SUM(a.PbSb_1 ) ,@s1pbsb_3 =SUM(a.PbSb_3 ) ,@s1pbsb_6 =SUM(a.PbSb_6 ) ,
				@s1zn_1 =SUM(a.Zn_1) ,@s1zn_3 =SUM(a.Zn_3) ,
				@s1sn_XN_1=SUM(b.Sn_XN_1) ,@s1sn_XN_3=SUM(b.Sn_XN_3) ,
				@s1sn_ZX_1=SUM(b.Sn_ZX_1) ,@s1sn_ZX_3=SUM(b.Sn_ZX_3) 		
				from mms_aReportDay_T1 a inner join
					mms_aReportDay_T2 b on a.R_Date =b.R_Date and a.R_CID =b.R_CID  inner join 
					mms_afmPlantRun d on a.R_Date=d.run_date and a.R_CID=d.classid
					where d.self23 ='自产'  and a.R_Date <=@M_Date and year(a.R_Date)=year(@M_Date)
				select @s2yk_1=SUM(a.YK_1) , @s2yk_3=SUM(a.YK_3) , @s2yk_5=SUM(a.YK_5) , @s2yk_7=SUM(a.YK_7) , @s2yk_9=SUM(a.YK_9) , 
				@s2pbsb_1 =SUM(a.PbSb_1 ) ,@s2pbsb_3 =SUM(a.PbSb_3 ) ,@s2pbsb_6 =SUM(a.PbSb_6 ) ,
				@s2zn_1 =SUM(a.Zn_1) ,@s2zn_3 =SUM(a.Zn_3) ,
				@s2sn_XN_1=SUM(b.Sn_XN_1) ,@s2sn_XN_3=SUM(b.Sn_XN_3) ,
				@s2sn_ZX_1=SUM(b.Sn_ZX_1) ,@s2sn_ZX_3=SUM(b.Sn_ZX_3)	
				from mms_aReportDay2_T1 a inner join
					mms_aReportDay2_T2 b on a.R_Date =b.R_Date and a.R_CID =b.R_CID  inner join 
					mms_afmPlantRun2 d on a.R_Date=d.run_date and a.R_CID=d.classid
					where d.self23 ='自产'  and a.R_Date <=@M_Date and year(a.R_Date)=year(@M_Date)					
			end
		if(@M_Cols=11)
			begin
				select @s1yk_1=SUM(a.YK_1) , @s1yk_3=SUM(a.YK_3) , @s1yk_5=SUM(a.YK_5) , @s1yk_7=SUM(a.YK_7) , @s1yk_9=SUM(a.YK_9) , 
				@s1pbsb_1 =SUM(a.PbSb_1 ) ,@s1pbsb_3 =SUM(a.PbSb_3 ) ,@s1pbsb_6 =SUM(a.PbSb_6 ) ,
				@s1zn_1 =SUM(a.Zn_1) ,@s1zn_3 =SUM(a.Zn_3) ,
				@s1sn_XN_1=SUM(b.Sn_XN_1) ,@s1sn_XN_3=SUM(b.Sn_XN_3) ,
				@s1sn_ZX_1=SUM(b.Sn_ZX_1) ,@s1sn_ZX_3=SUM(b.Sn_ZX_3) 				
				from mms_aReportDay_T1 a inner join
					mms_aReportDay_T2 b on a.R_Date =b.R_Date and a.R_CID =b.R_CID  inner join 
					mms_afmPlantRun d on a.R_Date=d.run_date and a.R_CID=d.classid
					where d.self23 ='自产' and d.minewherefrom='宏发矿' and a.R_Date <=@M_Date and a.R_Date >=@StartDateTime
				select @s2yk_1=SUM(a.YK_1) , @s2yk_3=SUM(a.YK_3) , @s2yk_5=SUM(a.YK_5) , @s2yk_7=SUM(a.YK_7) , @s2yk_9=SUM(a.YK_9) , 
				@s2pbsb_1 =SUM(a.PbSb_1 ) ,@s2pbsb_3 =SUM(a.PbSb_3 ) ,@s2pbsb_6 =SUM(a.PbSb_6 ) ,
				@s2zn_1 =SUM(a.Zn_1) ,@s2zn_3 =SUM(a.Zn_3) ,
				@s2sn_XN_1=SUM(b.Sn_XN_1) ,@s2sn_XN_3=SUM(b.Sn_XN_3) ,
				@s2sn_ZX_1=SUM(b.Sn_ZX_1) ,@s2sn_ZX_3=SUM(b.Sn_ZX_3)			
				from mms_aReportDay2_T1 a inner join
					mms_aReportDay2_T2 b on a.R_Date =b.R_Date and a.R_CID =b.R_CID  inner join 
					mms_afmPlantRun2 d on a.R_Date=d.run_date and a.R_CID=d.classid
					where d.self23 ='自产' and d.minewherefrom='宏发矿' and a.R_Date <=@M_Date and a.R_Date >=@StartDateTime
			end
		if(@M_Cols=12)
			begin
				select @s1yk_1=SUM(a.YK_1) , @s1yk_3=SUM(a.YK_3) , @s1yk_5=SUM(a.YK_5) , @s1yk_7=SUM(a.YK_7) , @s1yk_9=SUM(a.YK_9) , 
				@s1pbsb_1 =SUM(a.PbSb_1 ) ,@s1pbsb_3 =SUM(a.PbSb_3 ) ,@s1pbsb_6 =SUM(a.PbSb_6 ) ,
				@s1zn_1 =SUM(a.Zn_1) ,@s1zn_3 =SUM(a.Zn_3) ,
				@s1sn_XN_1=SUM(b.Sn_XN_1) ,@s1sn_XN_3=SUM(b.Sn_XN_3) ,
				@s1sn_ZX_1=SUM(b.Sn_ZX_1) ,@s1sn_ZX_3=SUM(b.Sn_ZX_3) 	
				from mms_aReportDay_T1 a inner join
					mms_aReportDay_T2 b on a.R_Date =b.R_Date and a.R_CID =b.R_CID  inner join 
					mms_afmPlantRun d on a.R_Date=d.run_date and a.R_CID=d.classid
					where d.self23 ='自产' and d.minewherefrom='宏发矿'  and a.R_Date <=@M_Date and year(a.R_Date)=year(@M_Date)
				select @s2yk_1=SUM(a.YK_1) , @s2yk_3=SUM(a.YK_3) , @s2yk_5=SUM(a.YK_5) , @s2yk_7=SUM(a.YK_7) , @s2yk_9=SUM(a.YK_9) , 
				@s2pbsb_1 =SUM(a.PbSb_1 ) ,@s2pbsb_3 =SUM(a.PbSb_3 ) ,@s2pbsb_6 =SUM(a.PbSb_6 ) ,
				@s2zn_1 =SUM(a.Zn_1) ,@s2zn_3 =SUM(a.Zn_3) ,
				@s2sn_XN_1=SUM(b.Sn_XN_1) ,@s2sn_XN_3=SUM(b.Sn_XN_3) ,
				@s2sn_ZX_1=SUM(b.Sn_ZX_1) ,@s2sn_ZX_3=SUM(b.Sn_ZX_3)		
				from mms_aReportDay2_T1 a inner join
					mms_aReportDay2_T2 b on a.R_Date =b.R_Date and a.R_CID =b.R_CID  inner join 
					mms_afmPlantRun2 d on a.R_Date=d.run_date and a.R_CID=d.classid
					where d.self23 ='自产' and d.minewherefrom='宏发矿'  and a.R_Date <=@M_Date and year(a.R_Date)=year(@M_Date)					
			end
		if(@M_Cols=13)
			begin
				select  @s1yk_1=SUM(a.YK_1) , @s1yk_3=SUM(a.YK_3) , @s1yk_5=SUM(a.YK_5) , @s1yk_7=SUM(a.YK_7) , @s1yk_9=SUM(a.YK_9) , 
				@s1pbsb_1 =SUM(a.PbSb_1 ) ,@s1pbsb_3 =SUM(a.PbSb_3 ) ,@s1pbsb_6 =SUM(a.PbSb_6 ) ,
				@s1zn_1 =SUM(a.Zn_1) ,@s1zn_3 =SUM(a.Zn_3) ,
				@s1sn_XN_1=SUM(b.Sn_XN_1) ,@s1sn_XN_3=SUM(b.Sn_XN_3) ,
				@s1sn_ZX_1=SUM(b.Sn_ZX_1) ,@s1sn_ZX_3=SUM(b.Sn_ZX_3) 	
				from mms_aReportDay_T1 a inner join
					mms_aReportDay_T2 b on a.R_Date =b.R_Date and a.R_CID =b.R_CID  inner join 
					mms_afmPlantRun d on a.R_Date=d.run_date and a.R_CID=d.classid
					where d.self23 ='自产' and d.minewherefrom='易鑫矿' and a.R_Date <=@M_Date and a.R_Date >=@StartDateTime
				select @s2yk_1=SUM(a.YK_1) , @s2yk_3=SUM(a.YK_3) , @s2yk_5=SUM(a.YK_5) , @s2yk_7=SUM(a.YK_7) , @s2yk_9=SUM(a.YK_9) , 
				@s2pbsb_1 =SUM(a.PbSb_1 ) ,@s2pbsb_3 =SUM(a.PbSb_3 ) ,@s2pbsb_6 =SUM(a.PbSb_6 ) ,
				@s2zn_1 =SUM(a.Zn_1) ,@s2zn_3 =SUM(a.Zn_3) ,
				@s2sn_XN_1=SUM(b.Sn_XN_1) ,@s2sn_XN_3=SUM(b.Sn_XN_3) ,
				@s2sn_ZX_1=SUM(b.Sn_ZX_1) ,@s2sn_ZX_3=SUM(b.Sn_ZX_3)		
				from mms_aReportDay2_T1 a inner join
					mms_aReportDay2_T2 b on a.R_Date =b.R_Date and a.R_CID =b.R_CID  inner join 
					mms_afmPlantRun2 d on a.R_Date=d.run_date and a.R_CID=d.classid
					where d.self23 ='自产' and d.minewherefrom='易鑫矿' and a.R_Date <=@M_Date and a.R_Date >=@StartDateTime					
			end
		if(@M_Cols=14)
			begin
				select  @s1yk_1=SUM(a.YK_1) , @s1yk_3=SUM(a.YK_3) , @s1yk_5=SUM(a.YK_5) , @s1yk_7=SUM(a.YK_7) , @s1yk_9=SUM(a.YK_9) , 
				@s1pbsb_1 =SUM(a.PbSb_1 ) ,@s1pbsb_3 =SUM(a.PbSb_3 ) ,@s1pbsb_6 =SUM(a.PbSb_6 ) ,
				@s1zn_1 =SUM(a.Zn_1) ,@s1zn_3 =SUM(a.Zn_3) ,
				@s1sn_XN_1=SUM(b.Sn_XN_1) ,@s1sn_XN_3=SUM(b.Sn_XN_3) ,
				@s1sn_ZX_1=SUM(b.Sn_ZX_1) ,@s1sn_ZX_3=SUM(b.Sn_ZX_3) 	
				from mms_aReportDay_T1 a inner join
					mms_aReportDay_T2 b on a.R_Date =b.R_Date and a.R_CID =b.R_CID  inner join 
					mms_afmPlantRun d on a.R_Date=d.run_date and a.R_CID=d.classid
					where d.self23 ='自产' and d.minewherefrom='易鑫矿'  and a.R_Date <=@M_Date and year(a.R_Date)=year(@M_Date)
				select @s2yk_1=SUM(a.YK_1) , @s2yk_3=SUM(a.YK_3) , @s2yk_5=SUM(a.YK_5) , @s2yk_7=SUM(a.YK_7) , @s2yk_9=SUM(a.YK_9) , 
				@s2pbsb_1 =SUM(a.PbSb_1 ) ,@s2pbsb_3 =SUM(a.PbSb_3 ) ,@s2pbsb_6 =SUM(a.PbSb_6 ) ,
				@s2zn_1 =SUM(a.Zn_1) ,@s2zn_3 =SUM(a.Zn_3) ,
				@s2sn_XN_1=SUM(b.Sn_XN_1) ,@s2sn_XN_3=SUM(b.Sn_XN_3) ,
				@s2sn_ZX_1=SUM(b.Sn_ZX_1) ,@s2sn_ZX_3=SUM(b.Sn_ZX_3)
				from mms_aReportDay2_T1 a inner join
					mms_aReportDay2_T2 b on a.R_Date =b.R_Date and a.R_CID =b.R_CID  inner join 
					mms_afmPlantRun2 d on a.R_Date=d.run_date and a.R_CID=d.classid
					where d.self23 ='自产' and d.minewherefrom='易鑫矿'  and a.R_Date <=@M_Date and year(a.R_Date)=year(@M_Date)					
			end
		if(@M_Cols=15)
			begin
				select  @s1yk_1=SUM(a.YK_1) , @s1yk_3=SUM(a.YK_3) , @s1yk_5=SUM(a.YK_5) , @s1yk_7=SUM(a.YK_7) , @s1yk_9=SUM(a.YK_9) , 
				@s1pbsb_1 =SUM(a.PbSb_1 ) ,@s1pbsb_3 =SUM(a.PbSb_3 ) ,@s1pbsb_6 =SUM(a.PbSb_6 ) ,
				@s1zn_1 =SUM(a.Zn_1) ,@s1zn_3 =SUM(a.Zn_3) ,
				@s1sn_XN_1=SUM(b.Sn_XN_1) ,@s1sn_XN_3=SUM(b.Sn_XN_3) ,
				@s1sn_ZX_1=SUM(b.Sn_ZX_1) ,@s1sn_ZX_3=SUM(b.Sn_ZX_3) 		
				from mms_aReportDay_T1 a inner join
					mms_aReportDay_T2 b on a.R_Date =b.R_Date and a.R_CID =b.R_CID  inner join 
					mms_afmPlantRun d on a.R_Date=d.run_date and a.R_CID=d.classid
					where  a.R_Date <=@M_Date and a.R_Date >=@StartDateTime
				select @s2yk_1=SUM(a.YK_1) , @s2yk_3=SUM(a.YK_3) , @s2yk_5=SUM(a.YK_5) , @s2yk_7=SUM(a.YK_7) , @s2yk_9=SUM(a.YK_9) , 
				@s2pbsb_1 =SUM(a.PbSb_1 ) ,@s2pbsb_3 =SUM(a.PbSb_3 ) ,@s2pbsb_6 =SUM(a.PbSb_6 ) ,
				@s2zn_1 =SUM(a.Zn_1) ,@s2zn_3 =SUM(a.Zn_3) ,
				@s2sn_XN_1=SUM(b.Sn_XN_1) ,@s2sn_XN_3=SUM(b.Sn_XN_3) ,
				@s2sn_ZX_1=SUM(b.Sn_ZX_1) ,@s2sn_ZX_3=SUM(b.Sn_ZX_3)
				from mms_aReportDay2_T1 a inner join
					mms_aReportDay2_T2 b on a.R_Date =b.R_Date and a.R_CID =b.R_CID  inner join 
					mms_afmPlantRun2 d on a.R_Date=d.run_date and a.R_CID=d.classid
					where  a.R_Date <=@M_Date and a.R_Date >=@StartDateTime					
			end
		if(@M_Cols=16)
			begin
				select  @s1yk_1=SUM(a.YK_1) , @s1yk_3=SUM(a.YK_3) , @s1yk_5=SUM(a.YK_5) , @s1yk_7=SUM(a.YK_7) , @s1yk_9=SUM(a.YK_9) , 
				@s1pbsb_1 =SUM(a.PbSb_1 ) ,@s1pbsb_3 =SUM(a.PbSb_3 ) ,@s1pbsb_6 =SUM(a.PbSb_6 ) ,
				@s1zn_1 =SUM(a.Zn_1) ,@s1zn_3 =SUM(a.Zn_3) ,
				@s1sn_XN_1=SUM(b.Sn_XN_1) ,@s1sn_XN_3=SUM(b.Sn_XN_3) ,
				@s1sn_ZX_1=SUM(b.Sn_ZX_1) ,@s1sn_ZX_3=SUM(b.Sn_ZX_3) 		
				from mms_aReportDay_T1 a inner join
					mms_aReportDay_T2 b on a.R_Date =b.R_Date and a.R_CID =b.R_CID  inner join 
					mms_afmPlantRun d on a.R_Date=d.run_date and a.R_CID=d.classid
					where  a.R_Date <=@M_Date and year(a.R_Date)=year(@M_Date)
				select @s2yk_1=SUM(a.YK_1) , @s2yk_3=SUM(a.YK_3) , @s2yk_5=SUM(a.YK_5) , @s2yk_7=SUM(a.YK_7) , @s2yk_9=SUM(a.YK_9) , 
				@s2pbsb_1 =SUM(a.PbSb_1 ) ,@s2pbsb_3 =SUM(a.PbSb_3 ) ,@s2pbsb_6 =SUM(a.PbSb_6 ) ,
				@s2zn_1 =SUM(a.Zn_1) ,@s2zn_3 =SUM(a.Zn_3) ,
				@s2sn_XN_1=SUM(b.Sn_XN_1) ,@s2sn_XN_3=SUM(b.Sn_XN_3) ,
				@s2sn_ZX_1=SUM(b.Sn_ZX_1) ,@s2sn_ZX_3=SUM(b.Sn_ZX_3)
				from mms_aReportDay2_T1 a inner join
					mms_aReportDay2_T2 b on a.R_Date =b.R_Date and a.R_CID =b.R_CID  inner join 
					mms_afmPlantRun2 d on a.R_Date=d.run_date and a.R_CID=d.classid
					where  a.R_Date <=@M_Date and year(a.R_Date)=year(@M_Date)					
			end
		----------------------------------计算1部分----------------------------------------------------------
		set @yk_1=@s1yk_1+	@s2yk_1
		set @yk_3=@s1yk_3+	@S2yk_3
		set @yk_5=@s1yk_5+	@S2yk_5
		set @yk_7=@s1yk_7+	@S2yk_7
		set @yk_9=@s1yk_9+	@S2yk_9
		set @pbsb_1=@s1pbsb_1+@S2pbsb_1
		set @pbsb_3=@s1pbsb_3+@S2pbsb_3
		set @pbsb_6=@s1pbsb_6+@S2pbsb_6
		set @zn_1=@s1zn_1+	@S2zn_1
		set @zn_3=@s1zn_3+	@S2zn_3
		set @zn_3=@s1zn_3+	@S2zn_3
		set @sn_XN_1=@s1sn_XN_1
		set @sn_XN_3=@s1sn_XN_3
		set @sn_ZX_1=@s1sn_ZX_1
		set @sn_ZX_3=@s1sn_ZX_3
		
		if(@yk_1>0)
			begin
				 set @yk_2=100*@yk_3/@yk_1
				 set @yk_4=100*@yk_5/@yk_1
				 set @yk_6=100*@yk_7/@yk_1
				 set @yk_8=100*@yk_9/@yk_1
			end
		 if(@yk_1=0)
			begin
				 set @yk_2=0
				 set @yk_4=0
				 set @yk_6=0
				 set @yk_8=0
			end
		 if(@pbsb_1=0)
			set	@pbsb_2=0
		 else
			set @pbsb_2 =100*@pbsb_3/@pbsb_1
		 if(@yk_3=0)
			set @pbsb_4=0
		 else 
			set @pbsb_4 =100*@pbsb_3/@yk_3
		 if(@pbsb_1=0)
			set @pbsb_5=0
		 else
			set @pbsb_5 =100*@pbsb_6/@pbsb_1

		 if(@yk_7=0)
			set @pbsb_7=0
		 else
			set @pbsb_7 =100*@pbsb_6/@yk_7
		 
		 if(@zn_1=0)
			set @zn_2=0
		 else
			set @zn_2 =100*@zn_3/@zn_1
		 if(@yk_5=0)
			set @zn_4=0
		 else 
			set @zn_4 =100*@zn_3/@yk_5
		----------------------------------计算2部分----------------------------------------------------------			
		if(@sn_XN_1=0)
			set @sn_XN_2=0
		else
			set @sn_XN_2 =100*@sn_XN_3/@sn_XN_1

		if(@sn_ZX_1=0)
			set @sn_ZX_2=0
		else
			set @sn_ZX_2 =100*@sn_ZX_3/@sn_ZX_1


		if (@yk_9 <3)
			begin
				set @sn_XN_4 =0
				set @sn_ZX_4 =0
			end
		else 
			begin
				set @sn_XN_4 =100*@sn_XN_3/@yk_9
				set @sn_ZX_4 =100*@sn_ZX_3/@yk_9
			end 
		----------------------------------计算3部分----------------------------------------------------------	
		set @sn_HJ_1 =@sn_XN_1 +@sn_ZX_1
		set @sn_HJ_3 =@sn_XN_3 +@sn_ZX_3
		if(@sn_HJ_1=0)
			set @sn_HJ_2=0
		else
			set @sn_HJ_2 =100*@sn_HJ_3/@sn_HJ_1

		if (@yk_9 <3)
			set @sn_HJ_4 =0
		else
			set @sn_HJ_4 =100*@sn_HJ_3/@yk_9
		
		set @ZH_Sn =@sn_HJ_3+(@pbsb_3+@pbsb_6+@zn_3)/8
		
----------------------------------------------------------------------------------------------------------------------
		declare @temp_Cols int =0
		set @temp_Cols =@M_Cols
		insert into mms_aReportMonth_T7 
			values(@M_Date ,1,@temp_Cols,@yk_1),
				(@M_Date ,2,@temp_Cols,@yk_2),
				(@M_Date ,3,@temp_Cols,@yk_3),
				(@M_Date ,4,@temp_Cols,@yk_4),
				(@M_Date ,5,@temp_Cols,@yk_5),
				(@M_Date ,6,@temp_Cols,@yk_6),
				(@M_Date ,7,@temp_Cols,@yk_7),
				(@M_Date ,8,@temp_Cols,@yk_8),
				(@M_Date ,9,@temp_Cols,@yk_9),
				(@M_Date ,10,@temp_Cols,@pbsb_1),
				(@M_Date ,11,@temp_Cols,@pbsb_2),
				(@M_Date ,12,@temp_Cols,@pbsb_3),
				(@M_Date ,13,@temp_Cols,@pbsb_4),
				(@M_Date ,14,@temp_Cols,@pbsb_5),
				(@M_Date ,15,@temp_Cols,@pbsb_6),
				(@M_Date ,16,@temp_Cols,@pbsb_7),
				(@M_Date ,17,@temp_Cols,@sn_XN_1),
				(@M_Date ,18,@temp_Cols,@sn_XN_2),
				(@M_Date ,19,@temp_Cols,@sn_XN_3),
				(@M_Date ,20,@temp_Cols,@sn_XN_4),
				(@M_Date ,21,@temp_Cols,@sn_ZX_1),
				(@M_Date ,22,@temp_Cols,@sn_ZX_2),
				(@M_Date ,23,@temp_Cols,@sn_ZX_3),
				(@M_Date ,24,@temp_Cols,@sn_ZX_4),
				(@M_Date ,25,@temp_Cols,@sn_HJ_1),
				(@M_Date ,26,@temp_Cols,@sn_HJ_2),
				(@M_Date ,27,@temp_Cols,@sn_HJ_3),
				(@M_Date ,28,@temp_Cols,@sn_HJ_4),
				(@M_Date ,29,@temp_Cols,@zn_1),
				(@M_Date ,30,@temp_Cols,@zn_2),
				(@M_Date ,31,@temp_Cols,@zn_3),
				(@M_Date ,32,@temp_Cols,@zn_4),
				(@M_Date ,33,@temp_Cols,@ZH_Sn)
		
	--end
go

