CREATE trigger [dbo].[Trig_RunForT1_3] on [dbo].[mms_afmPlantRun]
for delete
as
declare @L_date date =null
declare @C_ID nvarchar(50) =''
select @L_date =run_date ,@C_ID =classid from deleted     
exec proc_aReportDay_P1 @L_date,@C_ID,3
exec proc_aReportDay_P3 @L_date,@C_ID,3
exec proc_insertDaySumValue @L_date,@C_ID,3,1

exec proc_insertDaySumCombineValue @L_date,@C_ID,3,1
go

