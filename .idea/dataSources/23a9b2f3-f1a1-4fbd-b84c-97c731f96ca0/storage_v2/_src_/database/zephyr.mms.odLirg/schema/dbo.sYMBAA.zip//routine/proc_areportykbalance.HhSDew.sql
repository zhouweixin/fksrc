
CREATE procedure [dbo].[proc_aReportYKBalance]
@A_Date date =null
as

delete from mms_aReportYKBalance_T7 where ReportDate =@A_Date
--------------------------------------------------------------------
declare @BY1 decimal(18,4) =0
declare @BY2 decimal(18,4) =0
declare @BY3 decimal(18,4) =0
declare @BY4 decimal(18,4) =0
declare @in1m decimal(18,4) =0
declare @in2m decimal(18,4) =0
declare @in3m decimal(18,4) =0
declare @in4m decimal(18,4) =0
declare @in1 decimal(18,4) =0
declare @in2 decimal(18,4) =0
declare @in3 decimal(18,4) =0
declare @in4 decimal(18,4) =0
declare @out1m decimal(18,4) =0
declare @out2m decimal(18,4) =0
declare @out3m decimal(18,4) =0
declare @out4m decimal(18,4) =0
declare @out1 decimal(18,4) =0
declare @out2 decimal(18,4) =0
declare @out3 decimal(18,4) =0
declare @out4 decimal(18,4) =0
declare @mEnd1 decimal(18,4) =0
declare @mEnd2 decimal(18,4) =0
declare @mEnd3 decimal(18,4) =0
declare @mEnd4 decimal(18,4) =0
declare @StartDateTime datetime
if(day(@A_Date)<=25)
	select @StartDateTime = CONVERT(varchar(10), CONVERT(varchar(8),dateadd(month,-1,@A_Date),23)+'26' , 120)
if(day(@A_Date)>25)
	select @StartDateTime = convert(varchar(8),@A_Date,21)+'26'
-----------------------------Cols_1-------------------------------------------
select @BY1 =M_23ye ,@BY2 =gys ,@BY2 =yx ,@BY2 =hf 
		from mms_afmBeginningMassYK  where M_Year =YEAR(@A_Date)
insert into mms_aReportYKBalance_T7
		values(@A_Date ,1,1,@BY1 ),
		(@A_Date ,2,1,@BY2 ),
		(@A_Date ,3,1,@BY3 ),
		(@A_Date ,4,1,@BY4 )
-----------------------------Cols_2----------------------------------------------------
select @in1m=SUM(g2w3) 
	from mms_afmYkWeightList 
	where wl_date <=@A_Date and wl_date >=@StartDateTime
select @in2m=SUM(g2w3) 
	from mms_afmYkWeightList 
	where wl_date <=@A_Date and wl_date >=@StartDateTime and wherefrom ='高椅山矿'
select @in3m=SUM(g2w3) 
	from mms_afmYkWeightList 
	where wl_date <=@A_Date and wl_date >=@StartDateTime and wherefrom ='易鑫矿'
select @in4m=SUM(g2w3) 
	from mms_afmYkWeightList 
	where wl_date <=@A_Date and wl_date >=@StartDateTime and wherefrom ='宏发矿'	
insert into mms_aReportYKBalance_T7
		values(@A_Date ,1,2,@in1m ),
		(@A_Date ,2,2,@in2m ),
		(@A_Date ,3,2,@in3m ),
		(@A_Date ,4,2,@in4m )
-----------------------------Cols_3----------------------------------------------------
select @in1=SUM(g2w3) 
	from mms_afmYkWeightList 
	where wl_date <=@A_Date and wl_date >=@StartDateTime
select @in2=SUM(g2w3) 
	from mms_afmYkWeightList 
	where wl_date <=@A_Date and wl_date >=@StartDateTime and wherefrom ='高椅山矿'
select @in3=SUM(g2w3) 
	from mms_afmYkWeightList 
	where wl_date <=@A_Date and wl_date >=@StartDateTime and wherefrom ='易鑫矿'
select @in4=SUM(g2w3) 
	from mms_afmYkWeightList 
	where wl_date <=@A_Date and wl_date >=@StartDateTime and wherefrom ='宏发矿'	
insert into mms_aReportYKBalance_T7
		values(@A_Date ,1,3,@in1 ),
		(@A_Date ,2,3,@in2 ),
		(@A_Date ,3,3,@in3 ),
		(@A_Date ,4,3,@in4 )
-------------------------------------Cols_4-----------------------------------------------------	
select @out1m=SUM(mm.YK_1)from 
	(select a.*,b.self23,b.minewherefrom from mms_aReportDay_T1 a inner join
	mms_afmPlantRun b on a.R_Date =b.run_date and a.R_CID=b.classid 
	union
	select c.*,d.self23,d.minewherefrom from mms_aReportDay2_T1 c inner join
	mms_afmPlantRun2 d on c.R_Date =d.run_date and c.R_CID=d.classid ) mm	
		where mm.self23='23冶' and mm.R_Date <=@A_Date and mm.R_Date >=@StartDateTime
		
select @out2m=SUM(mm.YK_1)from 
	(select a.*,b.self23,b.minewherefrom from mms_aReportDay_T1 a inner join
	mms_afmPlantRun b on a.R_Date =b.run_date and a.R_CID=b.classid 
	union
	select c.*,d.self23,d.minewherefrom from mms_aReportDay2_T1 c inner join
	mms_afmPlantRun2 d on c.R_Date =d.run_date and c.R_CID=d.classid ) mm	
		where mm.self23='23冶' and mm.minewherefrom='高椅山矿' and mm.R_Date <=@A_Date and mm.R_Date >=@StartDateTime

select @out3m=SUM(mm.YK_1)from 
	(select a.*,b.self23,b.minewherefrom from mms_aReportDay_T1 a inner join
	mms_afmPlantRun b on a.R_Date =b.run_date and a.R_CID=b.classid 
	union
	select c.*,d.self23,d.minewherefrom from mms_aReportDay2_T1 c inner join
	mms_afmPlantRun2 d on c.R_Date =d.run_date and c.R_CID=d.classid ) mm	
		where mm.self23='23冶' and mm.minewherefrom='易鑫矿' and mm.R_Date <=@A_Date and mm.R_Date >=@StartDateTime

select @out4m=SUM(mm.YK_1)from 
	(select a.*,b.self23,b.minewherefrom from mms_aReportDay_T1 a inner join
	mms_afmPlantRun b on a.R_Date =b.run_date and a.R_CID=b.classid 
	union
	select c.*,d.self23,d.minewherefrom from mms_aReportDay2_T1 c inner join
	mms_afmPlantRun2 d on c.R_Date =d.run_date and c.R_CID=d.classid ) mm	
		where mm.self23='23冶' and mm.minewherefrom='宏发矿' and mm.R_Date <=@A_Date and mm.R_Date >=@StartDateTime

insert into mms_aReportYKBalance_T7
		values(@A_Date ,1,4,@out1m ),
		(@A_Date ,2,4,@out2m ),
		(@A_Date ,3,4,@out3m ),
		(@A_Date ,4,4,@out4m )
-------------------------------------Cols_5-----------------------------------------------------	
select @out1=SUM(mm.YK_1)from 
	(select a.*,b.self23,b.minewherefrom from mms_aReportDay_T1 a inner join
	mms_afmPlantRun b on a.R_Date =b.run_date and a.R_CID=b.classid 
	union
	select c.*,d.self23,d.minewherefrom from mms_aReportDay2_T1 c inner join
	mms_afmPlantRun2 d on c.R_Date =d.run_date and c.R_CID=d.classid ) mm	
		where mm.self23='23冶' and mm.R_Date <=@A_Date and year(mm.R_Date)=year(@A_Date)
		
select @out2=SUM(mm.YK_1)from 
	(select a.*,b.self23,b.minewherefrom from mms_aReportDay_T1 a inner join
	mms_afmPlantRun b on a.R_Date =b.run_date and a.R_CID=b.classid 
	union
	select c.*,d.self23,d.minewherefrom from mms_aReportDay2_T1 c inner join
	mms_afmPlantRun2 d on c.R_Date =d.run_date and c.R_CID=d.classid ) mm	
		where mm.self23='23冶' and mm.minewherefrom='高椅山矿' and mm.R_Date <=@A_Date and year(mm.R_Date)=year(@A_Date)

select @out3=SUM(mm.YK_1)from 
	(select a.*,b.self23,b.minewherefrom from mms_aReportDay_T1 a inner join
	mms_afmPlantRun b on a.R_Date =b.run_date and a.R_CID=b.classid 
	union
	select c.*,d.self23,d.minewherefrom from mms_aReportDay2_T1 c inner join
	mms_afmPlantRun2 d on c.R_Date =d.run_date and c.R_CID=d.classid ) mm	
		where mm.self23='23冶' and mm.minewherefrom='易鑫矿' and mm.R_Date <=@A_Date and year(mm.R_Date)=year(@A_Date)

select @out4=SUM(mm.YK_1)from 
	(select a.*,b.self23,b.minewherefrom from mms_aReportDay_T1 a inner join
	mms_afmPlantRun b on a.R_Date =b.run_date and a.R_CID=b.classid 
	union
	select c.*,d.self23,d.minewherefrom from mms_aReportDay2_T1 c inner join
	mms_afmPlantRun2 d on c.R_Date =d.run_date and c.R_CID=d.classid ) mm	
		where mm.self23='23冶' and mm.minewherefrom='宏发矿' and mm.R_Date <=@A_Date and year(mm.R_Date)=year(@A_Date)

insert into mms_aReportYKBalance_T7
		values(@A_Date ,1,5,@out1 ),
		(@A_Date ,2,5,@out2 ),
		(@A_Date ,3,5,@out3 ),
		(@A_Date ,4,5,@out4 )
				
-------------------------------------Cols_6-----------------------------------------------------			
	set @mEnd1 =@BY1 +@in1 -@out1 
	set @mEnd2 =@BY2 +@in2 -@out2 
	set @mEnd3 =@BY3 +@in3 -@out3 
	set @mEnd4 =@BY4 +@in4 -@out4 	
	insert into mms_aReportYKBalance_T7
		values(@A_Date ,1,6,@mEnd1 ),
		(@A_Date ,2,6,@mEnd1 ),
		(@A_Date ,3,6,@mEnd1 ),
		(@A_Date ,4,6,@mEnd1 )


go

