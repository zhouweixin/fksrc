CREATE procedure [dbo].[proc_aReportDay_P6]
@D_Date date =null,
@M_Mode int =0 -----------操作模式，1插入、2更新、3删除
as
declare @Capacity DECIMAL(18,4) =0

declare @Run_time DECIMAL(18,4) =0
declare @Stop_time DECIMAL(18,4) =0
declare @CalendarTime DECIMAL(18,4) =0
declare @WaitForWater_time DECIMAL(18,4) =0
declare @WaitForElectricity_time DECIMAL(18,4) =0
declare @WaitForFix_time DECIMAL(18,4) =0
declare @WaitForElse_time DECIMAL(18,4) =0
declare @QM_RunPercent DECIMAL(18,4) =0
declare @RDPC DECIMAL(18,4) =0  --Reduced daily processing capacity 折合日处理量

select @CalendarTime=SUM(run_1),@Run_time=SUM(Run_2), @Stop_time=SUM(Run_3),
	@WaitForWater_time=SUM(Run_4),@WaitForElectricity_time=SUM(Run_5),@WaitForFix_time=SUM(Run_6),
	@WaitForElse_time=SUM(Run_7)	 from mms_aReportDay_T3 where R_Date =@D_Date 
set @QM_RunPercent =100*@Run_time/@CalendarTime

select @Capacity =SUM(Yk_1) from mms_aReportDay_T1 where R_Date =@D_Date 
if(@Run_time =0 or @Capacity=0)
	set @RDPC =0	
else
	set @RDPC =@Capacity/@Run_time*24
	
declare @temp_t6 int =0
set @temp_t6=(select COUNT(*) from mms_aReportDay_T6 where R_Date =@D_Date)
if (@M_Mode =1)
	begin
		if(@temp_t6=0)		
			begin
				insert into mms_aReportDay_T6
					values(@D_Date,@CalendarTime,@Run_time ,@Stop_time ,@WaitForWater_time,@WaitForElectricity_time ,@WaitForFix_time ,
						@WaitForElse_time,@QM_RunPercent ,@RDPC )
				insert into mms_aReportDay_T7 
					values(@D_Date ,29,4,@CalendarTime),
							(@D_Date ,30,4,@Run_time),
							(@D_Date ,31,4,@Stop_time),
							(@D_Date ,32,4,@WaitForWater_time),
							(@D_Date ,33,4,@WaitForElectricity_time),
							(@D_Date ,34,4,@WaitForFix_time),
							(@D_Date ,35,4,@WaitForElse_time),
							(@D_Date ,36,4,@QM_RunPercent),
							(@D_Date ,37,4,@RDPC)
			end
		else
			begin	
				--------------------------T6---------------------------
				update mms_aReportDay_T6
				set Run_1 =@CalendarTime,
					Run_2 =@Run_time,
					Run_3 =@Stop_time,
					Run_4 =@WaitForWater_time,
					Run_5 =@WaitForElectricity_time,
					Run_6 =@WaitForFix_time,
					Run_7 =@WaitForElse_time,
					Run_8 =@QM_RunPercent,
					Run_9 =@RDPC
				where R_Date =@D_Date 
				----------------------------T7-------------------------
				update mms_aReportDay_T7 
					set ReportValue =@CalendarTime
				where ReportDate =@D_Date and R_Rows =29 and R_Cols =4
				update mms_aReportDay_T7 
					set ReportValue =@Run_time
				where ReportDate =@D_Date and R_Rows =30 and R_Cols =4
				update mms_aReportDay_T7 
					set ReportValue =@Stop_time
				where ReportDate =@D_Date and R_Rows =31 and R_Cols =4
				update mms_aReportDay_T7 
					set ReportValue =@WaitForWater_time
				where ReportDate =@D_Date and R_Rows =32 and R_Cols =4
				update mms_aReportDay_T7 
					set ReportValue =@WaitForElectricity_time
				where ReportDate =@D_Date and R_Rows =33 and R_Cols =4
				update mms_aReportDay_T7 
					set ReportValue =@WaitForFix_time
				where ReportDate =@D_Date and R_Rows =34 and R_Cols =4
				update mms_aReportDay_T7 
					set ReportValue =@WaitForElse_time
				where ReportDate =@D_Date and R_Rows =35 and R_Cols =4
				update mms_aReportDay_T7 
					set ReportValue =@QM_RunPercent
				where ReportDate =@D_Date and R_Rows =36 and R_Cols =4
				update mms_aReportDay_T7 
					set ReportValue =@RDPC
				where ReportDate =@D_Date and R_Rows =37 and R_Cols =4
			end

	end
if (@M_Mode =2)
	begin
		update mms_aReportDay_T6
			set Run_1 =@CalendarTime,
				Run_2 =@Run_time,
				Run_3 =@Stop_time,
				Run_4 =@WaitForWater_time,
				Run_5 =@WaitForElectricity_time,
				Run_6 =@WaitForFix_time,
				Run_7 =@WaitForElse_time,
				Run_8 =@QM_RunPercent,
				Run_9 =@RDPC
		where R_Date =@D_Date 
		update mms_aReportDay_T7 
			set ReportValue =@CalendarTime
		where ReportDate =@D_Date and R_Rows =29 and R_Cols =4
		update mms_aReportDay_T7 
			set ReportValue =@Run_time
		where ReportDate =@D_Date and R_Rows =30 and R_Cols =4
		update mms_aReportDay_T7 
			set ReportValue =@Stop_time
		where ReportDate =@D_Date and R_Rows =31 and R_Cols =4
		update mms_aReportDay_T7 
			set ReportValue =@WaitForWater_time
		where ReportDate =@D_Date and R_Rows =32 and R_Cols =4
		update mms_aReportDay_T7 
			set ReportValue =@WaitForElectricity_time
		where ReportDate =@D_Date and R_Rows =33 and R_Cols =4
		update mms_aReportDay_T7 
			set ReportValue =@WaitForFix_time
		where ReportDate =@D_Date and R_Rows =34 and R_Cols =4
		update mms_aReportDay_T7 
			set ReportValue =@WaitForElse_time
		where ReportDate =@D_Date and R_Rows =35 and R_Cols =4
		update mms_aReportDay_T7 
			set ReportValue =@QM_RunPercent
		where ReportDate =@D_Date and R_Rows =36 and R_Cols =4
		update mms_aReportDay_T7 
			set ReportValue =@RDPC
		where ReportDate =@D_Date and R_Rows =37 and R_Cols =4
	end
if (@M_Mode =3)
	begin
		delete from mms_aReportDay_T6 where R_Date =@D_Date 
		delete from mms_aReportDay_T7 where ReportDate =@D_Date and R_Cols =4 and R_Rows between 29 and 37 
	end
go

