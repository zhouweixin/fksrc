CREATE FUNCTION [dbo].[fn_sysdac_get_currentusername]()
RETURNS sysname
BEGIN
    RETURN dbo.fn_sysdac_get_username(SUSER_SID());
END
go

