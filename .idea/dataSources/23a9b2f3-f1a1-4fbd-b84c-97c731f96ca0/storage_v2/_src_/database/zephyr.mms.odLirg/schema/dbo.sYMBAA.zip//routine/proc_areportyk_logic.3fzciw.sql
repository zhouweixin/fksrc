CREATE PROCEDURE  [dbo].[proc_aReportYk_Logic] 
@M_Date date =null,
@M_Mode int =0 
as
	declare @tempDate date =null
	declare @tCount int =0
if(@M_Mode=0)
begin
	set @tCount =(select COUNT(*) from mms_aReportDay_T4 
				where R_Date >=@M_Date and  year(R_Date)=year(@M_Date))
				
	if(@tCount >0)
		begin 
			DECLARE TableCursor CURSOR 
			LOCAL
			FOR					
			select distinct R_Date  
				from mms_aReportDay_T4 
				where R_Date >=@M_Date and  year (R_Date)=year (@M_Date)
			OPEN TableCursor
			FETCH NEXT FROM TableCursor INTO @tempDate
			while @@FETCH_STATUS =0
				begin
					exec proc_aReportYk  @tempDate
					FETCH NEXT FROM TableCursor INTO @tempDate
				end
			CLOSE TableCursor
			DEALLOCATE TableCursor
		end
end	
if(@M_Mode=1)
begin
	set @tCount =(select COUNT(*) from mms_aReportDay2_T4 
				where R_Date >=@M_Date and  year(R_Date)=year(@M_Date))
				
	if(@tCount >0)
		begin 
			DECLARE TableCursor CURSOR 
			LOCAL
			FOR					
			select distinct R_Date  
				from mms_aReportDay2_T4 
				where R_Date >=@M_Date and  year (R_Date)=year (@M_Date)
			OPEN TableCursor
			FETCH NEXT FROM TableCursor INTO @tempDate
			while @@FETCH_STATUS =0
				begin
					exec proc_aReportYk  @tempDate
					FETCH NEXT FROM TableCursor INTO @tempDate
				end
			CLOSE TableCursor
			DEALLOCATE TableCursor
		end
end
go

