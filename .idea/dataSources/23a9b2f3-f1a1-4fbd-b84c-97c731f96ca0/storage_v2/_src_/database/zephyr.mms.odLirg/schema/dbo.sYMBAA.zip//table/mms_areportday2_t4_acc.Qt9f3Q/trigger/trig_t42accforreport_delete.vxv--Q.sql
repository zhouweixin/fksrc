------------------T4_acc表上的三类触发器-------------------------------
create trigger [dbo].[Trig_T42AccForReport_delete] on [dbo].[mms_aReportDay2_T4_Acc]
for delete
as
declare @L_date date =null
select @L_date =R_Date  from deleted   
exec proc_insert2DaySumValue @L_date,'',3,222
go

