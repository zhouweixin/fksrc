CREATE VIEW dbo.Class_Quota_Sum
AS
SELECT     dbo.Class_Calc_Step1.date, dbo.Class_Calc_Step1.c1, dbo.Class_Calc_Step1.c2 AS ClassName, dbo.Class_Calc_Step1.c3 AS YK_SF, dbo.Class_Calc_Step1.c4 AS PS_RunTime, 
                      dbo.Class_Calc_Step1.c5 AS QM_RunTime, dbo.Class_Calc_Step1.c6 AS PS_CLL, dbo.Class_Calc_Step1.c7 AS QM_SKL, dbo.Class_Calc_Step1.c8 AS P75, dbo.Class_Calc_Step1.c9 AS P38, 
                      dbo.Class_Calc_Step1.pw1 AS PW_YK_Pb, dbo.Class_Calc_Step1.pw2 AS PW_YK_Zn, dbo.Class_Calc_Step1.pw3 AS PW_YK_Ag, dbo.Class_Calc_Step1.pw4 AS PW_Pb_Pb, 
                      dbo.Class_Calc_Step1.pw5 AS PW_Pb_Zn, dbo.Class_Calc_Step1.pw6 AS PW_Pb_Ag, dbo.Class_Calc_Step1.pw7 AS PW_PbWk_Pb, dbo.Class_Calc_Step1.pw8 AS PW_PbWk_Zn, 
                      dbo.Class_Calc_Step1.pw9 AS PW_PbWk_Ag, dbo.Class_Calc_Step1.pw10 AS PW_Zn_Pb, dbo.Class_Calc_Step1.pw11 AS PW_Zn_Zn, dbo.Class_Calc_Step1.pw12 AS PW_Zn_Ag, 
                      dbo.Class_Calc_Step1.pw13 AS PW_Wk_Pb, dbo.Class_Calc_Step1.pw14 AS PW_Wk_Zn, dbo.Class_Calc_Step1.pw15 AS PW_Wk_Ag, dbo.Class_Calc_Step1.Yk_ZL, 
                      dbo.Class_Calc_Step2.PStaixiao, dbo.Class_Calc_Step2.QMTaixiao, dbo.Class_Calc_Step2.YK_Zn_JSL, dbo.Class_Calc_Step2.YK_Pb_JSL, dbo.Class_Calc_Step2.YK_Ag_JSL, 
                      dbo.Class_Calc_Step2.JKCL_Pb, dbo.Class_Calc_Step2.JKZL_Pb, dbo.Class_Calc_Step2.Pb_Pb_JSL, dbo.Class_Calc_Step2.Pb_Zn_JSL, dbo.Class_Calc_Step2.Pb_Ag_JSL, 
                      dbo.Class_Calc_Step2.JKCL_Zn, dbo.Class_Calc_Step2.JKZL_Zn, dbo.Class_Calc_Step2.Zn_Pb_JSL, dbo.Class_Calc_Step2.Zn_Zn_JSL, dbo.Class_Calc_Step2.Zn_Ag_JSL, 
                      dbo.Class_Calc_Step2.Wk_ZL, dbo.Class_Calc_Step2.Wk_Pb_JSL, dbo.Class_Calc_Step2.Wk_Zn_JSL, dbo.Class_Calc_Step2.Wk_Ag_JSL, dbo.Class_Calc_Step3.HSL_Pb, 
                      dbo.Class_Calc_Step3.HSL_Zn, dbo.Class_Calc_Step3.HSL_Ag
FROM         dbo.Class_Calc_Step1 INNER JOIN
                      dbo.Class_Calc_Step2 ON dbo.Class_Calc_Step1.date = dbo.Class_Calc_Step2.s2date AND dbo.Class_Calc_Step1.c1 = dbo.Class_Calc_Step2.s2c1 INNER JOIN
                      dbo.Class_Calc_Step3 ON dbo.Class_Calc_Step2.s2date = dbo.Class_Calc_Step3.s3date AND dbo.Class_Calc_Step2.s2c1 = dbo.Class_Calc_Step3.s3c1
go

