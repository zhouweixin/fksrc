CREATE trigger [dbo].[Trig_Run2ForT1_1] on [dbo].[mms_afmPlantRun2]
for insert
as
declare @L_date date =null
declare @C_ID nvarchar(50) =''
select @L_date =run_date ,@C_ID =classid from inserted    
exec proc_aReportDay2_P1 @L_date,@C_ID,1
exec proc_aReportDay2_P3 @L_date,@C_ID,1
exec proc_Create2DaySumTypical @L_date
exec proc_insert2DaySumValue @L_date,@C_ID,1,1

exec proc_CreateDaySumCombineTypical @L_date
exec proc_insertDaySumCombineValue @L_date,@C_ID,1,1
go

