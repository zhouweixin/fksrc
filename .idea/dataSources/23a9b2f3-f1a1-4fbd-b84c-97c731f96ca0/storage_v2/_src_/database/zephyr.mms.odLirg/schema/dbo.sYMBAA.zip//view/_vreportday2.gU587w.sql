CREATE VIEW dbo._VReportDay2
AS
SELECT     TOP (100) PERCENT tt1.C_Name AS QuotaName1, tt2.C_Name AS QuotaName2, tt3.C_Name AS Unit, a.ReportValue AS MoringClass, b.ReportValue AS MiddleClass, 
                      c.ReportValue AS NightClass, d.ReportValue AS SummryDay, e.ReportValue AS SummryMonth, f.ReportValue AS hf, g.ReportValue AS gys, h.ReportValue AS yx, 
                      a.ReportDate AS MonthDate, a.R_Rows AS OrderCode
FROM         (SELECT     R_Rows, ReportValue, ReportDate
                       FROM          dbo.mms_aReportDay2_T7
                       WHERE      (R_Cols = 1)) AS a INNER JOIN
                          (SELECT     R_Rows, C_Name
                            FROM          dbo.mms_aReportDay2_TT
                            WHERE      (R_Cols = 1)) AS tt1 ON a.R_Rows = tt1.R_Rows INNER JOIN
                          (SELECT     R_Rows, C_Name
                            FROM          dbo.mms_aReportDay2_TT AS mms_aReportDay2_TT_2
                            WHERE      (R_Cols = 2)) AS tt2 ON a.R_Rows = tt2.R_Rows INNER JOIN
                          (SELECT     R_Rows, C_Name
                            FROM          dbo.mms_aReportDay2_TT AS mms_aReportDay2_TT_1
                            WHERE      (R_Cols = 3)) AS tt3 ON a.R_Rows = tt3.R_Rows INNER JOIN
                          (SELECT     R_Rows, ReportValue, ReportDate
                            FROM          dbo.mms_aReportDay2_T7 AS mms_aReportDay2_T7_7
                            WHERE      (R_Cols = 2)) AS b ON a.R_Rows = b.R_Rows AND a.ReportDate = b.ReportDate INNER JOIN
                          (SELECT     R_Rows, ReportValue, ReportDate
                            FROM          dbo.mms_aReportDay2_T7 AS mms_aReportDay2_T7_6
                            WHERE      (R_Cols = 3)) AS c ON a.R_Rows = c.R_Rows AND a.ReportDate = c.ReportDate INNER JOIN
                          (SELECT     R_Rows, ReportValue, ReportDate
                            FROM          dbo.mms_aReportDay2_T7 AS mms_aReportDay2_T7_5
                            WHERE      (R_Cols = 4)) AS d ON a.R_Rows = d.R_Rows AND a.ReportDate = d.ReportDate INNER JOIN
                          (SELECT     R_Rows, ReportValue, ReportDate
                            FROM          dbo.mms_aReportDay2_T7 AS mms_aReportDay2_T7_4
                            WHERE      (R_Cols = 5)) AS e ON a.R_Rows = e.R_Rows AND a.ReportDate = e.ReportDate INNER JOIN
                          (SELECT     R_Rows, ReportValue, ReportDate
                            FROM          dbo.mms_aReportDay2_T7 AS mms_aReportDay2_T7_3
                            WHERE      (R_Cols = 6)) AS f ON a.R_Rows = f.R_Rows AND a.ReportDate = f.ReportDate INNER JOIN
                          (SELECT     R_Rows, ReportValue, ReportDate
                            FROM          dbo.mms_aReportDay2_T7 AS mms_aReportDay2_T7_2
                            WHERE      (R_Cols = 7)) AS g ON a.R_Rows = g.R_Rows AND a.ReportDate = g.ReportDate INNER JOIN
                          (SELECT     R_Rows, ReportValue, ReportDate
                            FROM          dbo.mms_aReportDay2_T7 AS mms_aReportDay2_T7_1
                            WHERE      (R_Cols = 8)) AS h ON a.R_Rows = h.R_Rows AND a.ReportDate = h.ReportDate
ORDER BY OrderCode
go

