create function dbo.fn_getYearMonth(@indate Date) 
returns varchar(7)
as
begin
	declare @tempym varchar(7)
	set @tempym = CONVERT(varchar, CONVERT(DATETIME, CONVERT(VARCHAR, @indate)), 120)
	return @tempym
end
go

