CREATE trigger [dbo].[Trig_WeightSnForT2_2] on [dbo].[mms_afmWeightSn]
for update
as
declare @L_date date =null
select @L_date =snw_date   from inserted    
exec proc_aReportDay_P2 @L_date,2
exec proc_aReportDay2_P2 @L_date,2
exec proc_insertDaySumValueSn @L_date,'',2,2
exec proc_insertDaySumCombineValueSn @L_date,'',2,2
go

