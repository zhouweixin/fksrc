create function fn_getMin(@a1 int,@a2 int ,@a3 int)
returns  int
as
begin
	declare @tp int =0
	declare @abc table(
		t_quota int null
	)
	insert into @abc values(@a1),(@a2),(@a3)
	select @tp=MIN(t_quota) from @abc
	return @tp 
end
go

