CREATE VIEW dbo._VDosingCalc_Class
AS
SELECT     e.MedicamentType, e.moring, e.middle, f.accvalue AS night, e.cs2date AS date
FROM         (SELECT     c.MedicamentType, c.accvalue AS moring, d.accvalue AS middle, d.cs2date
                       FROM          (SELECT     MedicamentType, accvalue, cs2date
                                               FROM          (SELECT     MedicamentType, SUM(value) AS accvalue, cs2date, hh
                                                                       FROM          (SELECT     DosingLocation, MedicamentType, value, maxValue, minValue, cs2date, hh
                                                                                               FROM          dbo._VDosingCalc_Step2) AS a
                                                                       GROUP BY MedicamentType, cs2date, hh) AS b
                                               WHERE      (hh = 8)) AS c INNER JOIN
                                                  (SELECT     MedicamentType, accvalue, cs2date
                                                    FROM          (SELECT     MedicamentType, SUM(value) AS accvalue, cs2date, hh
                                                                            FROM          (SELECT     DosingLocation, MedicamentType, value, maxValue, minValue, cs2date, hh
                                                                                                    FROM          dbo._VDosingCalc_Step2 AS _VDosingCalc_Step2_2) AS a_2
                                                                            GROUP BY MedicamentType, cs2date, hh) AS c_1
                                                    WHERE      (hh = 16)) AS d ON d.MedicamentType = c.MedicamentType AND d.cs2date = c.cs2date) AS e INNER JOIN
                          (SELECT     MedicamentType, accvalue, cs2date
                            FROM          (SELECT     MedicamentType, SUM(value) AS accvalue, cs2date, hh
                                                    FROM          (SELECT     DosingLocation, MedicamentType, value, maxValue, minValue, cs2date, hh
                                                                            FROM          dbo._VDosingCalc_Step2 AS _VDosingCalc_Step2_1) AS a_1
                                                    GROUP BY MedicamentType, cs2date, hh) AS b_1
                            WHERE      (hh = 24)) AS f ON e.MedicamentType = f.MedicamentType AND e.cs2date = f.cs2date
go

