CREATE procedure [dbo].[proc_PDWeight_Report]
@R_ValueId  nvarchar(50)='',
@R_DateTime datetime=null
as
declare @R_Date date 
declare @C8 decimal(18,2) =0
declare @C16 decimal(18,2) =0
declare @C24 decimal(18,2) =0
set @R_Date = CONVERT(nvarchar(10), @R_DateTime, 120)

declare @firstValue decimal(18,2) =0
declare @lastValue decimal(18,2) =0
declare @firstID int =0
declare @lastID int=0
declare @maxValue decimal(18,2) =0
declare @tempCount int =0
-----------获取3个班起止日期----
declare @aBeginTime datetime
declare @aEndTime datetime
declare @aBeginTime8 datetime
declare @aEndTime8 datetime
declare @aBeginTime16 datetime
declare @aEndTime16 datetime
declare @tt datetime 
declare @tt1 datetime
set @tt =@R_DateTime
set @tt1=dateadd(day, -1, @R_DateTime)
set @aBeginTime=CONVERT(nvarchar(10),@tt1,120)+' 23:30:00'
set @aEndTime=CONVERT(nvarchar(10),@tt,120)+' 07:31:00'
-----
set @aBeginTime8=CONVERT(nvarchar(10),@tt,120)+' 7:30:00'
set @aEndTime8=CONVERT(nvarchar(10),@tt,120)+' 15:31:00'
-----
set @aBeginTime16=CONVERT(nvarchar(10),@tt,120)+' 15:30:00'
set @aEndTime16=CONVERT(nvarchar(10),@tt,120)+' 23:31:00'
-----------------------------------------------------
		select @maxValue=MAX(A_Value),@firstID=MIN(ID),@lastID =MAX(ID),@tempCount =COUNT(*)
			from mms_afmPDWeight 
		where A_datetime between @aBeginTime and @aEndTime
		AND ValueID =@R_ValueId
	if(@tempCount =0)
		set @C8 =0
	else 
		begin			
			select @firstValue=A_Value  from mms_afmPDWeight where ID =@firstID 
			select @lastValue=A_Value  from mms_afmPDWeight where ID =@lastID 
			if( @maxValue-@lastValue>1)
				set @C8=@lastValue+@maxValue-@firstValue
			else
				set @C8=@lastValue-@firstValue
		end
-----------------------------------------------------
		select @maxValue=MAX(A_Value),@firstID=MIN(ID),@lastID =MAX(ID),@tempCount =COUNT(*)
			from mms_afmPDWeight 
		where A_datetime between @aBeginTime8 and @aEndTime8
		AND ValueID =@R_ValueId 
	if(@tempCount =0)
		set @C16 =0
	else 
		begin				
			select @firstValue=A_Value  from mms_afmPDWeight where ID =@firstID 
			select @lastValue=A_Value  from mms_afmPDWeight where ID =@lastID  		
			if( @maxValue-@lastValue>1)
				set @C16=@lastValue+@maxValue-@firstValue
			else
				set @C16=@lastValue-@firstValue
		end
-----------------------------------------------------
		select @maxValue=MAX(A_Value),@firstID=MIN(ID),@lastID =MAX(ID),@tempCount =COUNT(*) 
			from mms_afmPDWeight 
		where A_datetime between @aBeginTime16 and @aEndTime16
		AND ValueID =@R_ValueId 
	if(@tempCount =0)
		set @C24 =0
	else 
		begin
					
			select @firstValue=A_Value  from mms_afmPDWeight where ID =@firstID 
			select @lastValue=A_Value  from mms_afmPDWeight where ID =@lastID 
			if( @maxValue-@lastValue>1)
				set @C24=@lastValue+@maxValue-@firstValue
			else
				set @C24=@lastValue-@firstValue
		end
		

declare @n1 nvarchar(50) =''
declare @n2 nvarchar(50) =''
declare @OrderCode int =0
if(@R_ValueId='285')
	begin
		set @n1 ='Ⅰ系列'
		set @n2 ='7#皮带'
		set @OrderCode =1
	end
if(@R_ValueId='286')
	begin
		set @n1 ='Ⅱ系列'
		set @n2 ='6#皮带'
		set @OrderCode =4
	end
if(@R_ValueId='287')
	begin
		set @n1 ='Ⅰ系列'
		set @n2 ='9#皮带'
		set @OrderCode =2
	end
if(@R_ValueId='288')
	begin
		set @n1 ='Ⅱ系列'
		set @n2 ='8#皮带'
		set @OrderCode =5
	end
declare @t_i int =0
select @t_i=COUNT(*) from mms_aReportPDWeight where R_date =@R_Date and R_ValueID =@R_ValueId 
if(@t_i =0)
	insert mms_aReportPDWeight values(@OrderCode,@R_ValueId,@n1,@n2,@C8,@C16,@C24,@R_Date)
if(@t_i >0)
	update mms_aReportPDWeight set C8=@C8,C16=@C16 ,C24=@C24 
			where R_date =@R_Date AND R_ValueID =@R_ValueId 


exec proc_aReportPDWeight_Sum @R_Date

go

