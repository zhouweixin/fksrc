------------------T4表上的三类触发器-------------------------------
create trigger [dbo].[Trig_EquipRTinsert] on [dbo].[mms_afmEquipmentRunTime]
for insert
as
declare @R_DateTime datetime =null
declare @R_ValueID nvarchar(50) =''
select @R_DateTime =A_datetime,@R_ValueID =ValueID from inserted   
exec proc_EquipmentRunTime_Report @R_ValueID,@R_DateTime
go

