CREATE trigger [dbo].[Trig_T6ForT6Acc_insert] on [dbo].[mms_aReportDay_T6]
for insert
as
declare @L_date date =null
select @L_date =R_Date  from inserted   
exec proc_aReportDay_AccStatus @L_date,1,3
exec proc_aReportRunMonth_Logic @L_date
go

