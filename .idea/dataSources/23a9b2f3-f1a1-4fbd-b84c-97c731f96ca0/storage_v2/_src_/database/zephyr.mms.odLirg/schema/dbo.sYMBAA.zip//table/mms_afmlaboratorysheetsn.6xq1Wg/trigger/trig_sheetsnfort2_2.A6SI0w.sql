CREATE trigger [dbo].[Trig_SheetSnForT2_2] on [dbo].[mms_afmLaboratorySheetSn]
for update
as
declare @L_date date =null
select @L_date =ls_Date  from inserted    
exec proc_aReportDay_P2 @L_date,2
exec proc_aReportDay2_P2 @L_date,2
exec proc_insertDaySumValueSn @L_date,'',2,3
exec proc_insertDaySumCombineValueSn @L_date,'',2,3
go

