create trigger Trig_T5ForT5Acc_insert on mms_aReportDay_T5
for insert
as
declare @L_date date =null
select @L_date =R_Date  from inserted   
exec proc_aReportDay_AccStatus @L_date,1,2
go

