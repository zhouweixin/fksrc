create trigger Trig_forSellReportD on mms_afmMonthSell
for delete
as
declare @L_date date =null 
select @L_date =SellMonth   from deleted    
exec proc_aReportJKSell @L_date
go

