CREATE VIEW dbo.mms_SJKWeightSummry_Report
AS
SELECT     wl_date, COUNT(*) AS CarCount, SUM(g1w3) AS G1Sum, SellToWho
FROM         dbo.mms_afmSSellWeightList
GROUP BY wl_date, SellToWho
go

