CREATE procedure [dbo].[proc_insertDaySumCombineValue]
@D_Date date =null,
@C_Cid nvarchar(50)='',
@M_Mode int =0, -----------操作模式，1插入、2更新、3删除
@D_Mode int=0-------------数据内容，1运行数据、2化验数据
as

-----1.计算运行数据日报情况-------------------- 
if(@D_Mode =1)
	begin 
	  begin--#region---readyData--
		declare @handlingCapacity_1 decimal(18,2) =0
		declare @runTime_1 decimal(18,2)=0
		declare @wt1_1 decimal(18,2)=0
		declare @wt2_1 decimal(18,2)=0
		declare @wt3_1 decimal(18,2)=0
		declare @wt4_1 decimal(18,2)=0
		declare @mineWherefrom_1 varchar(50)=''
		declare @self23_1 nvarchar(50)=''
		select @handlingCapacity_1=handlingCapacity ,
			@runTime_1=runTime,
			@wt1_1=waitForWaterTime ,
			@wt2_1=waitForElectricityTime ,
			@wt3_1=waitForFixTime ,
			@wt4_1=waitElseTime ,
			@mineWherefrom_1=minewherefrom,
			@self23_1=self23
					from mms_afmPlantRun where run_date=@D_Date and classid=@C_Cid
		
		declare @handlingCapacity_2 decimal(18,2) =0
		declare @runTime_2 decimal(18,2)=0
		declare @wt1_2 decimal(18,2)=0
		declare @wt2_2 decimal(18,2)=0
		declare @wt3_2 decimal(18,2)=0
		declare @wt4_2 decimal(18,2)=0
		declare @mineWherefrom_2 varchar(50)=''
		declare @self23_2 nvarchar(50)=''
		select @handlingCapacity_2=handlingCapacity ,
			@runTime_2=runTime,
			@wt1_2=waitForWaterTime ,
			@wt2_2=waitForElectricityTime ,
			@wt3_2=waitForFixTime ,
			@wt4_2=waitElseTime ,
			@mineWherefrom_2=minewherefrom,
			@self23_2=self23
					from mms_afmPlantRun2 where run_date=@D_Date and classid=@C_Cid	
					
		declare @handlingCapacity decimal(18,2) =0
		declare @runTime decimal(18,2)=0
		declare @wt1 decimal(18,2)=0
		declare @wt2 decimal(18,2)=0
		declare @wt3 decimal(18,2)=0
		declare @wt4 decimal(18,2)=0
		declare @mineWherefrom varchar(50)=''
		declare @self23 nvarchar(50)=''
		 set @handlingCapacity=@handlingCapacity_2 +@handlingCapacity_1
		 set @runTime=@runTime_2+@runTime_1
		 set @wt1=@wt1_2 +@wt1_1
		 set @wt2=@wt2_2 +@wt2_1
		 set @wt3=@wt3_2 +@wt3_1
		 set @wt4=@wt4_2 +@wt4_1
		 if(@mineWherefrom_2 <> @mineWherefrom_1)			
			set @mineWherefrom=@minewherefrom_1
		 if(@self23_2 <> @self23_1)
			set @self23=@self23_1		
	  end--#region---readyData--								
		if(@M_Mode=1 or @M_Mode =2)
			begin
				if(@C_Cid ='早班')
					begin
						update mms_aTypicalDaySummryCombine set MoringClass=@handlingCapacity
							where OrderCode='0101' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MoringClass=2*8
							where OrderCode='0601' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MoringClass=@runTime
							where OrderCode='0602'	and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MoringClass=@wt1+@wt2+@wt3+@wt4
							where OrderCode='0603' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MoringClass=@wt1
							where OrderCode='0604' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MoringClass=@wt2
							where OrderCode='0605' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MoringClass=@wt3
							where OrderCode='0606' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MoringClass=@wt4
							where OrderCode='0607' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MoringClass=100*@runTime/8
							where OrderCode='0608' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MoringClass=24*@handlingCapacity/nullif(@runTime,0)
							where OrderCode='0609' and MonthDate=@D_Date
					end
				if(@C_Cid ='中班')
					begin
						update mms_aTypicalDaySummryCombine set MiddleClass=@handlingCapacity
							where OrderCode='0101' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MiddleClass=2*8
							where OrderCode='0601' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MiddleClass=@runTime
							where OrderCode='0602' and MonthDate=@D_Date	
						update mms_aTypicalDaySummryCombine set MiddleClass=@wt1+@wt2+@wt3+@wt4
							where OrderCode='0603' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MiddleClass=@wt1
							where OrderCode='0604' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MiddleClass=@wt2
							where OrderCode='0605' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MiddleClass=@wt3
							where OrderCode='0606' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MiddleClass=@wt4
							where OrderCode='0607' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MiddleClass=100*@runTime/8
							where OrderCode='0608' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MiddleClass=24*@handlingCapacity/nullif(@runTime,0)
							where OrderCode='0609' and MonthDate=@D_Date
					end	
				if(@C_Cid ='晚班')
					begin
						update mms_aTypicalDaySummryCombine set NightClass=@handlingCapacity
							where OrderCode='0101' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set NightClass=2*8
							where OrderCode='0601' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set NightClass=@runTime
							where OrderCode='0602' and MonthDate=@D_Date	
						update mms_aTypicalDaySummryCombine set NightClass=@wt1+@wt2+@wt3+@wt4
							where OrderCode='0603' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set NightClass=@wt1
							where OrderCode='0604' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set NightClass=@wt2
							where OrderCode='0605' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set NightClass=@wt3
							where OrderCode='0606' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set NightClass=@wt4
							where OrderCode='0607' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set NightClass=100*@runTime/8
							where OrderCode='0608' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set NightClass=24*@handlingCapacity/nullif(@runTime,0)
							where OrderCode='0609' and MonthDate=@D_Date
					end
			end	
		if(@M_Mode=3)
			begin
				if(@C_Cid ='早班')
					begin
						update mms_aTypicalDaySummryCombine set MoringClass=0
							where OrderCode='0101' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MoringClass=0
							where OrderCode='0601' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MoringClass=0
							where OrderCode='0602' and MonthDate=@D_Date	
						update mms_aTypicalDaySummryCombine set MoringClass=0
							where OrderCode='0603' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MoringClass=0
							where OrderCode='0604' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MoringClass=0
							where OrderCode='0605' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MoringClass=0
							where OrderCode='0606' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MoringClass=0
							where OrderCode='0607' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MoringClass=0
							where OrderCode='0608' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MoringClass=0
							where OrderCode='0609' and MonthDate=@D_Date
					end
				if(@C_Cid ='中班')
					begin
						update mms_aTypicalDaySummryCombine set MiddleClass=0
							where OrderCode='0101' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MiddleClass=0
							where OrderCode='0601' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MiddleClass=0
							where OrderCode='0602'	 and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MiddleClass=0
							where OrderCode='0603' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MiddleClass=0
							where OrderCode='0604' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MiddleClass=0
							where OrderCode='0605' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MiddleClass=0
							where OrderCode='0606' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MiddleClass=0
							where OrderCode='0607' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MiddleClass=0
							where OrderCode='0608' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set MiddleClass=0
							where OrderCode='0609' and MonthDate=@D_Date
					end	
				if(@C_Cid ='晚班')
					begin
						update mms_aTypicalDaySummryCombine set NightClass=0
							where OrderCode='0101' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set NightClass=0
							where OrderCode='0601' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set NightClass=0
							where OrderCode='0602' and MonthDate=@D_Date	
						update mms_aTypicalDaySummryCombine set NightClass=0
							where OrderCode='0603' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set NightClass=0
							where OrderCode='0604' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set NightClass=0
							where OrderCode='0605' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set NightClass=0
							where OrderCode='0606' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set NightClass=0
							where OrderCode='0607' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set NightClass=0
							where OrderCode='0608' and MonthDate=@D_Date
						update mms_aTypicalDaySummryCombine set NightClass=0
							where OrderCode='0609' and MonthDate=@D_Date
					end				
			end
begin--#region2----------------计算当日和-------
			declare @handlingCapacity_day1 decimal(18,2) =0
			declare @runTime_day1 decimal(18,2)=0
			declare @wt1_day1 decimal(18,2)=0
			declare @wt2_day1 decimal(18,2)=0
			declare @wt3_day1 decimal(18,2)=0
			declare @wt4_day1 decimal(18,2)=0			
			select @handlingCapacity_day1=sum(handlingCapacity) ,
				@runTime_day1=sum(runTime),
				@wt1_day1=sum(waitForWaterTime) ,
				@wt2_day1=sum(waitForElectricityTime) ,
				@wt3_day1=sum(waitForFixTime) ,
				@wt4_day1=sum(waitElseTime) 
						from mms_afmPlantRun where run_date=@D_Date
						
			declare @handlingCapacity_day2 decimal(18,2) =0
			declare @runTime_day2 decimal(18,2)=0
			declare @wt1_day2 decimal(18,2)=0
			declare @wt2_day2 decimal(18,2)=0
			declare @wt3_day2 decimal(18,2)=0
			declare @wt4_day2 decimal(18,2)=0			
			select @handlingCapacity_day2=sum(handlingCapacity) ,
				@runTime_day2=sum(runTime),
				@wt1_day2=sum(waitForWaterTime) ,
				@wt2_day2=sum(waitForElectricityTime) ,
				@wt3_day2=sum(waitForFixTime) ,
				@wt4_day2=sum(waitElseTime) 
						from mms_afmPlantRun2 where run_date=@D_Date

			declare @handlingCapacity_day decimal(18,2) =0
			declare @runTime_day decimal(18,2)=0
			declare @wt1_day decimal(18,2)=0
			declare @wt2_day decimal(18,2)=0
			declare @wt3_day decimal(18,2)=0
			declare @wt4_day decimal(18,2)=0			
			set @handlingCapacity_day=@handlingCapacity_day1+@handlingCapacity_day2
			set @runTime_day=@runTime_day1+@runTime_day2
			set @wt1_day=@wt1_day1 + @wt1_day2
			set @wt2_day=@wt2_day1 + @wt2_day2
			set @wt3_day=@wt3_day1 + @wt3_day2
			set @wt4_day=@wt4_day1 + @wt4_day2		
						
			update mms_aTypicalDaySummryCombine set SummryDay=@handlingCapacity_day
				where OrderCode='0101' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set SummryDay=2*24
				where OrderCode='0601' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set SummryDay=@runTime_day
				where OrderCode='0602' and MonthDate=@D_Date	
			update mms_aTypicalDaySummryCombine set SummryDay=@wt1_day+@wt2_day+@wt3_day+@wt4_day
				where OrderCode='0603' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set SummryDay=@wt1_day
				where OrderCode='0604' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set SummryDay=@wt2_day
				where OrderCode='0605' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set SummryDay=@wt3_day
				where OrderCode='0606' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set SummryDay=@wt4_day
				where OrderCode='0607' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set SummryDay=100*@runTime_day/24
				where OrderCode='0608' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set SummryDay=24*@handlingCapacity_day/nullif(@runTime_day,0)
				where OrderCode='0609' and MonthDate=@D_Date
end--#region2----------------计算当日和-------				
begin--#region3------------计算月累计和-------

			---------处理日期关系--
				declare @StartDateTime datetime
				declare @EndDateTime datetime
				declare @iDays int
				if(day(@D_Date)<=25)
					select @StartDateTime = CONVERT(varchar(10), CONVERT(varchar(8),dateadd(month,-1,@D_Date),23)+'26' , 120)
				if(day(@D_Date)>25)
					select @StartDateTime = convert(varchar(8),@D_Date,21)+'26'
				select @EndDateTime = @D_Date
				select @iDays = datediff(day,convert(varchar(100),@StartDateTime,23),convert(varchar(100),@EndDateTime,23))
				set @iDays=@iDays +1
			-----------
			declare @handlingCapacity_month1 decimal(18,2) =0
			declare @runTime_month1  decimal(18,2)=0
			declare @wt1_month1  decimal(18,2)=0
			declare @wt2_month1  decimal(18,2)=0
			declare @wt3_month1  decimal(18,2)=0
			declare @wt4_month1  decimal(18,2)=0			
			select @handlingCapacity_month1 =sum(handlingCapacity) ,
				@runTime_month1 =sum(runTime),
				@wt1_month1 =sum(waitForWaterTime) ,
				@wt2_month1 =sum(waitForElectricityTime) ,
				@wt3_month1 =sum(waitForFixTime) ,
				@wt4_month1 =sum(waitElseTime) 
						from mms_afmPlantRun where run_date<=@D_Date and run_date>=@StartDateTime
						

			declare @handlingCapacity_month2 decimal(18,2) =0
			declare @runTime_month2  decimal(18,2)=0
			declare @wt1_month2  decimal(18,2)=0
			declare @wt2_month2  decimal(18,2)=0
			declare @wt3_month2  decimal(18,2)=0
			declare @wt4_month2  decimal(18,2)=0

			select @handlingCapacity_month2 =sum(handlingCapacity) ,
				@runTime_month2 =sum(runTime),
				@wt1_month2 =sum(waitForWaterTime) ,
				@wt2_month2 =sum(waitForElectricityTime) ,
				@wt3_month2 =sum(waitForFixTime) ,
				@wt4_month2 =sum(waitElseTime) 
						from mms_afmPlantRun2 where run_date<=@D_Date and run_date>=@StartDateTime
						
			declare @handlingCapacity_month decimal(18,2) =0
			declare @runTime_month  decimal(18,2)=0
			declare @wt1_month  decimal(18,2)=0
			declare @wt2_month  decimal(18,2)=0
			declare @wt3_month  decimal(18,2)=0
			declare @wt4_month  decimal(18,2)=0	
								
			set @handlingCapacity_month=@handlingCapacity_month1+@handlingCapacity_month2
			set @runTime_month=@runTime_month1+@runTime_month2
			set @wt1_month=@wt1_month1 + @wt1_month2
			set @wt2_month=@wt2_month1 + @wt2_month2
			set @wt3_month=@wt3_month1 + @wt3_month2
			set @wt4_month=@wt4_month1 + @wt4_month2							
						
			update mms_aTypicalDaySummryCombine set SummryMonth=@handlingCapacity_month
				where OrderCode='0101' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set SummryMonth=2*24*@iDays
				where OrderCode='0601' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set SummryMonth=@runTime_month
				where OrderCode='0602' and MonthDate=@D_Date	
			update mms_aTypicalDaySummryCombine set SummryMonth=@wt1_month+@wt2_month+@wt3_month+@wt4_month
				where OrderCode='0603' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set SummryMonth=@wt1_month
				where OrderCode='0604' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set SummryMonth=@wt2_month
				where OrderCode='0605' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set SummryMonth=@wt3_month
				where OrderCode='0606' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set SummryMonth=@wt4_month
				where OrderCode='0607' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set SummryMonth=100*@runTime_month/(24*nullif(@iDays,0))
				where OrderCode='0608' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set SummryMonth=24*@handlingCapacity_month/nullif(@runTime_month,0)
				where OrderCode='0609' and MonthDate=@D_Date	
end----#region3--------end-----						
			-------分矿源计算累计和-----
			if(@mineWherefrom='高椅山矿')
				begin
					declare @StartDateTime_gys datetime
					declare @EndDateTime_gys datetime
					declare @iDays_gys int
					if(day(@D_Date)<=25)
						select @StartDateTime_gys = CONVERT(varchar(10), CONVERT(varchar(8),dateadd(month,-1,@D_Date),23)+'26' , 120)
					if(day(@D_Date)>25)
						select @StartDateTime_gys = convert(varchar(8),@D_Date,21)+'26'
					select @EndDateTime_gys = @D_Date
					select @iDays_gys = datediff(day,convert(varchar(100),@StartDateTime_gys,23),convert(varchar(100),@EndDateTime_gys,23))
					set @iDays_gys=@iDays_gys +1				
				------------1-----
					declare @handlingCapacity_gys1 decimal(18,2) =0
					declare @runTime_gys1  decimal(18,2)=0
					declare @wt1_gys1  decimal(18,2)=0
					declare @wt2_gys1  decimal(18,2)=0
					declare @wt3_gys1  decimal(18,2)=0
					declare @wt4_gys1  decimal(18,2)=0
					select @handlingCapacity_gys1 =sum(handlingCapacity) ,
						@runTime_gys1 =sum(runTime),
						@wt1_gys1 =sum(waitForWaterTime) ,
						@wt2_gys1 =sum(waitForElectricityTime) ,
						@wt3_gys1 =sum(waitForFixTime) ,
						@wt4_gys1 =sum(waitElseTime) 
								from mms_afmPlantRun where run_date<=@D_Date and run_date>=@StartDateTime_gys and minewherefrom='高椅山矿'
					----------------------2-----
					declare @handlingCapacity_gys2 decimal(18,2) =0
					declare @runTime_gys2  decimal(18,2)=0
					declare @wt1_gys2  decimal(18,2)=0
					declare @wt2_gys2  decimal(18,2)=0
					declare @wt3_gys2  decimal(18,2)=0
					declare @wt4_gys2  decimal(18,2)=0
					select @handlingCapacity_gys2 =sum(handlingCapacity) ,
						@runTime_gys2 =sum(runTime),
						@wt1_gys2 =sum(waitForWaterTime) ,
						@wt2_gys2 =sum(waitForElectricityTime) ,
						@wt3_gys2 =sum(waitForFixTime) ,
						@wt4_gys2 =sum(waitElseTime) 
								from mms_afmPlantRun2 where run_date<=@D_Date and run_date>=@StartDateTime_gys and minewherefrom='高椅山矿'
					
					declare @handlingCapacity_gys decimal(18,2) =0
					declare @runTime_gys  decimal(18,2)=0
					declare @wt1_gys  decimal(18,2)=0
					declare @wt2_gys  decimal(18,2)=0
					declare @wt3_gys  decimal(18,2)=0
					declare @wt4_gys  decimal(18,2)=0
					set @handlingCapacity_gys=@handlingCapacity_gys1+@handlingCapacity_gys2
					set @runTime_gys=@runTime_gys1+@runTime_gys2
					set @wt1_gys=@wt1_gys1 + @wt1_gys2
					set @wt2_gys=@wt2_gys1 + @wt2_gys2
					set @wt3_gys=@wt3_gys1 + @wt3_gys2
					set @wt4_gys=@wt4_gys1 + @wt4_gys2	
													
					update mms_aTypicalDaySummryCombine set gys=@handlingCapacity_gys
						where OrderCode='0101' and MonthDate=@D_Date
					update mms_aTypicalDaySummryCombine set gys=2*24*@iDays_gys
						where OrderCode='0601' and MonthDate=@D_Date
					update mms_aTypicalDaySummryCombine set gys=@runTime_gys
						where OrderCode='0602' and MonthDate=@D_Date	
					update mms_aTypicalDaySummryCombine set gys=@wt1_gys+@wt2_gys+@wt3_gys+@wt4_gys
						where OrderCode='0603' and MonthDate=@D_Date
					update mms_aTypicalDaySummryCombine set gys=@wt1_gys
						where OrderCode='0604' and MonthDate=@D_Date
					update mms_aTypicalDaySummryCombine set gys=@wt2_gys
						where OrderCode='0605' and MonthDate=@D_Date
					update mms_aTypicalDaySummryCombine set gys=@wt3_gys
						where OrderCode='0606' and MonthDate=@D_Date
					update mms_aTypicalDaySummryCombine set gys=@wt4_gys
						where OrderCode='0607' and MonthDate=@D_Date
					update mms_aTypicalDaySummryCombine set gys=100*@runTime_gys/(24*nullif(@iDays_gys,0))
						where OrderCode='0608' and MonthDate=@D_Date
					update mms_aTypicalDaySummryCombine set gys=24*@handlingCapacity_gys/nullif(@runTime_gys,0)
						where OrderCode='0609' and MonthDate=@D_Date									
				end	
			if(@mineWherefrom='宏发矿')
				begin
					declare @StartDateTime_hf datetime
					declare @EndDateTime_hf datetime
					declare @iDays_hf int
					if(day(@D_Date)<=25)
						select @StartDateTime_hf = CONVERT(varchar(10), CONVERT(varchar(8),dateadd(month,-1,@D_Date),23)+'26' , 120)
					if(day(@D_Date)>25)
						select @StartDateTime_hf = convert(varchar(8),@D_Date,21)+'26'
					select @EndDateTime_hf = @D_Date
					select @iDays_hf = datediff(day,convert(varchar(100),@StartDateTime_hf,23),convert(varchar(100),@EndDateTime_hf,23))
					set @iDays_hf=@iDays_hf +1				
				------------1-----
					declare @handlingCapacity_hf1 decimal(18,2) =0
					declare @runTime_hf1  decimal(18,2)=0
					declare @wt1_hf1  decimal(18,2)=0
					declare @wt2_hf1  decimal(18,2)=0
					declare @wt3_hf1  decimal(18,2)=0
					declare @wt4_hf1  decimal(18,2)=0
					select @handlingCapacity_hf1 =sum(handlingCapacity) ,
						@runTime_hf1 =sum(runTime),
						@wt1_hf1 =sum(waitForWaterTime) ,
						@wt2_hf1 =sum(waitForElectricityTime) ,
						@wt3_hf1 =sum(waitForFixTime) ,
						@wt4_hf1 =sum(waitElseTime) 
								from mms_afmPlantRun where run_date<=@D_Date and run_date>=@StartDateTime_hf and minewherefrom='宏发矿'
					----------------------2-----
					declare @handlingCapacity_hf2 decimal(18,2) =0
					declare @runTime_hf2  decimal(18,2)=0
					declare @wt1_hf2  decimal(18,2)=0
					declare @wt2_hf2  decimal(18,2)=0
					declare @wt3_hf2  decimal(18,2)=0
					declare @wt4_hf2  decimal(18,2)=0
					select @handlingCapacity_hf2 =sum(handlingCapacity) ,
						@runTime_hf2 =sum(runTime),
						@wt1_hf2 =sum(waitForWaterTime) ,
						@wt2_hf2 =sum(waitForElectricityTime) ,
						@wt3_hf2 =sum(waitForFixTime) ,
						@wt4_hf2 =sum(waitElseTime) 
								from mms_afmPlantRun2 where run_date<=@D_Date and run_date>=@StartDateTime_hf and minewherefrom='宏发矿'
					
					declare @handlingCapacity_hf decimal(18,2) =0
					declare @runTime_hf  decimal(18,2)=0
					declare @wt1_hf  decimal(18,2)=0
					declare @wt2_hf  decimal(18,2)=0
					declare @wt3_hf  decimal(18,2)=0
					declare @wt4_hf  decimal(18,2)=0
					set @handlingCapacity_hf=@handlingCapacity_hf1+@handlingCapacity_hf2
					set @runTime_hf=@runTime_hf1+@runTime_hf2
					set @wt1_hf=@wt1_hf1 + @wt1_hf2
					set @wt2_hf=@wt2_hf1 + @wt2_hf2
					set @wt3_hf=@wt3_hf1 + @wt3_hf2
					set @wt4_hf=@wt4_hf1 + @wt4_hf2	
					
					update mms_aTypicalDaySummryCombine set hf=@handlingCapacity_hf
						where OrderCode='0101' and MonthDate=@D_Date
					update mms_aTypicalDaySummryCombine set hf=2*24*@iDays_hf
						where OrderCode='0601' and MonthDate=@D_Date
					update mms_aTypicalDaySummryCombine set hf=@runTime_hf
						where OrderCode='0602' and MonthDate=@D_Date	
					update mms_aTypicalDaySummryCombine set hf=@wt1_hf+@wt2_hf+@wt3_hf+@wt4_hf
						where OrderCode='0603' and MonthDate=@D_Date
					update mms_aTypicalDaySummryCombine set hf=@wt1_hf
						where OrderCode='0604' and MonthDate=@D_Date
					update mms_aTypicalDaySummryCombine set hf=@wt2_hf
						where OrderCode='0605' and MonthDate=@D_Date
					update mms_aTypicalDaySummryCombine set hf=@wt3_hf
						where OrderCode='0606' and MonthDate=@D_Date
					update mms_aTypicalDaySummryCombine set hf=@wt4_hf
						where OrderCode='0607' and MonthDate=@D_Date
					update mms_aTypicalDaySummryCombine set hf=100*@runTime_hf/(24*nullif(@iDays_hf,0))
						where OrderCode='0608' and MonthDate=@D_Date
					update mms_aTypicalDaySummryCombine set hf=24*@handlingCapacity_hf/nullif(@runTime_hf,0)
						where OrderCode='0609' and MonthDate=@D_Date									
				end	
			if(@mineWherefrom='易鑫矿')
				begin
					declare @StartDateTime_yx datetime
					declare @EndDateTime_yx datetime
					declare @iDays_yx int
					if(day(@D_Date)<=25)
						select @StartDateTime_yx = CONVERT(varchar(10), CONVERT(varchar(8),dateadd(month,-1,@D_Date),23)+'26' , 120)
					if(day(@D_Date)>25)
						select @StartDateTime_yx = convert(varchar(8),@D_Date,21)+'26'
					select @EndDateTime_yx = @D_Date
					select @iDays_yx = datediff(day,convert(varchar(100),@StartDateTime_yx,23),convert(varchar(100),@EndDateTime_yx,23))
					set @iDays_yx=@iDays_yx +1				
				------------1-----
					declare @handlingCapacity_yx1 decimal(18,2) =0
					declare @runTime_yx1  decimal(18,2)=0
					declare @wt1_yx1  decimal(18,2)=0
					declare @wt2_yx1  decimal(18,2)=0
					declare @wt3_yx1  decimal(18,2)=0
					declare @wt4_yx1  decimal(18,2)=0
					select @handlingCapacity_yx1 =sum(handlingCapacity) ,
						@runTime_yx1 =sum(runTime),
						@wt1_yx1 =sum(waitForWaterTime) ,
						@wt2_yx1 =sum(waitForElectricityTime) ,
						@wt3_yx1 =sum(waitForFixTime) ,
						@wt4_yx1 =sum(waitElseTime) 
								from mms_afmPlantRun where run_date<=@D_Date and run_date>=@StartDateTime_yx and minewherefrom='易鑫矿'
					----------------------2-----
					declare @handlingCapacity_yx2 decimal(18,2) =0
					declare @runTime_yx2  decimal(18,2)=0
					declare @wt1_yx2  decimal(18,2)=0
					declare @wt2_yx2  decimal(18,2)=0
					declare @wt3_yx2  decimal(18,2)=0
					declare @wt4_yx2  decimal(18,2)=0
					select @handlingCapacity_yx2 =sum(handlingCapacity) ,
						@runTime_yx2 =sum(runTime),
						@wt1_yx2 =sum(waitForWaterTime) ,
						@wt2_yx2 =sum(waitForElectricityTime) ,
						@wt3_yx2 =sum(waitForFixTime) ,
						@wt4_yx2 =sum(waitElseTime) 
								from mms_afmPlantRun2 where run_date<=@D_Date and run_date>=@StartDateTime_yx and minewherefrom='易鑫矿'
					
					declare @handlingCapacity_yx decimal(18,2) =0
					declare @runTime_yx  decimal(18,2)=0
					declare @wt1_yx  decimal(18,2)=0
					declare @wt2_yx  decimal(18,2)=0
					declare @wt3_yx  decimal(18,2)=0
					declare @wt4_yx  decimal(18,2)=0
					set @handlingCapacity_yx=@handlingCapacity_yx1+@handlingCapacity_yx2
					set @runTime_yx=@runTime_yx1+@runTime_yx2
					set @wt1_yx=@wt1_yx1 + @wt1_yx2
					set @wt2_yx=@wt2_yx1 + @wt2_yx2
					set @wt3_yx=@wt3_yx1 + @wt3_yx2
					set @wt4_yx=@wt4_yx1 + @wt4_yx2	
					
					update mms_aTypicalDaySummryCombine set yx=@handlingCapacity_yx
						where OrderCode='0101' and MonthDate=@D_Date
					update mms_aTypicalDaySummryCombine set yx=2*24*@iDays_yx
						where OrderCode='0601' and MonthDate=@D_Date
					update mms_aTypicalDaySummryCombine set yx=@runTime_yx
						where OrderCode='0602' and MonthDate=@D_Date	
					update mms_aTypicalDaySummryCombine set yx=@wt1_yx+@wt2_yx+@wt3_yx+@wt4_yx
						where OrderCode='0603' and MonthDate=@D_Date
					update mms_aTypicalDaySummryCombine set yx=@wt1_yx
						where OrderCode='0604' and MonthDate=@D_Date
					update mms_aTypicalDaySummryCombine set yx=@wt2_yx
						where OrderCode='0605' and MonthDate=@D_Date
					update mms_aTypicalDaySummryCombine set yx=@wt3_yx
						where OrderCode='0606' and MonthDate=@D_Date
					update mms_aTypicalDaySummryCombine set yx=@wt4_yx
						where OrderCode='0607' and MonthDate=@D_Date
					update mms_aTypicalDaySummryCombine set yx=100*@runTime_yx/(24*nullif(@iDays_yx,0))
						where OrderCode='0608' and MonthDate=@D_Date
					update mms_aTypicalDaySummryCombine set yx=24*@handlingCapacity_yx/nullif(@runTime_yx,0)
						where OrderCode='0609' and MonthDate=@D_Date									
				end		
	end 

-----2.化验数据填充日报-------------		
	begin----#region1-ReadyLabTag-化验数据准备
		declare @yk_1 DECIMAL(18,4) =0
		declare @yk_2 DECIMAL(18,4) =0
		declare @yk_3 DECIMAL(18,4) =0
		declare @yk_4 DECIMAL(18,4) =0
		declare @yk_5 DECIMAL(18,4) =0
		declare @yk_6 DECIMAL(18,4) =0
		declare @yk_7 DECIMAL(18,4) =0
		declare @yk_8 DECIMAL(18,4) =0
		declare @yk_9 DECIMAL(18,4) =0
		declare @PbSb_1 DECIMAL(18,4) =0
		declare @PbSb_2 DECIMAL(18,4) =0
		declare @PbSb_3 DECIMAL(18,4) =0
		declare @PbSb_4 DECIMAL(18,4) =0
		declare @PbSb_5 DECIMAL(18,4) =0
		declare @PbSb_6 DECIMAL(18,4) =0
		declare @PbSb_7 DECIMAL(18,4) =0
		declare @Zn_1 DECIMAL(18,4) =0
		declare @Zn_2 DECIMAL(18,4) =0
		declare @Zn_3 DECIMAL(18,4) =0
		declare @Zn_4 DECIMAL(18,4) =0

		declare @s1yk_1 DECIMAL(18,4) =0
		declare @s1yk_2 DECIMAL(18,4) =0
		declare @s1yk_3 DECIMAL(18,4) =0
		declare @s1yk_4 DECIMAL(18,4) =0
		declare @s1yk_5 DECIMAL(18,4) =0
		declare @s1yk_6 DECIMAL(18,4) =0
		declare @s1yk_7 DECIMAL(18,4) =0
		declare @s1yk_8 DECIMAL(18,4) =0
		declare @s1yk_9 DECIMAL(18,4) =0
		declare @s1PbSb_1 DECIMAL(18,4) =0
		declare @s1PbSb_2 DECIMAL(18,4) =0
		declare @s1PbSb_3 DECIMAL(18,4) =0
		declare @s1PbSb_4 DECIMAL(18,4) =0
		declare @s1PbSb_5 DECIMAL(18,4) =0
		declare @s1PbSb_6 DECIMAL(18,4) =0
		declare @s1PbSb_7 DECIMAL(18,4) =0
		declare @s1Zn_1 DECIMAL(18,4) =0
		declare @s1Zn_2 DECIMAL(18,4) =0
		declare @s1Zn_3 DECIMAL(18,4) =0
		declare @s1Zn_4 DECIMAL(18,4) =0
		
		declare @s2yk_1 DECIMAL(18,4) =0
		declare @s2yk_2 DECIMAL(18,4) =0
		declare @s2yk_3 DECIMAL(18,4) =0
		declare @s2yk_4 DECIMAL(18,4) =0
		declare @s2yk_5 DECIMAL(18,4) =0
		declare @s2yk_6 DECIMAL(18,4) =0
		declare @s2yk_7 DECIMAL(18,4) =0
		declare @s2yk_8 DECIMAL(18,4) =0
		declare @s2yk_9 DECIMAL(18,4) =0
		declare @s2PbSb_1 DECIMAL(18,4) =0
		declare @s2PbSb_2 DECIMAL(18,4) =0
		declare @s2PbSb_3 DECIMAL(18,4) =0
		declare @s2PbSb_4 DECIMAL(18,4) =0
		declare @s2PbSb_5 DECIMAL(18,4) =0
		declare @s2PbSb_6 DECIMAL(18,4) =0
		declare @s2PbSb_7 DECIMAL(18,4) =0
		declare @s2Zn_1 DECIMAL(18,4) =0
		declare @s2Zn_2 DECIMAL(18,4) =0
		declare @s2Zn_3 DECIMAL(18,4) =0
		declare @s2Zn_4 DECIMAL(18,4) =0	
					
		declare @StartDateTime_la datetime
		declare @EndDateTime_la datetime
		--declare @iDays_la int
		if(day(@D_Date)<=25)
			select @StartDateTime_La = CONVERT(varchar(10), CONVERT(varchar(8),dateadd(month,-1,@D_Date),23)+'26' , 120)
		if(day(@D_Date)>25)
			select @StartDateTime_la = convert(varchar(8),@D_Date,21)+'26'
		select @EndDateTime_la = @D_Date
end---#region1--ReadyLabTag

if(@D_Mode =2)
  begin
	if(@M_Mode=1 or @M_Mode=2)
	  begin
	  begin--#region-ReadLabData--
		select @s1yk_1 =YK_1, @s1yk_3 =YK_3,@s1yk_5 =YK_5,@s1yk_7 =YK_7,@s1yk_9 =YK_9,
			@s1pbsb_1 =PbSb_1,@s1pbsb_3 =PbSb_3,@s1pbsb_6 =PbSb_6,
			@s1zn_1 =Zn_1,@s1zn_3 =Zn_3
		 from mms_aReportDay_T1 where R_Date =@D_Date and R_CID=@C_Cid

		select @s2yk_1 =YK_1, @s2yk_3 =YK_3,@s2yk_5 =YK_5,@s2yk_7 =YK_7,@s2yk_9 =YK_9,
			@s2pbsb_1 =PbSb_1,@s2pbsb_3 =PbSb_3,@s2pbsb_6 =PbSb_6,
			@s2zn_1 =Zn_1,@s2zn_3 =Zn_3
		 from mms_aReportDay2_T1 where R_Date =@D_Date and R_CID=@C_Cid
	  end--#region-ReadLabData--
	begin--#region-calcLabData-	  		 
		set @yk_1=@s1yk_1+@s2yk_1
		set @yk_3=@s1yk_3+@s2yk_3
		set @yk_5=@s1yk_5+@s2yk_5
		set @yk_7=@s1yk_7+@s2yk_7
		set @yk_9=@s1yk_9+@s2yk_9
		set @PbSb_1=@s1pbsb_1+@s2pbsb_1
		set @PbSb_3=@s1pbsb_3+@s2pbsb_3
		set @PbSb_6=@s1pbsb_6+@s2pbsb_6
		set @Zn_1=@s1zn_1+@s2zn_1
		set @Zn_1=@s1zn_3+@s2zn_3
		 if(@yk_1>0)
			begin
				 set @yk_2=100*@yk_3/@yk_1
				 set @yk_4=100*@yk_5/@yk_1
				 set @yk_6=100*@yk_7/@yk_1
				 set @yk_8=100*@yk_9/@yk_1
			end
		 if(@yk_1=0)
			begin
				 set @yk_2=0
				 set @yk_4=0
				 set @yk_6=0
				 set @yk_8=0
			end
		 if(@pbsb_1=0)
			set	@pbsb_2=0
		 else
			set @pbsb_2 =100*@pbsb_3/@pbsb_1
		 if(@yk_3=0)
			set @pbsb_4=0
		 else 
			set @pbsb_4 =100*@pbsb_3/@yk_3
		 if(@pbsb_1=0)
			set @pbsb_5=0
		 else
			set @pbsb_5 =100*@pbsb_6/@pbsb_1

		 if(@yk_7=0)
			set @pbsb_7=0
		 else
			set @pbsb_7 =100*@pbsb_6/@yk_7
		 
		 if(@zn_1=0)
			set @zn_2=0
		 else
			set @zn_2 =100*@zn_3/@zn_1
		 if(@yk_5=0)
			set @zn_4=0
		 else 
			set @zn_4 =100*@zn_3/@yk_5	
	end--#region--calcLabData------	 
		 if(@C_Cid='晚班')		 
			begin
				update	mms_aTypicalDaySummryCombine set NightClass=@yk_1
					where MonthDate=@D_Date and OrderCode='0101'
				update	mms_aTypicalDaySummryCombine set NightClass=@yk_2
					where MonthDate=@D_Date and OrderCode='0102'
				update	mms_aTypicalDaySummryCombine set NightClass=@yk_3
					where MonthDate=@D_Date and OrderCode='0103'
				update	mms_aTypicalDaySummryCombine set NightClass=@yk_4
					where MonthDate=@D_Date and OrderCode='0104'
				update	mms_aTypicalDaySummryCombine set NightClass=@yk_5
					where MonthDate=@D_Date and OrderCode='0105'
				update	mms_aTypicalDaySummryCombine set NightClass=@yk_6
					where MonthDate=@D_Date and OrderCode='0106'
				update	mms_aTypicalDaySummryCombine set NightClass=@yk_7
					where MonthDate=@D_Date and OrderCode='0107'
				update	mms_aTypicalDaySummryCombine set NightClass=@yk_8
					where MonthDate=@D_Date and OrderCode='0108'
				update	mms_aTypicalDaySummryCombine set NightClass=@yk_9
					where MonthDate=@D_Date and OrderCode='0109'
				update	mms_aTypicalDaySummryCombine set NightClass=@pbsb_1
					where MonthDate=@D_Date and OrderCode='0201'
				update	mms_aTypicalDaySummryCombine set NightClass=@pbsb_2
					where MonthDate=@D_Date and OrderCode='0202'
				update	mms_aTypicalDaySummryCombine set NightClass=@pbsb_3
					where MonthDate=@D_Date and OrderCode='0203'
				update	mms_aTypicalDaySummryCombine set NightClass=@pbsb_4
					where MonthDate=@D_Date and OrderCode='0204'
				update	mms_aTypicalDaySummryCombine set NightClass=@pbsb_5
					where MonthDate=@D_Date and OrderCode='0205'
				update	mms_aTypicalDaySummryCombine set NightClass=@pbsb_6
					where MonthDate=@D_Date and OrderCode='0206'
				update	mms_aTypicalDaySummryCombine set NightClass=@pbsb_7
					where MonthDate=@D_Date and OrderCode='0207'
				update	mms_aTypicalDaySummryCombine set NightClass=@zn_1
					where MonthDate=@D_Date and OrderCode='0501'
				update	mms_aTypicalDaySummryCombine set NightClass=@zn_2
					where MonthDate=@D_Date and OrderCode='0502'
				update	mms_aTypicalDaySummryCombine set NightClass=@zn_3
					where MonthDate=@D_Date and OrderCode='0503'
				update	mms_aTypicalDaySummryCombine set NightClass=@zn_4
					where MonthDate=@D_Date and OrderCode='0504'
						
			end
		 if(@C_Cid='早班')
			begin
				update	mms_aTypicalDaySummryCombine set MoringClass=@yk_1
					where MonthDate=@D_Date and OrderCode='0101'
				update	mms_aTypicalDaySummryCombine set MoringClass=@yk_2
					where MonthDate=@D_Date and OrderCode='0102'
				update	mms_aTypicalDaySummryCombine set MoringClass=@yk_3
					where MonthDate=@D_Date and OrderCode='0103'
				update	mms_aTypicalDaySummryCombine set MoringClass=@yk_4
					where MonthDate=@D_Date and OrderCode='0104'
				update	mms_aTypicalDaySummryCombine set MoringClass=@yk_5
					where MonthDate=@D_Date and OrderCode='0105'
				update	mms_aTypicalDaySummryCombine set MoringClass=@yk_6
					where MonthDate=@D_Date and OrderCode='0106'
				update	mms_aTypicalDaySummryCombine set MoringClass=@yk_7
					where MonthDate=@D_Date and OrderCode='0107'
				update	mms_aTypicalDaySummryCombine set MoringClass=@yk_8
					where MonthDate=@D_Date and OrderCode='0108'
				update	mms_aTypicalDaySummryCombine set MoringClass=@yk_9
					where MonthDate=@D_Date and OrderCode='0109'
				update	mms_aTypicalDaySummryCombine set MoringClass=@pbsb_1
					where MonthDate=@D_Date and OrderCode='0201'
				update	mms_aTypicalDaySummryCombine set MoringClass=@pbsb_2
					where MonthDate=@D_Date and OrderCode='0202'
				update	mms_aTypicalDaySummryCombine set MoringClass=@pbsb_3
					where MonthDate=@D_Date and OrderCode='0203'
				update	mms_aTypicalDaySummryCombine set MoringClass=@pbsb_4
					where MonthDate=@D_Date and OrderCode='0204'
				update	mms_aTypicalDaySummryCombine set MoringClass=@pbsb_5
					where MonthDate=@D_Date and OrderCode='0205'
				update	mms_aTypicalDaySummryCombine set MoringClass=@pbsb_6
					where MonthDate=@D_Date and OrderCode='0206'
				update	mms_aTypicalDaySummryCombine set MoringClass=@pbsb_7
					where MonthDate=@D_Date and OrderCode='0207'
				update	mms_aTypicalDaySummryCombine set MoringClass=@zn_1
					where MonthDate=@D_Date and OrderCode='0501'
				update	mms_aTypicalDaySummryCombine set MoringClass=@zn_2
					where MonthDate=@D_Date and OrderCode='0502'
				update	mms_aTypicalDaySummryCombine set MoringClass=@zn_3
					where MonthDate=@D_Date and OrderCode='0503'
				update	mms_aTypicalDaySummryCombine set MoringClass=@zn_4
					where MonthDate=@D_Date and OrderCode='0504'
			end		
		 if(@C_Cid='中班')
			begin
				update	mms_aTypicalDaySummryCombine set MiddleClass=@yk_1
					where MonthDate=@D_Date and OrderCode='0101'
				update	mms_aTypicalDaySummryCombine set MiddleClass=@yk_2
					where MonthDate=@D_Date and OrderCode='0102'
				update	mms_aTypicalDaySummryCombine set MiddleClass=@yk_3
					where MonthDate=@D_Date and OrderCode='0103'
				update	mms_aTypicalDaySummryCombine set MiddleClass=@yk_4
					where MonthDate=@D_Date and OrderCode='0104'
				update	mms_aTypicalDaySummryCombine set MiddleClass=@yk_5
					where MonthDate=@D_Date and OrderCode='0105'
				update	mms_aTypicalDaySummryCombine set MiddleClass=@yk_6
					where MonthDate=@D_Date and OrderCode='0106'
				update	mms_aTypicalDaySummryCombine set MiddleClass=@yk_7
					where MonthDate=@D_Date and OrderCode='0107'
				update	mms_aTypicalDaySummryCombine set MiddleClass=@yk_8
					where MonthDate=@D_Date and OrderCode='0108'
				update	mms_aTypicalDaySummryCombine set MiddleClass=@yk_9
					where MonthDate=@D_Date and OrderCode='0109'
				update	mms_aTypicalDaySummryCombine set MiddleClass=@pbsb_1
					where MonthDate=@D_Date and OrderCode='0201'
				update	mms_aTypicalDaySummryCombine set MiddleClass=@pbsb_2
					where MonthDate=@D_Date and OrderCode='0202'
				update	mms_aTypicalDaySummryCombine set MiddleClass=@pbsb_3
					where MonthDate=@D_Date and OrderCode='0203'
				update	mms_aTypicalDaySummryCombine set MiddleClass=@pbsb_4
					where MonthDate=@D_Date and OrderCode='0204'
				update	mms_aTypicalDaySummryCombine set MiddleClass=@pbsb_5
					where MonthDate=@D_Date and OrderCode='0205'
				update	mms_aTypicalDaySummryCombine set MiddleClass=@pbsb_6
					where MonthDate=@D_Date and OrderCode='0206'
				update	mms_aTypicalDaySummryCombine set MiddleClass=@pbsb_7
					where MonthDate=@D_Date and OrderCode='0207'
				update	mms_aTypicalDaySummryCombine set MiddleClass=@zn_1
					where MonthDate=@D_Date and OrderCode='0501'
				update	mms_aTypicalDaySummryCombine set MiddleClass=@zn_2
					where MonthDate=@D_Date and OrderCode='0502'
				update	mms_aTypicalDaySummryCombine set MiddleClass=@zn_3
					where MonthDate=@D_Date and OrderCode='0503'
				update	mms_aTypicalDaySummryCombine set MiddleClass=@zn_4
					where MonthDate=@D_Date and OrderCode='0504'
			end
	  end					
	if(@M_Mode=3)		
	  begin	
		 if(@C_Cid='晚班')
			begin
				update	mms_aTypicalDaySummryCombine set NightClass=0
					where MonthDate=@D_Date and OrderCode='0101'
				update	mms_aTypicalDaySummryCombine set NightClass=0
					where MonthDate=@D_Date and OrderCode='0102'
				update	mms_aTypicalDaySummryCombine set NightClass=0
					where MonthDate=@D_Date and OrderCode='0103'
				update	mms_aTypicalDaySummryCombine set NightClass=0
					where MonthDate=@D_Date and OrderCode='0104'
				update	mms_aTypicalDaySummryCombine set NightClass=0
					where MonthDate=@D_Date and OrderCode='0105'
				update	mms_aTypicalDaySummryCombine set NightClass=0
					where MonthDate=@D_Date and OrderCode='0106'
				update	mms_aTypicalDaySummryCombine set NightClass=0
					where MonthDate=@D_Date and OrderCode='0107'
				update	mms_aTypicalDaySummryCombine set NightClass=0
					where MonthDate=@D_Date and OrderCode='0108'
				update	mms_aTypicalDaySummryCombine set NightClass=0
					where MonthDate=@D_Date and OrderCode='0109'
				update	mms_aTypicalDaySummryCombine set NightClass=0
					where MonthDate=@D_Date and OrderCode='0201'
				update	mms_aTypicalDaySummryCombine set NightClass=0
					where MonthDate=@D_Date and OrderCode='0202'
				update	mms_aTypicalDaySummryCombine set NightClass=0
					where MonthDate=@D_Date and OrderCode='0203'
				update	mms_aTypicalDaySummryCombine set NightClass=0
					where MonthDate=@D_Date and OrderCode='0204'
				update	mms_aTypicalDaySummryCombine set NightClass=0
					where MonthDate=@D_Date and OrderCode='0205'
				update	mms_aTypicalDaySummryCombine set NightClass=0
					where MonthDate=@D_Date and OrderCode='0206'
				update	mms_aTypicalDaySummryCombine set NightClass=0
					where MonthDate=@D_Date and OrderCode='0207'
				update	mms_aTypicalDaySummryCombine set NightClass=0
					where MonthDate=@D_Date and OrderCode='0501'
				update	mms_aTypicalDaySummryCombine set NightClass=0
					where MonthDate=@D_Date and OrderCode='0502'
				update	mms_aTypicalDaySummryCombine set NightClass=0
					where MonthDate=@D_Date and OrderCode='0503'
				update	mms_aTypicalDaySummryCombine set NightClass=0
					where MonthDate=@D_Date and OrderCode='0504'
			end
		 if(@C_Cid='早班')
			begin
				update	mms_aTypicalDaySummryCombine set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0101'
				update	mms_aTypicalDaySummryCombine set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0102'
				update	mms_aTypicalDaySummryCombine set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0103'
				update	mms_aTypicalDaySummryCombine set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0104'
				update	mms_aTypicalDaySummryCombine set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0105'
				update	mms_aTypicalDaySummryCombine set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0106'
				update	mms_aTypicalDaySummryCombine set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0107'
				update	mms_aTypicalDaySummryCombine set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0108'
				update	mms_aTypicalDaySummryCombine set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0109'
				update	mms_aTypicalDaySummryCombine set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0201'
				update	mms_aTypicalDaySummryCombine set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0202'
				update	mms_aTypicalDaySummryCombine set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0203'
				update	mms_aTypicalDaySummryCombine set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0204'
				update	mms_aTypicalDaySummryCombine set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0205'
				update	mms_aTypicalDaySummryCombine set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0206'
				update	mms_aTypicalDaySummryCombine set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0207'
				update	mms_aTypicalDaySummryCombine set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0501'
				update	mms_aTypicalDaySummryCombine set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0502'
				update	mms_aTypicalDaySummryCombine set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0503'
				update	mms_aTypicalDaySummryCombine set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0504'
			end		
		 if(@C_Cid='中班')
			begin
				update	mms_aTypicalDaySummryCombine set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0101'
				update	mms_aTypicalDaySummryCombine set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0102'
				update	mms_aTypicalDaySummryCombine set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0103'
				update	mms_aTypicalDaySummryCombine set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0104'
				update	mms_aTypicalDaySummryCombine set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0105'
				update	mms_aTypicalDaySummryCombine set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0106'
				update	mms_aTypicalDaySummryCombine set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0107'
				update	mms_aTypicalDaySummryCombine set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0108'
				update	mms_aTypicalDaySummryCombine set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0109'
				update	mms_aTypicalDaySummryCombine set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0201'
				update	mms_aTypicalDaySummryCombine set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0202'
				update	mms_aTypicalDaySummryCombine set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0203'
				update	mms_aTypicalDaySummryCombine set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0204'
				update	mms_aTypicalDaySummryCombine set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0205'
				update	mms_aTypicalDaySummryCombine set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0206'
				update	mms_aTypicalDaySummryCombine set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0207'
				update	mms_aTypicalDaySummryCombine set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0501'
				update	mms_aTypicalDaySummryCombine set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0502'
				update	mms_aTypicalDaySummryCombine set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0503'
				update	mms_aTypicalDaySummryCombine set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0504'
			end				
	  end
-----2.2化验数据单日合计-------------------
	begin--#region-ReadLabData--
		set @yk_1 =0
		set @yk_2 =0
		set @yk_3 =0
		set @yk_4 =0
		set @yk_5 =0
		set @yk_6 =0
		set @yk_7 =0
		set @yk_8 =0
		set @yk_9 =0
		set @PbSb_1 =0
		set @PbSb_2 =0
		set @PbSb_3 =0
		set @PbSb_4 =0
		set @PbSb_5 =0
		set @PbSb_6 =0
		set @PbSb_7 =0
		set @Zn_1 =0
		set @Zn_2 =0
		set @Zn_3 =0
		set @Zn_4 =0

		set @s1yk_1 =0
		set @s1yk_2 =0
		set @s1yk_3 =0
		set @s1yk_4 =0
		set @s1yk_5 =0
		set @s1yk_6 =0
		set @s1yk_7 =0
		set @s1yk_8 =0
		set @s1yk_9 =0
		set @s1PbSb_1 =0
		set @s1PbSb_2 =0
		set @s1PbSb_3 =0
		set @s1PbSb_4 =0
		set @s1PbSb_5 =0
		set @s1PbSb_6 =0
		set @s1PbSb_7 =0
		set @s1Zn_1 =0
		set @s1Zn_2 =0
		set @s1Zn_3 =0
		set @s1Zn_4 =0
		
		set @s2yk_1 =0
		set @s2yk_2 =0
		set @s2yk_3 =0
		set @s2yk_4 =0
		set @s2yk_5 =0
		set @s2yk_6 =0
		set @s2yk_7 =0
		set @s2yk_8 =0
		set @s2yk_9 =0
		set @s2PbSb_1 =0
		set @s2PbSb_2 =0
		set @s2PbSb_3 =0
		set @s2PbSb_4 =0
		set @s2PbSb_5 =0
		set @s2PbSb_6 =0
		set @s2PbSb_7 =0
		set @s2Zn_1 =0
		set @s2Zn_2 =0
		set @s2Zn_3 =0
		set @s2Zn_4 =0	
		
			select @s1yk_1 =SUM(YK_1), @s1yk_3 =SUM(YK_3),@s1yk_5 =SUM(YK_5),@s1yk_7 =SUM(YK_7),@s1yk_9 =SUM(YK_9),
			@s1pbsb_1 =SUM(PbSb_1),@s1pbsb_3 =SUM(PbSb_3),@s1pbsb_6 =SUM(PbSb_6),
			@s1zn_1 =SUM(Zn_1),@s1zn_3 =SUM(Zn_3)
			 from mms_aReportDay_T1 where R_Date =@D_Date 

			select @s2yk_1 =SUM(YK_1), @s2yk_3 =SUM(YK_3),@s2yk_5 =SUM(YK_5),@s2yk_7 =SUM(YK_7),@s2yk_9 =SUM(YK_9),
			@s2pbsb_1 =SUM(PbSb_1),@s2pbsb_3 =SUM(PbSb_3),@s2pbsb_6 =SUM(PbSb_6),
			@s2zn_1 =SUM(Zn_1),@s2zn_3 =SUM(Zn_3)
			 from mms_aReportDay2_T1 where R_Date =@D_Date 
	  end--#region-ReadLabData--
	begin--#region-calcLabData-	  		 
		set @yk_1=@s1yk_1+@s2yk_1
		set @yk_3=@s1yk_3+@s2yk_3
		set @yk_5=@s1yk_5+@s2yk_5
		set @yk_7=@s1yk_7+@s2yk_7
		set @yk_9=@s1yk_9+@s2yk_9
		set @PbSb_1=@s1pbsb_1+@s2pbsb_1
		set @PbSb_3=@s1pbsb_3+@s2pbsb_3
		set @PbSb_6=@s1pbsb_6+@s2pbsb_6
		set @Zn_1=@s1zn_1+@s2zn_1
		set @Zn_1=@s1zn_3+@s2zn_3
		 if(@yk_1>0)
			begin
				 set @yk_2=100*@yk_3/@yk_1
				 set @yk_4=100*@yk_5/@yk_1
				 set @yk_6=100*@yk_7/@yk_1
				 set @yk_8=100*@yk_9/@yk_1
			end
		 if(@yk_1=0)
			begin
				 set @yk_2=0
				 set @yk_4=0
				 set @yk_6=0
				 set @yk_8=0
			end
		 if(@pbsb_1=0)
			set	@pbsb_2=0
		 else
			set @pbsb_2 =100*@pbsb_3/@pbsb_1
		 if(@yk_3=0)
			set @pbsb_4=0
		 else 
			set @pbsb_4 =100*@pbsb_3/@yk_3
		 if(@pbsb_1=0)
			set @pbsb_5=0
		 else
			set @pbsb_5 =100*@pbsb_6/@pbsb_1

		 if(@yk_7=0)
			set @pbsb_7=0
		 else
			set @pbsb_7 =100*@pbsb_6/@yk_7
		 
		 if(@zn_1=0)
			set @zn_2=0
		 else
			set @zn_2 =100*@zn_3/@zn_1
		 if(@yk_5=0)
			set @zn_4=0
		 else 
			set @zn_4 =100*@zn_3/@yk_5	
	end--#region--calcLabData------			 
	begin--#region-updateData-		 			 
				update	mms_aTypicalDaySummryCombine set SummryDay=@yk_1
					where MonthDate=@D_Date and OrderCode='0101'
				update	mms_aTypicalDaySummryCombine set SummryDay=@yk_2
					where MonthDate=@D_Date and OrderCode='0102'
				update	mms_aTypicalDaySummryCombine set SummryDay=@yk_3
					where MonthDate=@D_Date and OrderCode='0103'
				update	mms_aTypicalDaySummryCombine set SummryDay=@yk_4
					where MonthDate=@D_Date and OrderCode='0104'
				update	mms_aTypicalDaySummryCombine set SummryDay=@yk_5
					where MonthDate=@D_Date and OrderCode='0105'
				update	mms_aTypicalDaySummryCombine set SummryDay=@yk_6
					where MonthDate=@D_Date and OrderCode='0106'
				update	mms_aTypicalDaySummryCombine set SummryDay=@yk_7
					where MonthDate=@D_Date and OrderCode='0107'
				update	mms_aTypicalDaySummryCombine set SummryDay=@yk_8
					where MonthDate=@D_Date and OrderCode='0108'
				update	mms_aTypicalDaySummryCombine set SummryDay=@yk_9
					where MonthDate=@D_Date and OrderCode='0109'
				update	mms_aTypicalDaySummryCombine set SummryDay=@pbsb_1
					where MonthDate=@D_Date and OrderCode='0201'
				update	mms_aTypicalDaySummryCombine set SummryDay=@pbsb_2
					where MonthDate=@D_Date and OrderCode='0202'
				update	mms_aTypicalDaySummryCombine set SummryDay=@pbsb_3
					where MonthDate=@D_Date and OrderCode='0203'
				update	mms_aTypicalDaySummryCombine set SummryDay=@pbsb_4
					where MonthDate=@D_Date and OrderCode='0204'
				update	mms_aTypicalDaySummryCombine set SummryDay=@pbsb_5
					where MonthDate=@D_Date and OrderCode='0205'
				update	mms_aTypicalDaySummryCombine set SummryDay=@pbsb_6
					where MonthDate=@D_Date and OrderCode='0206'
				update	mms_aTypicalDaySummryCombine set SummryDay=@pbsb_7
					where MonthDate=@D_Date and OrderCode='0207'
				update	mms_aTypicalDaySummryCombine set SummryDay=@zn_1
					where MonthDate=@D_Date and OrderCode='0501'
				update	mms_aTypicalDaySummryCombine set SummryDay=@zn_2
					where MonthDate=@D_Date and OrderCode='0502'
				update	mms_aTypicalDaySummryCombine set SummryDay=@zn_3
					where MonthDate=@D_Date and OrderCode='0503'
				update	mms_aTypicalDaySummryCombine set SummryDay=@zn_4
					where MonthDate=@D_Date and OrderCode='0504'
		end--#region--updateData

------2.3化验数据月累计-----------
	begin--#region-ReadLabData--
		set @yk_1 =0
		set @yk_2 =0
		set @yk_3 =0
		set @yk_4 =0
		set @yk_5 =0
		set @yk_6 =0
		set @yk_7 =0
		set @yk_8 =0
		set @yk_9 =0
		set @PbSb_1 =0
		set @PbSb_2 =0
		set @PbSb_3 =0
		set @PbSb_4 =0
		set @PbSb_5 =0
		set @PbSb_6 =0
		set @PbSb_7 =0
		set @Zn_1 =0
		set @Zn_2 =0
		set @Zn_3 =0
		set @Zn_4 =0

		set @s1yk_1 =0
		set @s1yk_2 =0
		set @s1yk_3 =0
		set @s1yk_4 =0
		set @s1yk_5 =0
		set @s1yk_6 =0
		set @s1yk_7 =0
		set @s1yk_8 =0
		set @s1yk_9 =0
		set @s1PbSb_1 =0
		set @s1PbSb_2 =0
		set @s1PbSb_3 =0
		set @s1PbSb_4 =0
		set @s1PbSb_5 =0
		set @s1PbSb_6 =0
		set @s1PbSb_7 =0
		set @s1Zn_1 =0
		set @s1Zn_2 =0
		set @s1Zn_3 =0
		set @s1Zn_4 =0
		
		set @s2yk_1 =0
		set @s2yk_2 =0
		set @s2yk_3 =0
		set @s2yk_4 =0
		set @s2yk_5 =0
		set @s2yk_6 =0
		set @s2yk_7 =0
		set @s2yk_8 =0
		set @s2yk_9 =0
		set @s2PbSb_1 =0
		set @s2PbSb_2 =0
		set @s2PbSb_3 =0
		set @s2PbSb_4 =0
		set @s2PbSb_5 =0
		set @s2PbSb_6 =0
		set @s2PbSb_7 =0
		set @s2Zn_1 =0
		set @s2Zn_2 =0
		set @s2Zn_3 =0
		set @s2Zn_4 =0
					 		
			select @s1yk_1 =SUM(YK_1), @s1yk_3 =SUM(YK_3),@s1yk_5 =SUM(YK_5),@s1yk_7 =SUM(YK_7),@s1yk_9 =SUM(YK_9),
			@s1pbsb_1 =SUM(PbSb_1),@s1pbsb_3 =SUM(PbSb_3),@s1pbsb_6 =SUM(PbSb_6),
			@s1zn_1 =SUM(Zn_1),@s1zn_3 =SUM(Zn_3)
			 from mms_aReportDay_T1 where R_Date <=@D_Date and R_Date>=@StartDateTime_la

			select @s2yk_1 =SUM(YK_1), @s2yk_3 =SUM(YK_3),@s2yk_5 =SUM(YK_5),@s2yk_7 =SUM(YK_7),@s2yk_9 =SUM(YK_9),
			@s2pbsb_1 =SUM(PbSb_1),@s2pbsb_3 =SUM(PbSb_3),@s2pbsb_6 =SUM(PbSb_6),
			@s2zn_1 =SUM(Zn_1),@s2zn_3 =SUM(Zn_3)
			 from mms_aReportDay2_T1 where R_Date <=@D_Date and R_Date>=@StartDateTime_la
	  end--#region-ReadLabData--
	begin--#region-calcLabData-	  		 
		set @yk_1=@s1yk_1+@s2yk_1
		set @yk_3=@s1yk_3+@s2yk_3
		set @yk_5=@s1yk_5+@s2yk_5
		set @yk_7=@s1yk_7+@s2yk_7
		set @yk_9=@s1yk_9+@s2yk_9
		set @PbSb_1=@s1pbsb_1+@s2pbsb_1
		set @PbSb_3=@s1pbsb_3+@s2pbsb_3
		set @PbSb_6=@s1pbsb_6+@s2pbsb_6
		set @Zn_1=@s1zn_1+@s2zn_1
		set @Zn_1=@s1zn_3+@s2zn_3
		 if(@yk_1>0)
			begin
				 set @yk_2=100*@yk_3/@yk_1
				 set @yk_4=100*@yk_5/@yk_1
				 set @yk_6=100*@yk_7/@yk_1
				 set @yk_8=100*@yk_9/@yk_1
			end
		 if(@yk_1=0)
			begin
				 set @yk_2=0
				 set @yk_4=0
				 set @yk_6=0
				 set @yk_8=0
			end
		 if(@pbsb_1=0)
			set	@pbsb_2=0
		 else
			set @pbsb_2 =100*@pbsb_3/@pbsb_1
		 if(@yk_3=0)
			set @pbsb_4=0
		 else 
			set @pbsb_4 =100*@pbsb_3/@yk_3
		 if(@pbsb_1=0)
			set @pbsb_5=0
		 else
			set @pbsb_5 =100*@pbsb_6/@pbsb_1

		 if(@yk_7=0)
			set @pbsb_7=0
		 else
			set @pbsb_7 =100*@pbsb_6/@yk_7
		 
		 if(@zn_1=0)
			set @zn_2=0
		 else
			set @zn_2 =100*@zn_3/@zn_1
		 if(@yk_5=0)
			set @zn_4=0
		 else 
			set @zn_4 =100*@zn_3/@yk_5	
	end--#region--calcLabData------
	begin--#region--updateData--	
				update	mms_aTypicalDaySummryCombine set SummryMonth=@yk_1
					where MonthDate=@D_Date and OrderCode='0101'
				update	mms_aTypicalDaySummryCombine set SummryMonth=@yk_2
					where MonthDate=@D_Date and OrderCode='0102'
				update	mms_aTypicalDaySummryCombine set SummryMonth=@yk_3
					where MonthDate=@D_Date and OrderCode='0103'
				update	mms_aTypicalDaySummryCombine set SummryMonth=@yk_4
					where MonthDate=@D_Date and OrderCode='0104'
				update	mms_aTypicalDaySummryCombine set SummryMonth=@yk_5
					where MonthDate=@D_Date and OrderCode='0105'
				update	mms_aTypicalDaySummryCombine set SummryMonth=@yk_6
					where MonthDate=@D_Date and OrderCode='0106'
				update	mms_aTypicalDaySummryCombine set SummryMonth=@yk_7
					where MonthDate=@D_Date and OrderCode='0107'
				update	mms_aTypicalDaySummryCombine set SummryMonth=@yk_8
					where MonthDate=@D_Date and OrderCode='0108'
				update	mms_aTypicalDaySummryCombine set SummryMonth=@yk_9
					where MonthDate=@D_Date and OrderCode='0109'
				update	mms_aTypicalDaySummryCombine set SummryMonth=@pbsb_1
					where MonthDate=@D_Date and OrderCode='0201'
				update	mms_aTypicalDaySummryCombine set SummryMonth=@pbsb_2
					where MonthDate=@D_Date and OrderCode='0202'
				update	mms_aTypicalDaySummryCombine set SummryMonth=@pbsb_3
					where MonthDate=@D_Date and OrderCode='0203'
				update	mms_aTypicalDaySummryCombine set SummryMonth=@pbsb_4
					where MonthDate=@D_Date and OrderCode='0204'
				update	mms_aTypicalDaySummryCombine set SummryMonth=@pbsb_5
					where MonthDate=@D_Date and OrderCode='0205'
				update	mms_aTypicalDaySummryCombine set SummryMonth=@pbsb_6
					where MonthDate=@D_Date and OrderCode='0206'
				update	mms_aTypicalDaySummryCombine set SummryMonth=@pbsb_7
					where MonthDate=@D_Date and OrderCode='0207'
				update	mms_aTypicalDaySummryCombine set SummryMonth=@zn_1
					where MonthDate=@D_Date and OrderCode='0501'
				update	mms_aTypicalDaySummryCombine set SummryMonth=@zn_2
					where MonthDate=@D_Date and OrderCode='0502'
				update	mms_aTypicalDaySummryCombine set SummryMonth=@zn_3
					where MonthDate=@D_Date and OrderCode='0503'
				update	mms_aTypicalDaySummryCombine set SummryMonth=@zn_4
					where MonthDate=@D_Date and OrderCode='0504'
	end--#region---updateData		
------2.4高椅山月累计--------------
	  begin--#region-ReadLabData--
		set @yk_1 =0
		set @yk_2 =0
		set @yk_3 =0
		set @yk_4 =0
		set @yk_5 =0
		set @yk_6 =0
		set @yk_7 =0
		set @yk_8 =0
		set @yk_9 =0
		set @PbSb_1 =0
		set @PbSb_2 =0
		set @PbSb_3 =0
		set @PbSb_4 =0
		set @PbSb_5 =0
		set @PbSb_6 =0
		set @PbSb_7 =0
		set @Zn_1 =0
		set @Zn_2 =0
		set @Zn_3 =0
		set @Zn_4 =0

		set @s1yk_1 =0
		set @s1yk_2 =0
		set @s1yk_3 =0
		set @s1yk_4 =0
		set @s1yk_5 =0
		set @s1yk_6 =0
		set @s1yk_7 =0
		set @s1yk_8 =0
		set @s1yk_9 =0
		set @s1PbSb_1 =0
		set @s1PbSb_2 =0
		set @s1PbSb_3 =0
		set @s1PbSb_4 =0
		set @s1PbSb_5 =0
		set @s1PbSb_6 =0
		set @s1PbSb_7 =0
		set @s1Zn_1 =0
		set @s1Zn_2 =0
		set @s1Zn_3 =0
		set @s1Zn_4 =0
		
		set @s2yk_1 =0
		set @s2yk_2 =0
		set @s2yk_3 =0
		set @s2yk_4 =0
		set @s2yk_5 =0
		set @s2yk_6 =0
		set @s2yk_7 =0
		set @s2yk_8 =0
		set @s2yk_9 =0
		set @s2PbSb_1 =0
		set @s2PbSb_2 =0
		set @s2PbSb_3 =0
		set @s2PbSb_4 =0
		set @s2PbSb_5 =0
		set @s2PbSb_6 =0
		set @s2PbSb_7 =0
		set @s2Zn_1 =0
		set @s2Zn_2 =0
		set @s2Zn_3 =0
		set @s2Zn_4 =0
						 		
		select @s1yk_1 =SUM(YK_1), @s1yk_3 =SUM(YK_3),@s1yk_5 =SUM(YK_5),@s1yk_7 =SUM(YK_7),@s1yk_9 =SUM(YK_9),
			@s1pbsb_1 =SUM(PbSb_1),@s1pbsb_3 =SUM(PbSb_3),@s1pbsb_6 =SUM(PbSb_6),
			@s1zn_1 =SUM(Zn_1),@s1zn_3 =SUM(Zn_3)
		from mms_afmPlantRun b inner join mms_aReportDay_T1 a 
			on a.R_Date=b.run_date and a.R_CID=b.classid	 
		where a.R_Date <=@D_Date and a.R_Date>=@StartDateTime_la and b.minewherefrom='高椅山矿'	

		select @s2yk_1 =SUM(YK_1), @s2yk_3 =SUM(YK_3),@s2yk_5 =SUM(YK_5),@s2yk_7 =SUM(YK_7),@s2yk_9 =SUM(YK_9),
			@s2pbsb_1 =SUM(PbSb_1),@s2pbsb_3 =SUM(PbSb_3),@s2pbsb_6 =SUM(PbSb_6),
			@s2zn_1 =SUM(Zn_1),@s2zn_3 =SUM(Zn_3)
		from mms_afmPlantRun2 b inner join mms_aReportDay2_T1 a 
			on a.R_Date=b.run_date and a.R_CID=b.classid	 
		where a.R_Date <=@D_Date and a.R_Date>=@StartDateTime_la and b.minewherefrom='高椅山矿'	
		
	  end--#region-ReadLabData--
	begin--#region-calcLabData-	  		 
		set @yk_1=@s1yk_1+@s2yk_1
		set @yk_3=@s1yk_3+@s2yk_3
		set @yk_5=@s1yk_5+@s2yk_5
		set @yk_7=@s1yk_7+@s2yk_7
		set @yk_9=@s1yk_9+@s2yk_9
		set @PbSb_1=@s1pbsb_1+@s2pbsb_1
		set @PbSb_3=@s1pbsb_3+@s2pbsb_3
		set @PbSb_6=@s1pbsb_6+@s2pbsb_6
		set @Zn_1=@s1zn_1+@s2zn_1
		set @Zn_1=@s1zn_3+@s2zn_3
		 if(@yk_1>0)
			begin
				 set @yk_2=100*@yk_3/@yk_1
				 set @yk_4=100*@yk_5/@yk_1
				 set @yk_6=100*@yk_7/@yk_1
				 set @yk_8=100*@yk_9/@yk_1
			end
		 if(@yk_1=0)
			begin
				 set @yk_2=0
				 set @yk_4=0
				 set @yk_6=0
				 set @yk_8=0
			end
		 if(@pbsb_1=0)
			set	@pbsb_2=0
		 else
			set @pbsb_2 =100*@pbsb_3/@pbsb_1
		 if(@yk_3=0)
			set @pbsb_4=0
		 else 
			set @pbsb_4 =100*@pbsb_3/@yk_3
		 if(@pbsb_1=0)
			set @pbsb_5=0
		 else
			set @pbsb_5 =100*@pbsb_6/@pbsb_1

		 if(@yk_7=0)
			set @pbsb_7=0
		 else
			set @pbsb_7 =100*@pbsb_6/@yk_7
		 
		 if(@zn_1=0)
			set @zn_2=0
		 else
			set @zn_2 =100*@zn_3/@zn_1
		 if(@yk_5=0)
			set @zn_4=0
		 else 
			set @zn_4 =100*@zn_3/@yk_5	
	end--#region--calcLabData------
	begin--#region--updateData--	
				update	mms_aTypicalDaySummryCombine set gys=@yk_1
					where MonthDate=@D_Date and OrderCode='0101'
				update	mms_aTypicalDaySummryCombine set gys=@yk_2
					where MonthDate=@D_Date and OrderCode='0102'
				update	mms_aTypicalDaySummryCombine set gys=@yk_3
					where MonthDate=@D_Date and OrderCode='0103'
				update	mms_aTypicalDaySummryCombine set gys=@yk_4
					where MonthDate=@D_Date and OrderCode='0104'
				update	mms_aTypicalDaySummryCombine set gys=@yk_5
					where MonthDate=@D_Date and OrderCode='0105'
				update	mms_aTypicalDaySummryCombine set gys=@yk_6
					where MonthDate=@D_Date and OrderCode='0106'
				update	mms_aTypicalDaySummryCombine set gys=@yk_7
					where MonthDate=@D_Date and OrderCode='0107'
				update	mms_aTypicalDaySummryCombine set gys=@yk_8
					where MonthDate=@D_Date and OrderCode='0108'
				update	mms_aTypicalDaySummryCombine set gys=@yk_9
					where MonthDate=@D_Date and OrderCode='0109'
				update	mms_aTypicalDaySummryCombine set gys=@pbsb_1
					where MonthDate=@D_Date and OrderCode='0201'
				update	mms_aTypicalDaySummryCombine set gys=@pbsb_2
					where MonthDate=@D_Date and OrderCode='0202'
				update	mms_aTypicalDaySummryCombine set gys=@pbsb_3
					where MonthDate=@D_Date and OrderCode='0203'
				update	mms_aTypicalDaySummryCombine set gys=@pbsb_4
					where MonthDate=@D_Date and OrderCode='0204'
				update	mms_aTypicalDaySummryCombine set gys=@pbsb_5
					where MonthDate=@D_Date and OrderCode='0205'
				update	mms_aTypicalDaySummryCombine set gys=@pbsb_6
					where MonthDate=@D_Date and OrderCode='0206'
				update	mms_aTypicalDaySummryCombine set gys=@pbsb_7
					where MonthDate=@D_Date and OrderCode='0207'
				update	mms_aTypicalDaySummryCombine set gys=@zn_1
					where MonthDate=@D_Date and OrderCode='0501'
				update	mms_aTypicalDaySummryCombine set gys=@zn_2
					where MonthDate=@D_Date and OrderCode='0502'
				update	mms_aTypicalDaySummryCombine set gys=@zn_3
					where MonthDate=@D_Date and OrderCode='0503'
				update	mms_aTypicalDaySummryCombine set gys=@zn_4
					where MonthDate=@D_Date and OrderCode='0504'
	end--#region---updateData	

------2.5易鑫矿月累计---------------
	begin--#region-ReadLabData--
		set @yk_1 =0
		set @yk_2 =0
		set @yk_3 =0
		set @yk_4 =0
		set @yk_5 =0
		set @yk_6 =0
		set @yk_7 =0
		set @yk_8 =0
		set @yk_9 =0
		set @PbSb_1 =0
		set @PbSb_2 =0
		set @PbSb_3 =0
		set @PbSb_4 =0
		set @PbSb_5 =0
		set @PbSb_6 =0
		set @PbSb_7 =0
		set @Zn_1 =0
		set @Zn_2 =0
		set @Zn_3 =0
		set @Zn_4 =0

		set @s1yk_1 =0
		set @s1yk_2 =0
		set @s1yk_3 =0
		set @s1yk_4 =0
		set @s1yk_5 =0
		set @s1yk_6 =0
		set @s1yk_7 =0
		set @s1yk_8 =0
		set @s1yk_9 =0
		set @s1PbSb_1 =0
		set @s1PbSb_2 =0
		set @s1PbSb_3 =0
		set @s1PbSb_4 =0
		set @s1PbSb_5 =0
		set @s1PbSb_6 =0
		set @s1PbSb_7 =0
		set @s1Zn_1 =0
		set @s1Zn_2 =0
		set @s1Zn_3 =0
		set @s1Zn_4 =0
		
		set @s2yk_1 =0
		set @s2yk_2 =0
		set @s2yk_3 =0
		set @s2yk_4 =0
		set @s2yk_5 =0
		set @s2yk_6 =0
		set @s2yk_7 =0
		set @s2yk_8 =0
		set @s2yk_9 =0
		set @s2PbSb_1 =0
		set @s2PbSb_2 =0
		set @s2PbSb_3 =0
		set @s2PbSb_4 =0
		set @s2PbSb_5 =0
		set @s2PbSb_6 =0
		set @s2PbSb_7 =0
		set @s2Zn_1 =0
		set @s2Zn_2 =0
		set @s2Zn_3 =0
		set @s2Zn_4 =0
						 		
		select @s1yk_1 =SUM(YK_1), @s1yk_3 =SUM(YK_3),@s1yk_5 =SUM(YK_5),@s1yk_7 =SUM(YK_7),@s1yk_9 =SUM(YK_9),
			@s1pbsb_1 =SUM(PbSb_1),@s1pbsb_3 =SUM(PbSb_3),@s1pbsb_6 =SUM(PbSb_6),
			@s1zn_1 =SUM(Zn_1),@s1zn_3 =SUM(Zn_3)
		from mms_afmPlantRun b inner join mms_aReportDay_T1 a 
			on a.R_Date=b.run_date and a.R_CID=b.classid	 
		where a.R_Date <=@D_Date and a.R_Date>=@StartDateTime_la and b.minewherefrom='易鑫矿'	

		select @s2yk_1 =SUM(YK_1), @s2yk_3 =SUM(YK_3),@s2yk_5 =SUM(YK_5),@s2yk_7 =SUM(YK_7),@s2yk_9 =SUM(YK_9),
			@s2pbsb_1 =SUM(PbSb_1),@s2pbsb_3 =SUM(PbSb_3),@s2pbsb_6 =SUM(PbSb_6),
			@s2zn_1 =SUM(Zn_1),@s2zn_3 =SUM(Zn_3)
		from mms_afmPlantRun2 b inner join mms_aReportDay2_T1 a 
			on a.R_Date=b.run_date and a.R_CID=b.classid	 
		where a.R_Date <=@D_Date and a.R_Date>=@StartDateTime_la and b.minewherefrom='易鑫矿'	
		
	  end--#region-ReadLabData--
	begin--#region-calcLabData-	  		 
		set @yk_1=@s1yk_1+@s2yk_1
		set @yk_3=@s1yk_3+@s2yk_3
		set @yk_5=@s1yk_5+@s2yk_5
		set @yk_7=@s1yk_7+@s2yk_7
		set @yk_9=@s1yk_9+@s2yk_9
		set @PbSb_1=@s1pbsb_1+@s2pbsb_1
		set @PbSb_3=@s1pbsb_3+@s2pbsb_3
		set @PbSb_6=@s1pbsb_6+@s2pbsb_6
		set @Zn_1=@s1zn_1+@s2zn_1
		set @Zn_1=@s1zn_3+@s2zn_3
		 if(@yk_1>0)
			begin
				 set @yk_2=100*@yk_3/@yk_1
				 set @yk_4=100*@yk_5/@yk_1
				 set @yk_6=100*@yk_7/@yk_1
				 set @yk_8=100*@yk_9/@yk_1
			end
		 if(@yk_1=0)
			begin
				 set @yk_2=0
				 set @yk_4=0
				 set @yk_6=0
				 set @yk_8=0
			end
		 if(@pbsb_1=0)
			set	@pbsb_2=0
		 else
			set @pbsb_2 =100*@pbsb_3/@pbsb_1
		 if(@yk_3=0)
			set @pbsb_4=0
		 else 
			set @pbsb_4 =100*@pbsb_3/@yk_3
		 if(@pbsb_1=0)
			set @pbsb_5=0
		 else
			set @pbsb_5 =100*@pbsb_6/@pbsb_1

		 if(@yk_7=0)
			set @pbsb_7=0
		 else
			set @pbsb_7 =100*@pbsb_6/@yk_7
		 
		 if(@zn_1=0)
			set @zn_2=0
		 else
			set @zn_2 =100*@zn_3/@zn_1
		 if(@yk_5=0)
			set @zn_4=0
		 else 
			set @zn_4 =100*@zn_3/@yk_5	
	end--#region--calcLabData------
	begin--#region--updateData--	
				update	mms_aTypicalDaySummryCombine set yx=@yk_1
					where MonthDate=@D_Date and OrderCode='0101'
				update	mms_aTypicalDaySummryCombine set yx=@yk_2
					where MonthDate=@D_Date and OrderCode='0102'
				update	mms_aTypicalDaySummryCombine set yx=@yk_3
					where MonthDate=@D_Date and OrderCode='0103'
				update	mms_aTypicalDaySummryCombine set yx=@yk_4
					where MonthDate=@D_Date and OrderCode='0104'
				update	mms_aTypicalDaySummryCombine set yx=@yk_5
					where MonthDate=@D_Date and OrderCode='0105'
				update	mms_aTypicalDaySummryCombine set yx=@yk_6
					where MonthDate=@D_Date and OrderCode='0106'
				update	mms_aTypicalDaySummryCombine set yx=@yk_7
					where MonthDate=@D_Date and OrderCode='0107'
				update	mms_aTypicalDaySummryCombine set yx=@yk_8
					where MonthDate=@D_Date and OrderCode='0108'
				update	mms_aTypicalDaySummryCombine set yx=@yk_9
					where MonthDate=@D_Date and OrderCode='0109'
				update	mms_aTypicalDaySummryCombine set yx=@pbsb_1
					where MonthDate=@D_Date and OrderCode='0201'
				update	mms_aTypicalDaySummryCombine set yx=@pbsb_2
					where MonthDate=@D_Date and OrderCode='0202'
				update	mms_aTypicalDaySummryCombine set yx=@pbsb_3
					where MonthDate=@D_Date and OrderCode='0203'
				update	mms_aTypicalDaySummryCombine set yx=@pbsb_4
					where MonthDate=@D_Date and OrderCode='0204'
				update	mms_aTypicalDaySummryCombine set yx=@pbsb_5
					where MonthDate=@D_Date and OrderCode='0205'
				update	mms_aTypicalDaySummryCombine set yx=@pbsb_6
					where MonthDate=@D_Date and OrderCode='0206'
				update	mms_aTypicalDaySummryCombine set yx=@pbsb_7
					where MonthDate=@D_Date and OrderCode='0207'
				update	mms_aTypicalDaySummryCombine set yx=@zn_1
					where MonthDate=@D_Date and OrderCode='0501'
				update	mms_aTypicalDaySummryCombine set yx=@zn_2
					where MonthDate=@D_Date and OrderCode='0502'
				update	mms_aTypicalDaySummryCombine set yx=@zn_3
					where MonthDate=@D_Date and OrderCode='0503'
				update	mms_aTypicalDaySummryCombine set yx=@zn_4
					where MonthDate=@D_Date and OrderCode='0504'
	end--#region---updateData		
------2.6宏发矿月累计-------------------
	begin--#region-ReadLabData--
		set @yk_1 =0
		set @yk_2 =0
		set @yk_3 =0
		set @yk_4 =0
		set @yk_5 =0
		set @yk_6 =0
		set @yk_7 =0
		set @yk_8 =0
		set @yk_9 =0
		set @PbSb_1 =0
		set @PbSb_2 =0
		set @PbSb_3 =0
		set @PbSb_4 =0
		set @PbSb_5 =0
		set @PbSb_6 =0
		set @PbSb_7 =0
		set @Zn_1 =0
		set @Zn_2 =0
		set @Zn_3 =0
		set @Zn_4 =0

		set @s1yk_1 =0
		set @s1yk_2 =0
		set @s1yk_3 =0
		set @s1yk_4 =0
		set @s1yk_5 =0
		set @s1yk_6 =0
		set @s1yk_7 =0
		set @s1yk_8 =0
		set @s1yk_9 =0
		set @s1PbSb_1 =0
		set @s1PbSb_2 =0
		set @s1PbSb_3 =0
		set @s1PbSb_4 =0
		set @s1PbSb_5 =0
		set @s1PbSb_6 =0
		set @s1PbSb_7 =0
		set @s1Zn_1 =0
		set @s1Zn_2 =0
		set @s1Zn_3 =0
		set @s1Zn_4 =0
		
		set @s2yk_1 =0
		set @s2yk_2 =0
		set @s2yk_3 =0
		set @s2yk_4 =0
		set @s2yk_5 =0
		set @s2yk_6 =0
		set @s2yk_7 =0
		set @s2yk_8 =0
		set @s2yk_9 =0
		set @s2PbSb_1 =0
		set @s2PbSb_2 =0
		set @s2PbSb_3 =0
		set @s2PbSb_4 =0
		set @s2PbSb_5 =0
		set @s2PbSb_6 =0
		set @s2PbSb_7 =0
		set @s2Zn_1 =0
		set @s2Zn_2 =0
		set @s2Zn_3 =0
		set @s2Zn_4 =0
						 		
		select @s1yk_1 =SUM(YK_1), @s1yk_3 =SUM(YK_3),@s1yk_5 =SUM(YK_5),@s1yk_7 =SUM(YK_7),@s1yk_9 =SUM(YK_9),
			@s1pbsb_1 =SUM(PbSb_1),@s1pbsb_3 =SUM(PbSb_3),@s1pbsb_6 =SUM(PbSb_6),
			@s1zn_1 =SUM(Zn_1),@s1zn_3 =SUM(Zn_3)
		from mms_afmPlantRun b inner join mms_aReportDay_T1 a 
			on a.R_Date=b.run_date and a.R_CID=b.classid	 
		where a.R_Date <=@D_Date and a.R_Date>=@StartDateTime_la and b.minewherefrom='宏发矿'	

		select @s2yk_1 =SUM(YK_1), @s2yk_3 =SUM(YK_3),@s2yk_5 =SUM(YK_5),@s2yk_7 =SUM(YK_7),@s2yk_9 =SUM(YK_9),
			@s2pbsb_1 =SUM(PbSb_1),@s2pbsb_3 =SUM(PbSb_3),@s2pbsb_6 =SUM(PbSb_6),
			@s2zn_1 =SUM(Zn_1),@s2zn_3 =SUM(Zn_3)
		from mms_afmPlantRun2 b inner join mms_aReportDay2_T1 a 
			on a.R_Date=b.run_date and a.R_CID=b.classid	 
		where a.R_Date <=@D_Date and a.R_Date>=@StartDateTime_la and b.minewherefrom='宏发矿'	
		
	  end--#region-ReadLabData--
	begin--#region-calcLabData-	  		 
		set @yk_1=@s1yk_1+@s2yk_1
		set @yk_3=@s1yk_3+@s2yk_3
		set @yk_5=@s1yk_5+@s2yk_5
		set @yk_7=@s1yk_7+@s2yk_7
		set @yk_9=@s1yk_9+@s2yk_9
		set @PbSb_1=@s1pbsb_1+@s2pbsb_1
		set @PbSb_3=@s1pbsb_3+@s2pbsb_3
		set @PbSb_6=@s1pbsb_6+@s2pbsb_6
		set @Zn_1=@s1zn_1+@s2zn_1
		set @Zn_1=@s1zn_3+@s2zn_3
		 if(@yk_1>0)
			begin
				 set @yk_2=100*@yk_3/@yk_1
				 set @yk_4=100*@yk_5/@yk_1
				 set @yk_6=100*@yk_7/@yk_1
				 set @yk_8=100*@yk_9/@yk_1
			end
		 if(@yk_1=0)
			begin
				 set @yk_2=0
				 set @yk_4=0
				 set @yk_6=0
				 set @yk_8=0
			end
		 if(@pbsb_1=0)
			set	@pbsb_2=0
		 else
			set @pbsb_2 =100*@pbsb_3/@pbsb_1
		 if(@yk_3=0)
			set @pbsb_4=0
		 else 
			set @pbsb_4 =100*@pbsb_3/@yk_3
		 if(@pbsb_1=0)
			set @pbsb_5=0
		 else
			set @pbsb_5 =100*@pbsb_6/@pbsb_1

		 if(@yk_7=0)
			set @pbsb_7=0
		 else
			set @pbsb_7 =100*@pbsb_6/@yk_7
		 
		 if(@zn_1=0)
			set @zn_2=0
		 else
			set @zn_2 =100*@zn_3/@zn_1
		 if(@yk_5=0)
			set @zn_4=0
		 else 
			set @zn_4 =100*@zn_3/@yk_5	
	end--#region--calcLabData------
	begin--#region--updateData--	
				update	mms_aTypicalDaySummryCombine set hf=@yk_1
					where MonthDate=@D_Date and OrderCode='0101'
				update	mms_aTypicalDaySummryCombine set hf=@yk_2
					where MonthDate=@D_Date and OrderCode='0102'
				update	mms_aTypicalDaySummryCombine set hf=@yk_3
					where MonthDate=@D_Date and OrderCode='0103'
				update	mms_aTypicalDaySummryCombine set hf=@yk_4
					where MonthDate=@D_Date and OrderCode='0104'
				update	mms_aTypicalDaySummryCombine set hf=@yk_5
					where MonthDate=@D_Date and OrderCode='0105'
				update	mms_aTypicalDaySummryCombine set hf=@yk_6
					where MonthDate=@D_Date and OrderCode='0106'
				update	mms_aTypicalDaySummryCombine set hf=@yk_7
					where MonthDate=@D_Date and OrderCode='0107'
				update	mms_aTypicalDaySummryCombine set hf=@yk_8
					where MonthDate=@D_Date and OrderCode='0108'
				update	mms_aTypicalDaySummryCombine set hf=@yk_9
					where MonthDate=@D_Date and OrderCode='0109'
				update	mms_aTypicalDaySummryCombine set hf=@pbsb_1
					where MonthDate=@D_Date and OrderCode='0201'
				update	mms_aTypicalDaySummryCombine set hf=@pbsb_2
					where MonthDate=@D_Date and OrderCode='0202'
				update	mms_aTypicalDaySummryCombine set hf=@pbsb_3
					where MonthDate=@D_Date and OrderCode='0203'
				update	mms_aTypicalDaySummryCombine set hf=@pbsb_4
					where MonthDate=@D_Date and OrderCode='0204'
				update	mms_aTypicalDaySummryCombine set hf=@pbsb_5
					where MonthDate=@D_Date and OrderCode='0205'
				update	mms_aTypicalDaySummryCombine set hf=@pbsb_6
					where MonthDate=@D_Date and OrderCode='0206'
				update	mms_aTypicalDaySummryCombine set hf=@pbsb_7
					where MonthDate=@D_Date and OrderCode='0207'
				update	mms_aTypicalDaySummryCombine set hf=@zn_1
					where MonthDate=@D_Date and OrderCode='0501'
				update	mms_aTypicalDaySummryCombine set hf=@zn_2
					where MonthDate=@D_Date and OrderCode='0502'
				update	mms_aTypicalDaySummryCombine set hf=@zn_3
					where MonthDate=@D_Date and OrderCode='0503'
				update	mms_aTypicalDaySummryCombine set hf=@zn_4
					where MonthDate=@D_Date and OrderCode='0504'
	end--#region---updateData	
  end

go

