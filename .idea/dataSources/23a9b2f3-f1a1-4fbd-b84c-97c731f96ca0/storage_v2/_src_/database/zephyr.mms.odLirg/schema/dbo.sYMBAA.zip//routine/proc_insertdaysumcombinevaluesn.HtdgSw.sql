create procedure [dbo].[proc_insertDaySumCombineValueSn]
@D_Date date =null,
@C_Cid nvarchar(50)='',
@M_Mode int =0, -----------操作模式： 1插入、2更新、3删除
@D_Mode int =0 -----------调用类型： 1 T2调用、 2称重数据调用、  3化验数据调用
as
if(@D_Mode=1)
begin
if(@M_Mode=1 or @M_Mode=2)
begin
	declare @sn_XN_1 DECIMAL(18,4) =0
	declare @sn_XN_2 DECIMAL(18,4) =0
	declare @sn_XN_3 DECIMAL(18,4) =0
	declare @sn_XN_4 DECIMAL(18,4) =0
	declare @sn_ZX_1 DECIMAL(18,4) =0
	declare @sn_ZX_2 DECIMAL(18,4) =0
	declare @sn_ZX_3 DECIMAL(18,4) =0
	declare @sn_ZX_4 DECIMAL(18,4) =0
	declare @yk_sn DECIMAL(18,4) =0
	declare @yk_sn1 DECIMAL(18,4) =0
	declare @yk_sn2 DECIMAL(18,4) =0		

	select @sn_XN_1=Sn_XN_1, @sn_XN_3=Sn_XN_3, @sn_ZX_1=Sn_ZX_1, @sn_ZX_3=Sn_ZX_3 
		from mms_aReportDay_T2 where R_Date =@D_Date and R_CID=@C_Cid
	if(@sn_XN_1=0)
		set @sn_XN_2=0
	else
		set @sn_XN_2 =100*@sn_XN_3/@sn_XN_1

	if(@sn_ZX_1=0)
		set @sn_ZX_2=0
	else
		set @sn_ZX_2 =100*@sn_ZX_3/@sn_ZX_1
		
	select @yk_sn1 =yk_9 from mms_aReportDay_T1 where R_Date =@D_Date and R_CID=@C_Cid
	select @yk_sn2 =yk_9 from mms_aReportDay2_T1 where R_Date =@D_Date and R_CID=@C_Cid	
	set @yk_sn=@yk_sn1+@yk_sn2
	
	if (@yk_sn =0)
		begin
			set @sn_XN_4 =0
			set @sn_ZX_4 =0
		end
	else 
		begin
			
			set @sn_XN_4 =100*@sn_XN_3/@yk_sn
			set @sn_ZX_4 =100*@sn_ZX_3/@yk_sn
		end
	
	
	if(@C_Cid='晚班')
		begin  
			update mms_aTypicalDaySummryCombine set NightClass=@sn_XN_1
				where OrderCode='0301' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set NightClass=@sn_XN_2
				where OrderCode='0302' and MonthDate=@D_Date	
			update mms_aTypicalDaySummryCombine set NightClass=@sn_XN_3
				where OrderCode='0303' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set NightClass=@sn_XN_4
				where OrderCode='0304' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set NightClass=@sn_ZX_1
				where OrderCode='0401' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set NightClass=@sn_ZX_2
				where OrderCode='0402' and MonthDate=@D_Date	
			update mms_aTypicalDaySummryCombine set NightClass=@sn_ZX_3
				where OrderCode='0403' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set NightClass=@sn_ZX_4
				where OrderCode='0404' and MonthDate=@D_Date								
		end
	if(@C_Cid='早班')
		begin  
			update mms_aTypicalDaySummryCombine set MoringClass=@sn_XN_1
				where OrderCode='0301' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set MoringClass=@sn_XN_2
				where OrderCode='0302' and MonthDate=@D_Date	
			update mms_aTypicalDaySummryCombine set MoringClass=@sn_XN_3
				where OrderCode='0303' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set MoringClass=@sn_XN_4
				where OrderCode='0304' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set MoringClass=@sn_ZX_1
				where OrderCode='0401' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set MoringClass=@sn_ZX_2
				where OrderCode='0402' and MonthDate=@D_Date	
			update mms_aTypicalDaySummryCombine set MoringClass=@sn_ZX_3
				where OrderCode='0403' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set MoringClass=@sn_ZX_4
				where OrderCode='0404' and MonthDate=@D_Date								
		end		
	if(@C_Cid='中班')
		begin  
			update mms_aTypicalDaySummryCombine set MiddleClass=@sn_XN_1
				where OrderCode='0301' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set MiddleClass=@sn_XN_2
				where OrderCode='0302' and MonthDate=@D_Date	
			update mms_aTypicalDaySummryCombine set MiddleClass=@sn_XN_3
				where OrderCode='0303' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set MiddleClass=@sn_XN_4
				where OrderCode='0304' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set MiddleClass=@sn_ZX_1
				where OrderCode='0401' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set MiddleClass=@sn_ZX_2
				where OrderCode='0402' and MonthDate=@D_Date	
			update mms_aTypicalDaySummryCombine set MiddleClass=@sn_ZX_3
				where OrderCode='0403' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set MiddleClass=@sn_ZX_4
				where OrderCode='0404' and MonthDate=@D_Date								
		end	
end

if(@M_Mode=3)
  begin
	if(@C_Cid='晚班')
		begin  
			update mms_aTypicalDaySummryCombine set NightClass=0
				where OrderCode='0301' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set NightClass=0
				where OrderCode='0302' and MonthDate=@D_Date	
			update mms_aTypicalDaySummryCombine set NightClass=0
				where OrderCode='0303' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set NightClass=0
				where OrderCode='0304' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set NightClass=0
				where OrderCode='0401' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set NightClass=0
				where OrderCode='0402' and MonthDate=@D_Date	
			update mms_aTypicalDaySummryCombine set NightClass=0
				where OrderCode='0403' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set NightClass=0
				where OrderCode='0404' and MonthDate=@D_Date								
		end
	if(@C_Cid='早班')
		begin  
			update mms_aTypicalDaySummryCombine set MoringClass=0
				where OrderCode='0301' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set MoringClass=0
				where OrderCode='0302' and MonthDate=@D_Date	
			update mms_aTypicalDaySummryCombine set MoringClass=0
				where OrderCode='0303' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set MoringClass=0
				where OrderCode='0304' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set MoringClass=0
				where OrderCode='0401' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set MoringClass=0
				where OrderCode='0402' and MonthDate=@D_Date	
			update mms_aTypicalDaySummryCombine set MoringClass=0
				where OrderCode='0403' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set MoringClass=0
				where OrderCode='0404' and MonthDate=@D_Date								
		end		
	if(@C_Cid='中班')
		begin  
			update mms_aTypicalDaySummryCombine set MiddleClass=0
				where OrderCode='0301' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set MiddleClass=0
				where OrderCode='0302' and MonthDate=@D_Date	
			update mms_aTypicalDaySummryCombine set MiddleClass=0
				where OrderCode='0303' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set MiddleClass=0
				where OrderCode='0304' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set MiddleClass=0
				where OrderCode='0401' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set MiddleClass=0
				where OrderCode='0402' and MonthDate=@D_Date	
			update mms_aTypicalDaySummryCombine set MiddleClass=0
				where OrderCode='0403' and MonthDate=@D_Date
			update mms_aTypicalDaySummryCombine set MiddleClass=0
				where OrderCode='0404' and MonthDate=@D_Date								
		end
  end
	begin--#region1_begin-----------------日合计----------------------------------	
	set @sn_XN_1 =0
	set @sn_XN_2 =0
	set @sn_XN_3 =0
	set @sn_XN_4 =0
	set @sn_ZX_1 =0
	set @sn_ZX_2 =0
	set @sn_ZX_3 =0
	set @sn_ZX_4 =0
	set @yk_sn =0
	set @yk_sn1 =0
	set @yk_sn2 =0
	select @sn_XN_1=SUM(Sn_XN_1), @sn_XN_3=sum(Sn_XN_3), @sn_ZX_1=sum(Sn_ZX_1), @sn_ZX_3=sum(Sn_ZX_3) 
		from mms_aReportDay_T2 where R_Date =@D_Date 
	if(@sn_XN_1=0)
		set @sn_XN_2=0
	else
		set @sn_XN_2 =100*@sn_XN_3/@sn_XN_1

	if(@sn_ZX_1=0)
		set @sn_ZX_2=0
	else
		set @sn_ZX_2 =100*@sn_ZX_3/@sn_ZX_1

	select @yk_sn1 =SUM(yk_9) from mms_aReportDay_T1 where R_Date =@D_Date 
	select @yk_sn2 =SUM(yk_9) from mms_aReportDay2_T1 where R_Date =@D_Date 	
	set @yk_sn = @yk_sn1+@yk_sn2
	if (@yk_sn =0)
		begin
			set @sn_XN_4 =0
			set @sn_ZX_4 =0
		end
	else 
		begin
			
			set @sn_XN_4 =100*@sn_XN_3/@yk_sn
			set @sn_ZX_4 =100*@sn_ZX_3/@yk_sn
		end
	update mms_aTypicalDaySummryCombine set SummryDay=@sn_XN_1
		where OrderCode='0301' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set SummryDay=@sn_XN_2
		where OrderCode='0302' and MonthDate=@D_Date	
	update mms_aTypicalDaySummryCombine set SummryDay=@sn_XN_3
		where OrderCode='0303' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set SummryDay=@sn_XN_4
		where OrderCode='0304' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set SummryDay=@sn_ZX_1
		where OrderCode='0401' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set SummryDay=@sn_ZX_2
		where OrderCode='0402' and MonthDate=@D_Date	
	update mms_aTypicalDaySummryCombine set SummryDay=@sn_ZX_3
		where OrderCode='0403' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set SummryDay=@sn_ZX_4
		where OrderCode='0404' and MonthDate=@D_Date	
end--#region1_end

	declare @StartDateTime datetime
	
	if(day(@D_Date)<=25)
		select @StartDateTime = CONVERT(varchar(10), CONVERT(varchar(8),dateadd(month,-1,@D_Date),23)+'26' , 120)
	if(day(@D_Date)>25)
		select @StartDateTime = convert(varchar(8),@D_Date,21)+'26'
		
	begin--#region2_begin-----------------月累计----------------------------------	
	set @sn_XN_1 =0
	set @sn_XN_2 =0
	set @sn_XN_3 =0
	set @sn_XN_4 =0
	set @sn_ZX_1 =0
	set @sn_ZX_2 =0
	set @sn_ZX_3 =0
	set @sn_ZX_4 =0
	set @yk_sn =0	
	set @yk_sn1 =0
	set @yk_sn2 =0
				
	select @sn_XN_1=SUM(Sn_XN_1), @sn_XN_3=sum(Sn_XN_3), @sn_ZX_1=sum(Sn_ZX_1), @sn_ZX_3=sum(Sn_ZX_3) 
		from mms_aReportDay_T2 where R_Date <=@D_Date and R_Date >=@StartDateTime 
	if(@sn_XN_1=0)
		set @sn_XN_2=0
	else
		set @sn_XN_2 =100*@sn_XN_3/@sn_XN_1

	if(@sn_ZX_1=0)
		set @sn_ZX_2=0
	else
		set @sn_ZX_2 =100*@sn_ZX_3/@sn_ZX_1

--	select @yk_sn =SUM(yk_9) from mms_aReportDay_T1 where R_Date <=@D_Date and R_Date >=@StartDateTime

	select @yk_sn1 =SUM(yk_9) from mms_aReportDay_T1 where R_Date <=@D_Date and R_Date >=@StartDateTime
	select @yk_sn2 =SUM(yk_9) from mms_aReportDay2_T1  where R_Date <=@D_Date and R_Date >=@StartDateTime 	
	set @yk_sn = @yk_sn1+@yk_sn2
		 
	if (@yk_sn =0)
		begin
			set @sn_XN_4 =0
			set @sn_ZX_4 =0
		end
	else 
		begin
			
			set @sn_XN_4 =100*@sn_XN_3/@yk_sn
			set @sn_ZX_4 =100*@sn_ZX_3/@yk_sn
		end
	update mms_aTypicalDaySummryCombine set SummryMonth=@sn_XN_1
		where OrderCode='0301' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set SummryMonth=@sn_XN_2
		where OrderCode='0302' and MonthDate=@D_Date	
	update mms_aTypicalDaySummryCombine set SummryMonth=@sn_XN_3
		where OrderCode='0303' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set SummryMonth=@sn_XN_4
		where OrderCode='0304' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set SummryMonth=@sn_ZX_1
		where OrderCode='0401' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set SummryMonth=@sn_ZX_2
		where OrderCode='0402' and MonthDate=@D_Date	
	update mms_aTypicalDaySummryCombine set SummryMonth=@sn_ZX_3
		where OrderCode='0403' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set SummryMonth=@sn_ZX_4
		where OrderCode='0404' and MonthDate=@D_Date	
end--#region2_end

	begin--#region3_begin-----------------高椅山月累计----------------------------------	
	set @sn_XN_1 =0
	set @sn_XN_2 =0
	set @sn_XN_3 =0
	set @sn_XN_4 =0
	set @sn_ZX_1 =0
	set @sn_ZX_2 =0
	set @sn_ZX_3 =0
	set @sn_ZX_4 =0
	set @yk_sn =0	
	set @yk_sn1 =0
	set @yk_sn2 =0
		
	select @sn_XN_1=SUM(a.Sn_XN_1), @sn_XN_3=sum(a.Sn_XN_3), @sn_ZX_1=sum(a.Sn_ZX_1), @sn_ZX_3=sum(a.Sn_ZX_3) 
		from mms_afmPlantRun b inner join mms_aReportDay_T2 a
			on a.R_Date=b.run_date and a.R_CID=b.classid
		where a.R_Date <=@D_Date and a.R_Date >=@StartDateTime and b.minewherefrom='高椅山矿'
	if(@sn_XN_1=0)
		set @sn_XN_2=0
	else
		set @sn_XN_2 =100*@sn_XN_3/@sn_XN_1

	if(@sn_ZX_1=0)
		set @sn_ZX_2=0
	else
		set @sn_ZX_2 =100*@sn_ZX_3/@sn_ZX_1

	select @yk_sn1 =SUM(yk_9) 
		from mms_afmPlantRun b inner join mms_aReportDay_T1 a
			on a.R_Date=b.run_date and a.R_CID=b.classid 
		where R_Date <=@D_Date and R_Date >=@StartDateTime and b.minewherefrom='高椅山矿'

	select @yk_sn2 =SUM(yk_9) 
		from mms_afmPlantRun2 b inner join mms_aReportDay2_T1 a
			on a.R_Date=b.run_date and a.R_CID=b.classid 
		where R_Date <=@D_Date and R_Date >=@StartDateTime and b.minewherefrom='高椅山矿'
				
	set @yk_sn = @yk_sn1+@yk_sn2
	
	if (@yk_sn =0)
		begin
			set @sn_XN_4 =0
			set @sn_ZX_4 =0
		end
	else 
		begin
			
			set @sn_XN_4 =100*@sn_XN_3/@yk_sn
			set @sn_ZX_4 =100*@sn_ZX_3/@yk_sn
		end
	update mms_aTypicalDaySummryCombine set gys=@sn_XN_1
		where OrderCode='0301' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set gys=@sn_XN_2
		where OrderCode='0302' and MonthDate=@D_Date	
	update mms_aTypicalDaySummryCombine set gys=@sn_XN_3
		where OrderCode='0303' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set gys=@sn_XN_4
		where OrderCode='0304' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set gys=@sn_ZX_1
		where OrderCode='0401' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set gys=@sn_ZX_2
		where OrderCode='0402' and MonthDate=@D_Date	
	update mms_aTypicalDaySummryCombine set gys=@sn_ZX_3
		where OrderCode='0403' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set gys=@sn_ZX_4
		where OrderCode='0404' and MonthDate=@D_Date	
end--#region3_end

	begin--#region4_begin-----------------易鑫月累计----------------------------------	
	set @sn_XN_1 =0
	set @sn_XN_2 =0
	set @sn_XN_3 =0
	set @sn_XN_4 =0
	set @sn_ZX_1 =0
	set @sn_ZX_2 =0
	set @sn_ZX_3 =0
	set @sn_ZX_4 =0
	set @yk_sn =0
	set @yk_sn1 =0
	set @yk_sn2 =0		
	select @sn_XN_1=SUM(a.Sn_XN_1), @sn_XN_3=sum(a.Sn_XN_3), @sn_ZX_1=sum(a.Sn_ZX_1), @sn_ZX_3=sum(a.Sn_ZX_3) 
		from mms_afmPlantRun b inner join mms_aReportDay_T2 a
			on a.R_Date=b.run_date and a.R_CID=b.classid
		where a.R_Date <=@D_Date and a.R_Date >=@StartDateTime and b.minewherefrom='易鑫矿'
	if(@sn_XN_1=0)
		set @sn_XN_2=0
	else
		set @sn_XN_2 =100*@sn_XN_3/@sn_XN_1

	if(@sn_ZX_1=0)
		set @sn_ZX_2=0
	else
		set @sn_ZX_2 =100*@sn_ZX_3/@sn_ZX_1

	select @yk_sn1 =SUM(yk_9) 
		from mms_afmPlantRun b inner join mms_aReportDay_T1 a
			on a.R_Date=b.run_date and a.R_CID=b.classid 
		where R_Date <=@D_Date and R_Date >=@StartDateTime and b.minewherefrom='易鑫矿'

	select @yk_sn2 =SUM(yk_9) 
		from mms_afmPlantRun2 b inner join mms_aReportDay2_T1 a
			on a.R_Date=b.run_date and a.R_CID=b.classid 
		where R_Date <=@D_Date and R_Date >=@StartDateTime and b.minewherefrom='易鑫矿'	
	set @yk_sn = @yk_sn1+@yk_sn2
	
	if (@yk_sn =0)
		begin
			set @sn_XN_4 =0
			set @sn_ZX_4 =0
		end
	else 
		begin
			
			set @sn_XN_4 =100*@sn_XN_3/@yk_sn
			set @sn_ZX_4 =100*@sn_ZX_3/@yk_sn
		end
	update mms_aTypicalDaySummryCombine set yx=@sn_XN_1
		where OrderCode='0301' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set yx=@sn_XN_2
		where OrderCode='0302' and MonthDate=@D_Date	
	update mms_aTypicalDaySummryCombine set yx=@sn_XN_3
		where OrderCode='0303' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set yx=@sn_XN_4
		where OrderCode='0304' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set yx=@sn_ZX_1
		where OrderCode='0401' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set yx=@sn_ZX_2
		where OrderCode='0402' and MonthDate=@D_Date	
	update mms_aTypicalDaySummryCombine set yx=@sn_ZX_3
		where OrderCode='0403' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set yx=@sn_ZX_4
		where OrderCode='0404' and MonthDate=@D_Date	
end--#region4_end

	begin--#region4_begin-----------------宏发矿 月累计----------------------------------	
	set @sn_XN_1 =0
	set @sn_XN_2 =0
	set @sn_XN_3 =0
	set @sn_XN_4 =0
	set @sn_ZX_1 =0
	set @sn_ZX_2 =0
	set @sn_ZX_3 =0
	set @sn_ZX_4 =0
	set @yk_sn =0
	set @yk_sn1 =0
	set @yk_sn2 =0		
	select @sn_XN_1=SUM(a.Sn_XN_1), @sn_XN_3=sum(a.Sn_XN_3), @sn_ZX_1=sum(a.Sn_ZX_1), @sn_ZX_3=sum(a.Sn_ZX_3) 
		from mms_afmPlantRun b inner join mms_aReportDay_T2 a
			on a.R_Date=b.run_date and a.R_CID=b.classid
		where a.R_Date <=@D_Date and a.R_Date >=@StartDateTime and b.minewherefrom='宏发矿'
	if(@sn_XN_1=0)
		set @sn_XN_2=0
	else
		set @sn_XN_2 =100*@sn_XN_3/@sn_XN_1

	if(@sn_ZX_1=0)
		set @sn_ZX_2=0
	else
		set @sn_ZX_2 =100*@sn_ZX_3/@sn_ZX_1

	select @yk_sn1 =SUM(yk_9) 
		from mms_afmPlantRun b inner join mms_aReportDay_T1 a
			on a.R_Date=b.run_date and a.R_CID=b.classid 
		where R_Date <=@D_Date and R_Date >=@StartDateTime and b.minewherefrom='宏发矿'
	select @yk_sn2 =SUM(yk_9) 
		from mms_afmPlantRun2 b inner join mms_aReportDay2_T1 a
			on a.R_Date=b.run_date and a.R_CID=b.classid 
		where R_Date <=@D_Date and R_Date >=@StartDateTime and b.minewherefrom='宏发矿'	
	set @yk_sn = @yk_sn1+@yk_sn2
		
	if (@yk_sn =0)
		begin
			set @sn_XN_4 =0
			set @sn_ZX_4 =0
		end
	else 
		begin
			
			set @sn_XN_4 =100*@sn_XN_3/@yk_sn
			set @sn_ZX_4 =100*@sn_ZX_3/@yk_sn
		end
	update mms_aTypicalDaySummryCombine set hf=@sn_XN_1
		where OrderCode='0301' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set hf=@sn_XN_2
		where OrderCode='0302' and MonthDate=@D_Date	
	update mms_aTypicalDaySummryCombine set hf=@sn_XN_3
		where OrderCode='0303' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set hf=@sn_XN_4
		where OrderCode='0304' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set hf=@sn_ZX_1
		where OrderCode='0401' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set hf=@sn_ZX_2
		where OrderCode='0402' and MonthDate=@D_Date	
	update mms_aTypicalDaySummryCombine set hf=@sn_ZX_3
		where OrderCode='0403' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set hf=@sn_ZX_4
		where OrderCode='0404' and MonthDate=@D_Date	
end--#region4_end

end

if(@D_Mode=2)
begin
	declare @snZX_Class0_W DECIMAL(18,4) =0
	declare @snZX_Class8_W DECIMAL(18,4) =0
	declare @snZX_Class16_W DECIMAL(18,4) =0
	declare @snXN_W DECIMAL(18,4) =0
	select @snXN_W=snXN,
			@snZX_Class0_W=snZX_class0,
			@snZX_Class8_W=snZX_class8,
			@snZX_Class16_W=snZX_class16
	  from mms_afmWeightSn where snw_date =@D_Date
	update mms_aTypicalDaySummryCombine set NightClass=@snXN_W
		where OrderCode='0301' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set MoringClass=0
		where OrderCode='0301' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set MiddleClass=0
		where OrderCode='0301' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set NightClass=@snZX_Class0_W
		where OrderCode='0401' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set MoringClass=@snZX_Class8_W
		where OrderCode='0401' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set MiddleClass=@snZX_Class16_W
		where OrderCode='0401' and MonthDate=@D_Date
end

if(@D_Mode=3)
begin
	declare @snZX_Class0_Q DECIMAL(18,4) =0
	declare @snZX_Class8_Q DECIMAL(18,4) =0
	declare @snZX_Class16_Q DECIMAL(18,4) =0
	declare @snXN_Q DECIMAL(18,4) =0
		select @snXN_Q=snXN,
			@snZX_Class0_Q=SnZX_0class,
			@snZX_Class8_Q=snZX_8class,
			@snZX_Class16_Q=snZX_16class		
		from mms_afmLaboratorySheetSn where ls_Date =@D_Date 
		
	update mms_aTypicalDaySummryCombine set NightClass=@snXN_Q
		where OrderCode='0302' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set MoringClass=0
		where OrderCode='0302' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set MiddleClass=0
		where OrderCode='0302' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set NightClass=@snZX_Class0_Q
		where OrderCode='0402' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set MoringClass=@snZX_Class8_Q
		where OrderCode='0402' and MonthDate=@D_Date
	update mms_aTypicalDaySummryCombine set MiddleClass=@snZX_Class16_Q
		where OrderCode='0402' and MonthDate=@D_Date	
end
go

