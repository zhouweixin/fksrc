CREATE procedure [dbo].[proc_aReportDay_P1]
@ClassDate date =null,
@ClassID nvarchar(50) ='',
@M_Mode int =null
as
-----条件判断变量----------
declare @Run_HandlingCapacity int =null
declare @SheetA_Class int =null
declare @SheetB_Class int =null

--------运行情况数据变量----------
declare @HandlingCapacity_Class DECIMAL(18,4)
--------班组化验A数据变量--------------------
declare @yk_pb_A DECIMAL(18,4) =0
declare @yk_sn_A DECIMAL(18,4) =0
declare @yk_sb_A DECIMAL(18,4) =0
declare @yk_zn_A DECIMAL(18,4) =0
declare @pb_pb_A DECIMAL(18,4) =0
declare @pb_sb_A DECIMAL(18,4) =0
declare @pbw_pb_A DECIMAL(18,4) =0
declare @WhereFrom_A nvarchar(50) =''
declare @self23_A nvarchar(50) =''
declare @Laboraorian_A nvarchar(50) =''
--------班组化验B数据变量--------------------
declare @wherefrom_B nvarchar(50) =''
declare @laboratorian_B nvarchar(50) =''
declare @self23_B nvarchar(50) =''
declare @yk_pb_B DECIMAL(18,4) =0
declare @yk_sn_B DECIMAL(18,4) =0
declare @yk_sb_B DECIMAL(18,4) =0
declare @yk_s_B DECIMAL(18,4) =0
declare @yk_zn_B DECIMAL(18,4) =0
declare @pb_pb_B DECIMAL(18,4) =0
declare @pb_s_B DECIMAL(18,4) =0
declare @pb_sb_B DECIMAL(18,4) =0
declare @pb_zn_B DECIMAL(18,4) =0
declare @zn_pb_B DECIMAL(18,4) =0
declare @zn_zn_B DECIMAL(18,4) =0
declare @zn_s_B DECIMAL(18,4) =0
declare @s_pb_B DECIMAL(18,4) =0
declare @s_zn_B DECIMAL(18,4) =0
declare @s_s_B DECIMAL(18,4) =0
declare @znswk_pb_B DECIMAL(18,4) =0
declare @znswk_zn_B DECIMAL(18,4) =0
declare @znswk_sn_B DECIMAL(18,4) =0
declare @znswk_s_B DECIMAL(18,4) =0
declare @znswk_sb_B DECIMAL(18,4) =0
---------------计算变量,原矿------------------------------------
declare @YK_Metallicity_pb DECIMAL(18,4) =0
declare @YK_Metallicity_zn DECIMAL(18,4) =0
declare @YK_Metallicity_sn DECIMAL(18,4) =0
declare @YK_Metallicity_sb DECIMAL(18,4) =0
---------------计算变量,铅锑精矿------------------------------------
declare @PbSb_Weight DECIMAL(18,4) =0
declare @PbSb_Quota_Pb DECIMAL(18,4) =0
declare @PbSb_Quota_Sb DECIMAL(18,4) =0
declare @PbSb_Metallicity_Pb DECIMAL(18,4) =0
declare @PbSb_Metallicity_Sb DECIMAL(18,4) =0
declare @PbSb_ConcentrateRecovery_Pb DECIMAL(18,4) =0
declare @PbSb_ConcentrateRecovery_Sb DECIMAL(18,4) =0
---------------计算变量，锌精矿------------------------------------
declare @Zn_Weight DECIMAL(18,4) =0
declare @Zn_Quota_Zn DECIMAL(18,4) =0
declare @Zn_Metallicity_Zn DECIMAL(18,4) =0
declare @Zn_ConcentrateRecovery_Zn DECIMAL(18,4) =0
---------------定义更新数据变量------------------------------------
declare @yk_1 DECIMAL(18,4) =0
declare @yk_2 DECIMAL(18,4) =0
declare @yk_3 DECIMAL(18,4) =0
declare @yk_4 DECIMAL(18,4) =0
declare @yk_5 DECIMAL(18,4) =0
declare @yk_6 DECIMAL(18,4) =0
declare @yk_7 DECIMAL(18,4) =0
declare @yk_8 DECIMAL(18,4) =0
declare @yk_9 DECIMAL(18,4) =0
declare @PbSb_1 DECIMAL(18,4) =0
declare @PbSb_2 DECIMAL(18,4) =0
declare @PbSb_3 DECIMAL(18,4) =0
declare @PbSb_4 DECIMAL(18,4) =0
declare @PbSb_5 DECIMAL(18,4) =0
declare @PbSb_6 DECIMAL(18,4) =0
declare @PbSb_7 DECIMAL(18,4) =0
declare @Zn_1 DECIMAL(18,4) =0
declare @Zn_2 DECIMAL(18,4) =0
declare @Zn_3 DECIMAL(18,4) =0
declare @Zn_4 DECIMAL(18,4) =0
------------系统变量-------------------------------
declare @errString nvarchar(255)

set @Run_HandlingCapacity =(select COUNT(*) from mms_afmPlantRun where  run_date=@ClassDate and classid =@ClassID)
set @SheetA_Class =(select COUNT(*) from mms_afmLaboratorySheetA where LS_Date=@ClassDate and ClassID =@ClassID)
set @SheetB_Class =(select COUNT(*) from mms_afmLaboratorySheetB where ls_Date=@ClassDate and classid =@ClassID)
if(@SheetA_Class+@SheetB_Class + @Run_HandlingCapacity =2)
	begin
	-------------------------------------------------------
	------条件满足，获取原始数据---------------------------
	-------------------------------------------------------
		-------第一步：获取处理量---------------
		set @HandlingCapacity_Class =(select handlingCapacity from mms_afmPlantRun where run_date =@ClassDate and classid =@ClassID);
		set @yk_1 = @HandlingCapacity_Class		
		-------第二步：获取化验数据--------------------
		if(@SheetA_Class =1)
			begin
				set @yk_pb_A=(select yk_pb from mms_afmLaboratorySheetA where LS_Date =@ClassDate and ClassID =@ClassID)/100
				set @yk_zn_A=(select yk_zn from mms_afmLaboratorySheetA where LS_Date =@ClassDate and ClassID =@ClassID)/100
				set @yk_sn_A=(select yk_sn from mms_afmLaboratorySheetA where LS_Date =@ClassDate and ClassID =@ClassID)/100
				set @yk_sb_A=(select yk_sb from mms_afmLaboratorySheetA where LS_Date =@ClassDate and ClassID =@ClassID)/100
				set @pb_pb_A=(select pb_pb from mms_afmLaboratorySheetA where LS_Date =@ClassDate and ClassID =@ClassID)/100
				set @pb_sb_A=(select pb_sb from mms_afmLaboratorySheetA where LS_Date =@ClassDate and ClassID =@ClassID)/100
				set @pbw_pb_A=(select pbw_pb from mms_afmLaboratorySheetA where LS_Date =@ClassDate and ClassID =@ClassID)/100
				set @WhereFrom_A =(select wherefrom from mms_afmLaboratorySheetA where LS_Date =@ClassDate and ClassID =@ClassID)
				set @self23_A =(select self23 from mms_afmLaboratorySheetA where LS_Date =@ClassDate and ClassID =@ClassID)
				set @Laboraorian_A  =(select laboratorian from mms_afmLaboratorySheetA where LS_Date =@ClassDate and ClassID =@ClassID)
				
				set @yk_2 =@yk_pb_A*100
				set @yk_4 =@yk_zn_A*100
				set @yk_6 =@yk_sb_A*100
				set @yk_8 =@yk_sn_A*100
				set @PbSb_2 =@pb_pb_A*100
				set @PbSb_5 =@pb_sb_A*100
				set @Zn_2 =0
			end
		if( @SheetB_Class=1)
			begin
				set @yk_pb_B=(select yk_pb from mms_afmLaboratorySheetB where LS_Date =@ClassDate and ClassID =@ClassID)/100
				set @yk_sn_B =(select yk_sn from mms_afmLaboratorySheetB where LS_Date =@ClassDate and ClassID =@ClassID)/100
				set @yk_sb_B=(select yk_sb  from mms_afmLaboratorySheetB where LS_Date =@ClassDate and ClassID =@ClassID)/100
				set @yk_s_B=(select yk_s from mms_afmLaboratorySheetB where LS_Date =@ClassDate and ClassID =@ClassID)/100
				set @yk_zn_B=(select yk_zn from mms_afmLaboratorySheetB where LS_Date =@ClassDate and ClassID =@ClassID)/100
				-----------------------------------------------------------------------------------------------------
				set @pb_pb_B=(select pb_pb from mms_afmLaboratorySheetB where LS_Date =@ClassDate and ClassID =@ClassID)/100
				set @pb_s_B=(select pb_s from mms_afmLaboratorySheetB where LS_Date =@ClassDate and ClassID =@ClassID)/100
				set @pb_sb_B=(select pb_sb from mms_afmLaboratorySheetB where LS_Date =@ClassDate and ClassID =@ClassID)/100
				set @pb_zn_B=(select pb_zn from mms_afmLaboratorySheetB where LS_Date =@ClassDate and ClassID =@ClassID)/100
				----------------------------------------------------------------------------------------------------
				set @zn_pb_B=(select zn_pb from mms_afmLaboratorySheetB where LS_Date =@ClassDate and ClassID =@ClassID)/100
				set @zn_zn_B=(select zn_zn from mms_afmLaboratorySheetB where LS_Date =@ClassDate and ClassID =@ClassID)/100
				set @zn_s_B=(select zn_s from mms_afmLaboratorySheetB where LS_Date =@ClassDate and ClassID =@ClassID)/100
				----------------------------------------------------------------------------------------------------
				set @s_pb_B=(select s_pb from mms_afmLaboratorySheetB where LS_Date =@ClassDate and ClassID =@ClassID)/100
				set @s_zn_B=(select s_zn from mms_afmLaboratorySheetB where LS_Date =@ClassDate and ClassID =@ClassID)/100
				set @s_s_B=(select s_s from mms_afmLaboratorySheetB where LS_Date =@ClassDate and ClassID =@ClassID)/100
				----------------------------------------------------------------------------------------------------
				set @znswk_pb_B=(select znswk_pb from mms_afmLaboratorySheetB where LS_Date =@ClassDate and ClassID =@ClassID)/100
				set @znswk_zn_B=(select znswk_zn from mms_afmLaboratorySheetB where LS_Date =@ClassDate and ClassID =@ClassID)/100
				set @znswk_sn_B=(select znswk_sn from mms_afmLaboratorySheetB where LS_Date =@ClassDate and ClassID =@ClassID)/100
				set @znswk_s_B=(select znswk_s from mms_afmLaboratorySheetB where LS_Date =@ClassDate and ClassID =@ClassID)/100
				set @znswk_sb_B=(select znswk_sb from mms_afmLaboratorySheetB where LS_Date =@ClassDate and ClassID =@ClassID)/100
				----------------------------------------------------------------------------------------------------
				set @self23_B=(select self23 from mms_afmLaboratorySheetB where LS_Date =@ClassDate and ClassID =@ClassID)
				set @laboratorian_B=(select laboratorian from mms_afmLaboratorySheetB where LS_Date =@ClassDate and ClassID =@ClassID)
				set @wherefrom_B=(select wherefrom from mms_afmLaboratorySheetB where LS_Date =@ClassDate and ClassID =@ClassID)
				
				set @yk_2 =@yk_pb_B*100
				set @yk_4 =@yk_zn_B*100
				set @yk_6 =@yk_sb_B*100
				set @yk_8 =@yk_sn_B*100
				set @PbSb_2 =@pb_pb_B*100
				set @PbSb_5 =@pb_sb_B*100
				set @Zn_2 =@zn_zn_B*100
			end
	-------------------------------------------------------
	------获取原始数据后，进行其它变量计算---------------------------
	-------------------------------------------------------
		---------第一步：计算非锡数据------------------------------
		if(@SheetA_Class =1)
			begin
				----------原矿段计算数据---------------------------------------
				set @YK_Metallicity_pb=@HandlingCapacity_Class *@yk_pb_A
				set @YK_Metallicity_zn=@HandlingCapacity_Class *@yk_zn_A
				set @YK_Metallicity_sn=@HandlingCapacity_Class *@yk_sn_A
				set @YK_Metallicity_sb=@HandlingCapacity_Class *@yk_sb_A			

				----------铅锑精矿段计算数据---------------------------------------
				----------理论回收率 = β(α-θ) / α(β-θ) × 100%---------------------
				----------化验原矿品位(α)精矿品位(β)和尾矿品位(θ)----------------
				declare @temp1 DECIMAL(18,4)=0
				declare @temp2 DECIMAL(18,4)=0
				set @temp1=@pb_pb_A*(@yk_pb_A-@pbw_pb_A)
				set @temp2=@yk_pb_A*(@pb_pb_A-@pbw_pb_A)
				---------计算顺序：铅回收率--》铅金属量--》精矿重量--》锑金属量--》锑回收率
				set @PbSb_Quota_Pb =@pb_pb_A
				set @PbSb_Quota_Sb =@pb_sb_A
				if(@temp2=0)
					set @PbSb_ConcentrateRecovery_Pb =0
				else
					set @PbSb_ConcentrateRecovery_Pb =@temp1/@temp2
					
				set @PbSb_Metallicity_Pb =@PbSb_ConcentrateRecovery_Pb*@YK_Metallicity_pb
				
				if(@PbSb_Quota_Pb=0)
					set @PbSb_Weight =0
				else 
					set @PbSb_Weight =@PbSb_Metallicity_Pb/@PbSb_Quota_Pb
					
				set @PbSb_Metallicity_Sb=@PbSb_Weight*@PbSb_Quota_Sb
				
				if(@YK_Metallicity_sb=0)
					set @PbSb_ConcentrateRecovery_Sb=0
				else
					set @PbSb_ConcentrateRecovery_Sb=@PbSb_Metallicity_Sb/@YK_Metallicity_sb
				

				----------锌精矿段计算数据---------空------------------------------
				set @Zn_1 =0
				set @Zn_3 =0
				set @Zn_4 =0
			end
		if(@SheetB_Class =1)
			begin
				----------原矿段计算数据---------------------------------------
				set @YK_Metallicity_pb=@HandlingCapacity_Class *@yk_pb_B
				set @YK_Metallicity_zn=@HandlingCapacity_Class *@yk_zn_B
				set @YK_Metallicity_sn=@HandlingCapacity_Class *@yk_sn_B
				set @YK_Metallicity_sb=@HandlingCapacity_Class *@yk_sb_B
				----------铅锑精矿段计算数据---------------------------------------
				-------------理论回收率,见质检部excel文档。声明中间变量---------------------
				declare @temp_a_1 DECIMAL(18,4)=0
				declare @temp_a_2 DECIMAL(18,4)=0
				declare @temp_a_3 DECIMAL(18,4)=0
				declare @temp_a_4 DECIMAL(18,4)=0
				declare @temp_b_1 DECIMAL(18,4)=0
				declare @temp_b_2 DECIMAL(18,4)=0
				declare @temp_b_3 DECIMAL(18,4)=0
				declare @temp_b_4 DECIMAL(18,4)=0				
				declare @temp_c_1 DECIMAL(18,4)=0
				declare @temp_c_2 DECIMAL(18,4)=0
				declare @temp_c_3 DECIMAL(18,4)=0
				declare @temp_c_4 DECIMAL(18,4)=0				
				
				declare @temp_d_1 DECIMAL(18,4)=0
				declare @temp_d_2 DECIMAL(18,4)=0
				declare @temp_d_3 DECIMAL(18,4)=0
				declare @temp_e_1 DECIMAL(18,4)=0
				declare @temp_e_2 DECIMAL(18,4)=0
				declare @temp_e_3 DECIMAL(18,4)=0
				declare @temp_f_1 DECIMAL(18,4)=0
				declare @temp_f_2 DECIMAL(18,4)=0
				declare @temp_f_3 DECIMAL(18,4)=0
				
				declare @temp_g_1 DECIMAL(18,4)=0
				declare @temp_g_2 DECIMAL(18,4)=0
				declare @temp_h_1 DECIMAL(18,4)=0
				declare @temp_h_2 DECIMAL(18,4)=0

				declare @temp_m DECIMAL(18,4)=0
				declare @temp_n DECIMAL(18,4)=0
				
				declare @temp_X DECIMAL(18,4)=0
				----------计算步骤，获取铅回收率----------------------
				set @temp_a_1 =@pb_pb_B - @znswk_pb_B
				set @temp_a_2 =@zn_pb_B - @znswk_pb_B
				set @temp_a_3 =@s_pb_B - @znswk_pb_B
				set @temp_a_4 =100*(@yk_pb_B - @znswk_pb_B)
				
				set @temp_b_1 =@pb_zn_B -@znswk_zn_B
				set @temp_b_2 =@zn_zn_B -@znswk_zn_B
				set @temp_b_3 =@s_zn_B -@znswk_zn_B
				set @temp_b_4 =100*(@yk_zn_B -@znswk_zn_B)
				
				set @temp_c_1 =@pb_s_B -@znswk_s_B
				set @temp_c_2 =@zn_s_B -@znswk_s_B
				set @temp_c_3 =@s_s_B -@znswk_s_B
				set @temp_c_4 =100*(@yk_s_B -@znswk_s_B)
				
				if(@temp_a_1=0)
					begin
						set @temp_d_1 =0
						set @temp_d_2 =0
						set @temp_d_3 =0
					end
				else
					begin
						set @temp_d_1 =@temp_a_2 / @temp_a_1
						set @temp_d_2 =@temp_a_3 / @temp_a_1
						set @temp_d_3 =@temp_a_4 / @temp_a_1
					end
				set @temp_e_1 =@temp_b_2 - @temp_d_1*@temp_b_1
				set @temp_e_2 =@temp_b_3 - @temp_d_2*@temp_b_1
				set @temp_e_3 =@temp_b_4 - @temp_d_3*@temp_b_1
				
				set @temp_f_1 =@temp_c_2 - @temp_d_1*@temp_c_1
				set @temp_f_2 =@temp_c_3 - @temp_d_2*@temp_c_1
				set @temp_f_3 =@temp_c_4 - @temp_d_3*@temp_c_1
				
				if(@temp_e_1=0)
					begin
						set @temp_g_1 =0
						set @temp_g_2 =0				
					end
				else
					begin
						set @temp_g_1 =@temp_e_2 / @temp_e_1
						set @temp_g_2 =@temp_e_3 / @temp_e_1
					end
				set @temp_h_1 =@temp_f_2 - @temp_g_1*@temp_f_1
				set @temp_h_2 =@temp_f_3 - @temp_g_2*@temp_f_1
				
				if(@temp_h_1=0)
					set @temp_m =0
				else				
					set @temp_m =@temp_h_2 / @temp_h_1
				
				set @temp_n =@temp_g_2 - @temp_m*@temp_g_1
				
				set @temp_X =@temp_d_3 -@temp_d_1*@temp_n -@temp_d_2*@temp_m				
				---------计算顺序：铅回收率,锌回收率---------------------------------------------------
				set @PbSb_ConcentrateRecovery_Pb =@temp_X*@pb_pb_B/nullif(@yk_pb_B,0)
				set @Zn_ConcentrateRecovery_Zn =@temp_n*@zn_zn_B /nullif(@yk_zn_B,0)
					
				set @PbSb_ConcentrateRecovery_Pb =@PbSb_ConcentrateRecovery_Pb/100
				set @Zn_ConcentrateRecovery_Zn =@Zn_ConcentrateRecovery_Zn/100				
				---------铅精矿段计算-----------------------------------------------------------------
				set @PbSb_Quota_Pb =@pb_pb_B
				set @PbSb_Quota_Sb =@pb_sb_B
				set @PbSb_Metallicity_Pb =@PbSb_ConcentrateRecovery_Pb*@YK_Metallicity_pb
				if(@PbSb_Quota_Pb=0)
					set @PbSb_Weight =0
				else
					set @PbSb_Weight =@PbSb_Metallicity_Pb/@PbSb_Quota_Pb
					
				set @PbSb_Metallicity_Sb=@PbSb_Weight*@PbSb_Quota_Sb
				
				if(@YK_Metallicity_sb=0)
					set @PbSb_ConcentrateRecovery_Sb=0
				else
					set @PbSb_ConcentrateRecovery_Sb=@PbSb_Metallicity_Sb/@YK_Metallicity_sb
				----------锌精矿段计算数据--------------------------------------
				set @Zn_Quota_Zn =@zn_zn_B
				set @Zn_Metallicity_Zn =@Zn_ConcentrateRecovery_Zn*@YK_Metallicity_zn
				
				if(@Zn_Quota_Zn=0)
					set @Zn_Weight =0
				else
					set @Zn_Weight =@Zn_Metallicity_Zn /@Zn_Quota_Zn
				
				set @Zn_1 =@Zn_Weight
				set @Zn_3 =@Zn_Metallicity_Zn
				set @Zn_4 =@Zn_ConcentrateRecovery_Zn*100
			end
			
	------------获取班组完整数据更新T1,T7-------------
				set @yk_3 =@YK_Metallicity_pb
				set @yk_5 =@YK_Metallicity_zn
				set @yk_7 =@YK_Metallicity_sb
				set @yk_9 =@YK_Metallicity_sn
				
				set @PbSb_1 =@PbSb_Weight
				set @PbSb_3 =@PbSb_Metallicity_Pb
				set @PbSb_4 =@PbSb_ConcentrateRecovery_Pb*100
				set @PbSb_6 =@PbSb_Metallicity_Sb
				set @PbSb_7 =@PbSb_ConcentrateRecovery_Sb*100
				
		declare @temp_Cols int =0
		if(@ClassID ='早班')
			set @temp_Cols =1
		if(@ClassID ='中班')
			set @temp_Cols =2
		if(@ClassID ='晚班')
			set @temp_Cols =3
			
		if (@M_Mode =1) ---插入模式
			begin
				insert into mms_aReportDay_T1 (R_Date ,R_CID ,
				YK_1 ,YK_2,YK_3,YK_4,YK_5,YK_6,YK_7,YK_8,YK_9,
				PbSb_1,PbSb_2,PbSb_3,PbSb_4,PbSb_5,PbSb_6,PbSb_7,
				Zn_1,Zn_2,Zn_3,Zn_4) 
				values(
				@ClassDate,@ClassID,@yk_1,@yk_2,@yk_3,@yk_4,@yk_5,@yk_6,@yk_7,@yk_8,@yk_9,
				@PbSb_1,@PbSb_2,@PbSb_3,@PbSb_4,@PbSb_5,@PbSb_6,@PbSb_7,
				@Zn_1,	@Zn_2,	@Zn_3,@Zn_4	)
				
				insert into mms_aReportDay_T7 (ReportDate ,R_Rows ,R_Cols ,ReportValue) 	values(@ClassDate,1,@temp_Cols,@yk_1)
				insert into mms_aReportDay_T7 (ReportDate ,R_Rows ,R_Cols ,ReportValue) 	values(@ClassDate,2,@temp_Cols,@yk_2)
				insert into mms_aReportDay_T7 (ReportDate ,R_Rows ,R_Cols ,ReportValue) 	values(@ClassDate,3,@temp_Cols,@yk_3)
				insert into mms_aReportDay_T7 (ReportDate ,R_Rows ,R_Cols ,ReportValue) 	values(@ClassDate,4,@temp_Cols,@yk_4)
				insert into mms_aReportDay_T7 (ReportDate ,R_Rows ,R_Cols ,ReportValue) 	values(@ClassDate,5,@temp_Cols,@yk_5)
				insert into mms_aReportDay_T7 (ReportDate ,R_Rows ,R_Cols ,ReportValue) 	values(@ClassDate,6,@temp_Cols,@yk_6)
				insert into mms_aReportDay_T7 (ReportDate ,R_Rows ,R_Cols ,ReportValue) 	values(@ClassDate,7,@temp_Cols,@yk_7)
				insert into mms_aReportDay_T7 (ReportDate ,R_Rows ,R_Cols ,ReportValue) 	values(@ClassDate,8,@temp_Cols,@yk_8)
				insert into mms_aReportDay_T7 (ReportDate ,R_Rows ,R_Cols ,ReportValue) 	values(@ClassDate,9,@temp_Cols,@yk_9)
				insert into mms_aReportDay_T7 (ReportDate ,R_Rows ,R_Cols ,ReportValue) 	values(@ClassDate,10,@temp_Cols,@PbSb_1)
				insert into mms_aReportDay_T7 (ReportDate ,R_Rows ,R_Cols ,ReportValue) 	values(@ClassDate,11,@temp_Cols,@PbSb_2)
				insert into mms_aReportDay_T7 (ReportDate ,R_Rows ,R_Cols ,ReportValue) 	values(@ClassDate,12,@temp_Cols,@PbSb_3)
				insert into mms_aReportDay_T7 (ReportDate ,R_Rows ,R_Cols ,ReportValue) 	values(@ClassDate,13,@temp_Cols,@PbSb_4)
				insert into mms_aReportDay_T7 (ReportDate ,R_Rows ,R_Cols ,ReportValue) 	values(@ClassDate,14,@temp_Cols,@PbSb_5)
				insert into mms_aReportDay_T7 (ReportDate ,R_Rows ,R_Cols ,ReportValue) 	values(@ClassDate,15,@temp_Cols,@PbSb_6)
				insert into mms_aReportDay_T7 (ReportDate ,R_Rows ,R_Cols ,ReportValue) 	values(@ClassDate,16,@temp_Cols,@PbSb_7)
				insert into mms_aReportDay_T7 (ReportDate ,R_Rows ,R_Cols ,ReportValue) 	values(@ClassDate,17,@temp_Cols,@Zn_1)
				insert into mms_aReportDay_T7 (ReportDate ,R_Rows ,R_Cols ,ReportValue) 	values(@ClassDate,18,@temp_Cols,@Zn_2)
				insert into mms_aReportDay_T7 (ReportDate ,R_Rows ,R_Cols ,ReportValue) 	values(@ClassDate,19,@temp_Cols,@Zn_3)
				insert into mms_aReportDay_T7 (ReportDate ,R_Rows ,R_Cols ,ReportValue) 	values(@ClassDate,20,@temp_Cols,@Zn_4)
			end
		if(@M_Mode =2)  ---更新模式
			begin
				update mms_aReportDay_T1 
				set		YK_1 =@HandlingCapacity_Class,
						YK_2 =@yk_2,
						YK_3 =@yk_3,
						YK_4 =@yk_4,
						YK_5 =@yk_5,
						YK_6 =@yk_6,
						YK_7 =@yk_7,
						YK_8 =@yk_8,
						YK_9 =@yk_9,
						PbSb_1 =@PbSb_1,
						PbSb_2 =@PbSb_2,
						PbSb_3 =@PbSb_3,
						PbSb_4 =@PbSb_4,
						PbSb_5 =@PbSb_5,
						PbSb_6 =@PbSb_6,
						PbSb_7 =@PbSb_7,
						Zn_1=@Zn_1,
						Zn_2=@Zn_2,
						Zn_3=@Zn_3,
						Zn_4=@Zn_4
				where R_date=@ClassDate and R_CID =@ClassID
				
				update mms_aReportDay_T7
					set ReportValue =@yk_1 				
				where ReportDate =@ClassDate and R_Rows =1 and R_Cols =@temp_Cols				
				update mms_aReportDay_T7
					set ReportValue =@yk_2 				
				where ReportDate =@ClassDate and R_Rows =2 and R_Cols=@temp_Cols
				update mms_aReportDay_T7
					set ReportValue =@yk_3 				
				where ReportDate =@ClassDate and R_Rows =3 and R_Cols=@temp_Cols
				update mms_aReportDay_T7
					set ReportValue =@yk_4 				
				where ReportDate =@ClassDate and R_Rows =4 and R_Cols=@temp_Cols
				update mms_aReportDay_T7
					set ReportValue =@yk_5 				
				where ReportDate =@ClassDate and R_Rows =5 and R_Cols=@temp_Cols
				update mms_aReportDay_T7
					set ReportValue =@yk_6 				
				where ReportDate =@ClassDate and R_Rows =6 and R_Cols=@temp_Cols
				update mms_aReportDay_T7
					set ReportValue =@yk_7 				
				where ReportDate =@ClassDate and R_Rows =7 and R_Cols=@temp_Cols
				update mms_aReportDay_T7
					set ReportValue =@yk_8 				
				where ReportDate =@ClassDate and R_Rows =8 and R_Cols=@temp_Cols
				update mms_aReportDay_T7
					set ReportValue =@yk_9 
				where ReportDate =@ClassDate and R_Rows =9 and R_Cols=@temp_Cols
				update mms_aReportDay_T7
					set ReportValue =@PbSb_1 
				where ReportDate =@ClassDate and R_Rows =10 and R_Cols=@temp_Cols
				update mms_aReportDay_T7
					set ReportValue =@PbSb_2 
				where ReportDate =@ClassDate and R_Rows =11 and R_Cols=@temp_Cols
				update mms_aReportDay_T7
					set ReportValue =@PbSb_3 
				where ReportDate =@ClassDate and R_Rows =12 and R_Cols=@temp_Cols
				update mms_aReportDay_T7
					set ReportValue =@PbSb_4 
				where ReportDate =@ClassDate and R_Rows =13 and R_Cols=@temp_Cols
				update mms_aReportDay_T7
					set ReportValue =@PbSb_5 
				where ReportDate =@ClassDate and R_Rows =14 and R_Cols=@temp_Cols
				update mms_aReportDay_T7
					set ReportValue =@PbSb_6 
				where ReportDate =@ClassDate and R_Rows =15 and R_Cols=@temp_Cols
				update mms_aReportDay_T7
					set ReportValue =@PbSb_7 
				where ReportDate =@ClassDate and R_Rows =16 and R_Cols=@temp_Cols
				update mms_aReportDay_T7
					set ReportValue =@Zn_1 
				where ReportDate =@ClassDate and R_Rows =17 and R_Cols=@temp_Cols
				update mms_aReportDay_T7
					set ReportValue =@Zn_2 
				where ReportDate =@ClassDate and R_Rows =18 and R_Cols=@temp_Cols
				update mms_aReportDay_T7
					set ReportValue =@Zn_3
				where ReportDate =@ClassDate and R_Rows =19 and R_Cols=@temp_Cols
				update mms_aReportDay_T7
					set ReportValue =@Zn_4 
				where ReportDate =@ClassDate and R_Rows =20 and R_Cols=@temp_Cols
			end
	end	
			
if(@M_Mode =3)  ---删除模式
	begin
		if(@SheetA_Class+@SheetB_Class + @Run_HandlingCapacity =0)
			begin
				delete from mms_aReportDay_T1 where R_date=@ClassDate and R_CID =@ClassID
				delete from mms_aReportDay_T7 where ReportDate =@ClassDate  and R_Cols=1 and R_Rows between 1 and 20
			end
	end

go

