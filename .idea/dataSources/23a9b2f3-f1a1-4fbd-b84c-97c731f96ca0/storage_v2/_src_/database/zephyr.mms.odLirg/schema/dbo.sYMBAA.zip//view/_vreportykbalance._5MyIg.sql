CREATE VIEW dbo._VReportYKBalance
AS
SELECT     TOP (100) PERCENT tt1.C_Name AS WhereFrom, tt2.C_Name AS Unit, r1.ReportValue AS Q1, r2.ReportValue AS Q2, r3.ReportValue AS Q3, r4.ReportValue AS Q4, r5.ReportValue AS Q5, 
                      r6.ReportValue AS Q6, r1.ReportDate AS MonthDate, r1.R_Rows AS OrderCode
FROM         (SELECT     R_Rows, ReportValue, ReportDate
                       FROM          dbo.mms_aReportYKBalance_T7
                       WHERE      (R_Cols = 1)) AS r1 INNER JOIN
                          (SELECT     R_Rows, C_Name
                            FROM          dbo.mms_aReportYKBalance_TT
                            WHERE      (R_Cols = 1)) AS tt1 ON r1.R_Rows = tt1.R_Rows INNER JOIN
                          (SELECT     R_Rows, C_Name
                            FROM          dbo.mms_aReportYKBalance_TT AS mms_aReportYKBalance_TT_2
                            WHERE      (R_Cols = 2)) AS tt2 ON r1.R_Rows = tt2.R_Rows INNER JOIN
                          (SELECT     R_Rows, ReportValue, ReportDate
                            FROM          dbo.mms_aReportYKBalance_T7 AS mms_aReportYKBalance_T7_6
                            WHERE      (R_Cols = 2)) AS r2 ON r1.R_Rows = r2.R_Rows AND r1.ReportDate = r2.ReportDate INNER JOIN
                          (SELECT     R_Rows, ReportValue, ReportDate
                            FROM          dbo.mms_aReportYKBalance_T7 AS mms_aReportYKBalance_T7_5
                            WHERE      (R_Cols = 3)) AS r3 ON r1.R_Rows = r3.R_Rows AND r1.ReportDate = r3.ReportDate INNER JOIN
                          (SELECT     R_Rows, ReportValue, ReportDate
                            FROM          dbo.mms_aReportYKBalance_T7 AS mms_aReportYKBalance_T7_4
                            WHERE      (R_Cols = 4)) AS r4 ON r1.R_Rows = r4.R_Rows AND r1.ReportDate = r4.ReportDate INNER JOIN
                          (SELECT     R_Rows, ReportValue, ReportDate
                            FROM          dbo.mms_aReportYKBalance_T7 AS mms_aReportYKBalance_T7_3
                            WHERE      (R_Cols = 5)) AS r5 ON r1.R_Rows = r5.R_Rows AND r1.ReportDate = r5.ReportDate INNER JOIN
                          (SELECT     R_Rows, ReportValue, ReportDate
                            FROM          dbo.mms_aReportYKBalance_T7 AS mms_aReportYKBalance_T7_2
                            WHERE      (R_Cols = 6)) AS r6 ON r1.R_Rows = r6.R_Rows AND r1.ReportDate = r6.ReportDate
ORDER BY OrderCode
go

