CREATE trigger [dbo].[Trig_forYKBalance_Insert] on [dbo].[mms_afmYkWeightList]
for insert,update
as
declare @L_date date =null 
declare @did nvarchar(50) =''
select @L_date=wl_date ,@did=ID from inserted

BEGIN TRANSACTION
--强制执行下列语句，保证业务规则
UPDATE mms_afmYkWeightList
SET g1g2_dif = g1w3 - g2w3
WHERE ID  = @did
COMMIT TRANSACTION
exec proc_aReportYKBalance @L_date
go

