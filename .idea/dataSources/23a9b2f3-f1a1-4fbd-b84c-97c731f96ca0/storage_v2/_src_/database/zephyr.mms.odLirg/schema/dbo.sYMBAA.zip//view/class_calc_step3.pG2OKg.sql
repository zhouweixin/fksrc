CREATE VIEW dbo.Class_Calc_Step3
AS
SELECT     s2date AS s3date, s2c1 AS s3c1, 100 * Pb_Pb_JSL / YK_Pb_JSL AS HSL_Pb, 100 * Zn_Zn_JSL / YK_Zn_JSL AS HSL_Zn, 1000 * Pb_Ag_JSL / YK_Ag_JSL AS HSL_Ag
FROM         dbo.Class_Calc_Step2
go

