CREATE VIEW dbo._VDosingValue
AS
SELECT     TOP (100) PERCENT DosingLocation_ID, AccValue, Timestampe, DosingLocation, MedicamentType
FROM         (SELECT     dbo.mms_afmDosing.ID, dbo.mms_afmDosing.DosingLocation_ID, dbo.mms_afmDosing.AccValue, dbo.mms_afmDosing.Timestampe, dbo.mms_afmDosingLocation.DosingLocation, 
                                              dbo.mms_afmMedicamentType.MedicamentType
                       FROM          dbo.mms_afmDosing LEFT OUTER JOIN
                                              dbo.mms_afmDosingLocation ON dbo.mms_afmDosing.DosingLocation_ID = dbo.mms_afmDosingLocation.DosingLocation_ID LEFT OUTER JOIN
                                              dbo.mms_afmMedicamentType ON dbo.mms_afmDosingLocation.MedicamentType_ID = dbo.mms_afmMedicamentType.MedicamentType_ID) AS a
go

