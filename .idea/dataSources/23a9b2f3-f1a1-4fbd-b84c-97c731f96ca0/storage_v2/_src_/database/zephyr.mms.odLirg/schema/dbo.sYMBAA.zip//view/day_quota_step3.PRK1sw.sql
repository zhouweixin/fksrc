CREATE VIEW dbo.Day_Quota_Step3
AS
SELECT     dbo.Day_Quota_Step1.day_date, 100 * dbo.Day_Quota_Step2.day_WK_Pb_JSL / dbo.Day_Quota_Step1.day_Wk_ZL AS day_WK_Pb_PW, 
                      100 * dbo.Day_Quota_Step2.day_WK_Zn_JSL / dbo.Day_Quota_Step1.day_Wk_ZL AS day_WK_Zn_PW, 
                      1000 * dbo.Day_Quota_Step2.day_WK_Ag_JSL / dbo.Day_Quota_Step1.day_Wk_ZL AS day_WK_Ag_PW, 
                      100 * dbo.Day_Quota_Step1.day_Pb_Pb_JSL / dbo.Day_Quota_Step1.day_YK_Pb_JSL AS day_HSL_Pb, 
                      100 * dbo.Day_Quota_Step1.day_Zn_Zn_JSL / dbo.Day_Quota_Step1.day_YK_Zn_JSL AS day_HSL_Zn, 
                      1000 * dbo.Day_Quota_Step1.day_Pb_Ag_JSL / dbo.Day_Quota_Step1.day_YK_Ag_JSL AS day_HSL_Ag
FROM         dbo.Day_Quota_Step1 INNER JOIN
                      dbo.Day_Quota_Step2 ON dbo.Day_Quota_Step1.day_date = dbo.Day_Quota_Step2.day_date
go

