CREATE trigger [dbo].[Trig_T42ForT42Acc_update] on [dbo].[mms_aReportDay2_T4]
for update
as
declare @L_date date =null
select @L_date =R_Date  from inserted   
exec proc_aReportDay2_AccStatus @L_date,2,1
--exec proc_aReportMonth_Logic @L_date
exec proc_aReportYk_Logic @L_date,1
--exec proc_insert2DaySumValue @L_date,'',2,22
--exec proc_insert2DaySumValue @L_date,'',2,222
go

