CREATE trigger [dbo].[Trig_SheetSnForT2_1] on [dbo].[mms_afmLaboratorySheetSn]
for insert
as
declare @L_date date =null
select @L_date =ls_Date  from inserted    
exec proc_aReportDay_P2 @L_date,1
exec proc_aReportDay2_P2 @L_date,1
exec proc_insertDaySumValueSn @L_date,'',1,3
exec proc_insertDaySumCombineValueSn @L_date,'',1,3

go

