CREATE VIEW dbo._VReportRun
AS
SELECT     TOP (100) PERCENT tt1.C_Name AS QuotaName1, tt2.C_Name AS QuotaName2, tt3.C_Name AS Unit, r1.ReportValue AS Q1, r2.ReportValue AS Q2, 
                      r3.ReportValue AS Q3, r4.ReportValue AS Q4, r5.ReportValue AS Q5, r6.ReportValue AS Q6, r7.ReportValue AS Q7, r8.ReportValue AS Q8, r1.ReportDate AS MonthDate, 
                      r1.R_Rows AS OrderCode
FROM         (SELECT     R_Rows, ReportValue, ReportDate
                       FROM          dbo.mms_aReportRun_T7
                       WHERE      (R_Cols = 1)) AS r1 INNER JOIN
                          (SELECT     R_Rows, C_Name
                            FROM          dbo.mms_aReportRun_TT
                            WHERE      (R_Cols = 1)) AS tt1 ON r1.R_Rows = tt1.R_Rows INNER JOIN
                          (SELECT     R_Rows, C_Name
                            FROM          dbo.mms_aReportRun_TT AS mms_aReportDay_TT_2
                            WHERE      (R_Cols = 2)) AS tt2 ON r1.R_Rows = tt2.R_Rows INNER JOIN
                          (SELECT     R_Rows, C_Name
                            FROM          dbo.mms_aReportRun_TT AS mms_aReportDay_TT_1
                            WHERE      (R_Cols = 3)) AS tt3 ON r1.R_Rows = tt3.R_Rows INNER JOIN
                          (SELECT     R_Rows, ReportValue, ReportDate
                            FROM          dbo.mms_aReportRun_T7 AS mms_aReportDay_T7_8
                            WHERE      (R_Cols = 2)) AS r2 ON r1.R_Rows = r2.R_Rows AND r1.ReportDate = r2.ReportDate INNER JOIN
                          (SELECT     R_Rows, ReportValue, ReportDate
                            FROM          dbo.mms_aReportRun_T7 AS mms_aReportDay_T7_7
                            WHERE      (R_Cols = 3)) AS r3 ON r1.R_Rows = r3.R_Rows AND r1.ReportDate = r3.ReportDate INNER JOIN
                          (SELECT     R_Rows, ReportValue, ReportDate
                            FROM          dbo.mms_aReportRun_T7 AS mms_aReportDay_T7_6
                            WHERE      (R_Cols = 4)) AS r4 ON r1.R_Rows = r4.R_Rows AND r1.ReportDate = r4.ReportDate INNER JOIN
                          (SELECT     R_Rows, ReportValue, ReportDate
                            FROM          dbo.mms_aReportRun_T7 AS mms_aReportDay_T7_4
                            WHERE      (R_Cols = 5)) AS r5 ON r1.R_Rows = r5.R_Rows AND r1.ReportDate = r5.ReportDate INNER JOIN
                          (SELECT     R_Rows, ReportValue, ReportDate
                            FROM          dbo.mms_aReportRun_T7 AS mms_aReportDay_T7_4
                            WHERE      (R_Cols = 6)) AS r6 ON r1.R_Rows = r6.R_Rows AND r1.ReportDate = r6.ReportDate INNER JOIN
                          (SELECT     R_Rows, ReportValue, ReportDate
                            FROM          dbo.mms_aReportRun_T7 AS mms_aReportDay_T7_3
                            WHERE      (R_Cols = 7)) AS r7 ON r1.R_Rows = r7.R_Rows AND r1.ReportDate = r7.ReportDate INNER JOIN
                          (SELECT     R_Rows, ReportValue, ReportDate
                            FROM          dbo.mms_aReportRun_T7 AS mms_aReportDay_T7_2
                            WHERE      (R_Cols = 8)) AS r8 ON r1.R_Rows = r8.R_Rows AND r1.ReportDate = r8.ReportDate
ORDER BY OrderCode
go

