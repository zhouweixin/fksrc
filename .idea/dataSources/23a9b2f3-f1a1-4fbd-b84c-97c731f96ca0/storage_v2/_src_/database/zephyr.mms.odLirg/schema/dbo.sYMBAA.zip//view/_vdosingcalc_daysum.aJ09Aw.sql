CREATE VIEW dbo._VDosingCalc_DaySum
AS
SELECT     MedicamentType, SUM(value) AS DayValue, cs2date AS date
FROM         (SELECT     DosingLocation, MedicamentType, value, maxValue, minValue, cs2date, hh
                       FROM          dbo._VDosingCalc_Step2) AS a
GROUP BY MedicamentType, cs2date
go

