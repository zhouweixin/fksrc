------------------Dosing表上的三类触发器-------------------------------
CREATE trigger [dbo].[Trig_Dosing2PDweight] on [dbo].[mms_afmDosing]
for insert
as
declare @ID int =null
declare @ValueID nvarchar(50) =''
declare @A_Value decimal(18,2) =0
declare @A_datetime datetime =null
select @ID =ID   ,@ValueID =DosingLocation_ID ,@A_Value=AccValue ,@A_datetime=Timestampe    from inserted   
exec proc_Dosing2PDweiht @ID, @ValueID, @A_Value, @A_datetime
exec proc_Dosing2EuipmentRunTme @ID, @ValueID, @A_Value, @A_datetime
go

