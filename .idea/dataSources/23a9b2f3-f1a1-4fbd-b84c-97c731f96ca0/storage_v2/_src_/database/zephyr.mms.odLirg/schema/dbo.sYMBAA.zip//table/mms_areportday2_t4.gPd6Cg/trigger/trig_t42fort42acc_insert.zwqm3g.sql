------------------T4表上的三类触发器-------------------------------
CREATE trigger [dbo].[Trig_T42ForT42Acc_insert] on [dbo].[mms_aReportDay2_T4]
for insert
as
declare @L_date date =null
select @L_date =R_Date  from inserted   
exec proc_aReportDay2_AccStatus @L_date,1,1
exec proc_aReportMonth_Logic @L_date
exec proc_aReportYk_Logic @L_date,1
exec proc_insert2DaySumValue @L_date,'',1,22
exec proc_insert2DaySumValue @L_date,'',1,222
go

