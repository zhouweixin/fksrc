 
 create proc  p_backupdb 
 @dbname sysname='',  
 @bkpath nvarchar(260)='', 
 @bkfname nvarchar(260)='', 
 @bktype nvarchar(10)='DB',  
 @appendfile bit=1,   
 @password nvarchar(20)='' , 
 @nolog bit=null 
 as 
  declare @sql varchar(8000) 
  declare @sql1 varchar(8000) 
  if isnull(@dbname,'')='' set @dbname=db_name() 
  if isnull(@bkpath,'')='' 
  begin 
   select @bkpath=rtrim(reverse(filename)) from master..sysfiles where name='master' 
   select @bkpath=substring(@bkpath,charindex('\',@bkpath)+1,4000) 
    ,@bkpath=reverse(substring(@bkpath,charindex('\',@bkpath),4000))+'BACKUP\' 
  end 
  if isnull(@bkfname,'')='' set @bkfname='\DBNAME\_\DATE\_\TIME\.BAK' 
  set @bkfname=replace(replace(replace(@bkfname,'\DBNAME\',@dbname) 
   ,'\DATE\',convert(varchar,getdate(),112)) 
   ,'\TIME\',replace(convert(varchar,getdate(),108),':','')) 
  set @sql='backup '+case @bktype when 'LOG' then 'log ' else 'database ' end +@dbname 
   +' to disk='''+@bkpath+@bkfname 
   +''' with '+case @bktype when 'DF' then 'DIFFERENTIAL,' else '' end 
   +case @appendfile when 1 then 'NOINIT' else 'INIT' end 
   +case isnull(@password,'') when '' then '' else ',PASSWORD='''+@password+'''' end 
  
  set @sql1=case @nolog when 1 then 'BACKUP LOG '+@dbname+' WITH NO_LOG '  
   +'DUMP  TRANSACTION  '+@dbname+' WITH  NO_LOG' else '' end 
  exec(@sql) 
  exec(@sql1);

 go

