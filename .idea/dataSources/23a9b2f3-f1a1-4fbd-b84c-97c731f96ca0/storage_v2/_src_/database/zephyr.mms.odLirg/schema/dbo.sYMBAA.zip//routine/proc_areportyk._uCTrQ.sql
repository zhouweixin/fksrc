CREATE PROCEDURE  [dbo].[proc_aReportYk] 
@M_Date date =null 
as
delete from mms_aReportYK_T7 where ReportDate =@M_Date 

declare @yk_1 DECIMAL(18,4) =0
declare @yk_2 DECIMAL(18,4) =0
declare @yk_3 DECIMAL(18,4) =0
declare @yk_4 DECIMAL(18,4) =0
declare @yk_5 DECIMAL(18,4) =0
declare @yk_6 DECIMAL(18,4) =0
declare @yk_7 DECIMAL(18,4) =0
declare @yk_8 DECIMAL(18,4) =0
declare @yk_9 DECIMAL(18,4) =0
declare @zh_1 DECIMAL(18,4) =0
declare @zh_2 DECIMAL(18,4) =0
declare @r_cols int =0
set @r_cols =1

declare @StartDateTime datetime
if(day(@M_Date)<=25)
	select @StartDateTime = CONVERT(varchar(10), CONVERT(varchar(8),dateadd(month,-1,@M_Date),23)+'26' , 120)
if(day(@M_Date)>25)
	select @StartDateTime = convert(varchar(8),@M_Date,21)+'26'
	
while @r_cols<9
	begin
	if(@r_cols =1)
		begin
			select @yk_1=SUM(mm.YK_1) , @yk_3=SUM(mm.YK_3) , @yk_5=SUM(mm.YK_5) 
			, @yk_7=SUM(mm.YK_7) , @yk_9=SUM(mm.YK_9) from		
			(select a.*,b.minewherefrom from mms_aReportDay_T1 a
			inner join mms_afmPlantRun b on a.R_Date=b.run_date and a.R_CID=b.classid
			union 
			select c.*,d.minewherefrom from mms_aReportDay2_T1 c
			inner join mms_afmPlantRun2 d on c.R_Date=d.run_date and c.R_CID=d.classid ) mm
			where mm.minewherefrom='易鑫矿'
			and mm.R_Date <=@M_Date and convert(nvarchar(10),mm.R_Date,120) >= @StartDateTime
		end
	
	if(@r_cols =2)
		begin
			select @yk_1=SUM(mm.YK_1) , @yk_3=SUM(mm.YK_3) , @yk_5=SUM(mm.YK_5) 
			, @yk_7=SUM(mm.YK_7) , @yk_9=SUM(mm.YK_9) from		
			(select a.*,b.minewherefrom from mms_aReportDay_T1 a
			inner join mms_afmPlantRun b on a.R_Date=b.run_date and a.R_CID=b.classid
			union 
			select c.*,d.minewherefrom from mms_aReportDay2_T1 c
			inner join mms_afmPlantRun2 d on c.R_Date=d.run_date and c.R_CID=d.classid ) mm
			where mm.minewherefrom='易鑫矿'
			and mm.R_Date <=@M_Date and year(mm.R_Date) = year(@M_Date)
		end
		
	if(@r_cols =3)
		begin
			select @yk_1=SUM(mm.YK_1) , @yk_3=SUM(mm.YK_3) , @yk_5=SUM(mm.YK_5) 
			, @yk_7=SUM(mm.YK_7) , @yk_9=SUM(mm.YK_9) from 
			(select a.*,b.minewherefrom from mms_aReportDay_T1 a
			inner join mms_afmPlantRun b on a.R_Date=b.run_date and a.R_CID=b.classid
			union 
			select c.*,d.minewherefrom from mms_aReportDay2_T1 c
			inner join mms_afmPlantRun2 d on c.R_Date=d.run_date and c.R_CID=d.classid ) mm
			where mm.minewherefrom='高椅山矿'
			and mm.R_Date <=@M_Date and convert(nvarchar(10),mm.R_Date,120) >= @StartDateTime
		end
		
	if(@r_cols =4)
		begin
			select @yk_1=SUM(mm.YK_1) , @yk_3=SUM(mm.YK_3) , @yk_5=SUM(mm.YK_5) 
			, @yk_7=SUM(mm.YK_7) , @yk_9=SUM(mm.YK_9) from 
			(select a.*,b.minewherefrom from mms_aReportDay_T1 a
			inner join mms_afmPlantRun b on a.R_Date=b.run_date and a.R_CID=b.classid
			union 
			select c.*,d.minewherefrom from mms_aReportDay2_T1 c
			inner join mms_afmPlantRun2 d on c.R_Date=d.run_date and c.R_CID=d.classid ) mm
			where mm.minewherefrom='高椅山矿'
			and mm.R_Date <=@M_Date and year(mm.R_Date) = year(@M_Date)
		end
		
	if(@r_cols =5)
		begin
			select @yk_1=SUM(mm.YK_1) , @yk_3=SUM(mm.YK_3) , @yk_5=SUM(mm.YK_5) 
			, @yk_7=SUM(mm.YK_7) , @yk_9=SUM(mm.YK_9) from 
			(select a.*,b.minewherefrom from mms_aReportDay_T1 a
			inner join mms_afmPlantRun b on a.R_Date=b.run_date and a.R_CID=b.classid
			union 
			select c.*,d.minewherefrom from mms_aReportDay2_T1 c
			inner join mms_afmPlantRun2 d on c.R_Date=d.run_date and c.R_CID=d.classid ) mm
			where mm.minewherefrom='宏发矿'
			and mm.R_Date <=@M_Date and convert(nvarchar(10),mm.R_Date,120) >= @StartDateTime
		end
		
	if(@r_cols =6)
		begin
			select @yk_1=SUM(mm.YK_1) , @yk_3=SUM(mm.YK_3) , @yk_5=SUM(mm.YK_5) 
			, @yk_7=SUM(mm.YK_7) , @yk_9=SUM(mm.YK_9) from 
			(select a.*,b.minewherefrom from mms_aReportDay_T1 a
			inner join mms_afmPlantRun b on a.R_Date=b.run_date and a.R_CID=b.classid
			union 
			select c.*,d.minewherefrom from mms_aReportDay2_T1 c
			inner join mms_afmPlantRun2 d on c.R_Date=d.run_date and c.R_CID=d.classid ) mm
			where mm.minewherefrom='宏发矿'
			and mm.R_Date <=@M_Date and year(mm.R_Date) = year(@M_Date)
		end
		
	if(@r_cols =7)
		begin
			select @yk_1=SUM(mm.YK_1) , @yk_3=SUM(mm.YK_3) , @yk_5=SUM(mm.YK_5) 
			, @yk_7=SUM(mm.YK_7) , @yk_9=SUM(mm.YK_9) from 			
			(select a.*,b.minewherefrom from mms_aReportDay_T1 a
			inner join mms_afmPlantRun b on a.R_Date=b.run_date and a.R_CID=b.classid
			union 
			select c.*,d.minewherefrom from mms_aReportDay2_T1 c
			inner join mms_afmPlantRun2 d on c.R_Date=d.run_date and c.R_CID=d.classid ) mm
			where  mm.R_Date <=@M_Date and convert(nvarchar(10),mm.R_Date,120) >= @StartDateTime
		end
		
	if(@r_cols =8)
		begin
			select @yk_1=SUM(mm.YK_1) , @yk_3=SUM(mm.YK_3) , @yk_5=SUM(mm.YK_5) 
			, @yk_7=SUM(mm.YK_7) , @yk_9=SUM(mm.YK_9) from 			
			(select a.*,b.minewherefrom from mms_aReportDay_T1 a
			inner join mms_afmPlantRun b on a.R_Date=b.run_date and a.R_CID=b.classid
			union 
			select c.*,d.minewherefrom from mms_aReportDay2_T1 c
			inner join mms_afmPlantRun2 d on c.R_Date=d.run_date and c.R_CID=d.classid ) mm
			where  mm.R_Date <=@M_Date and year(mm.R_Date) = year(@M_Date)
		end	
		
		set @zh_2=@yk_7+(@yk_3+@yk_5+@yk_9)/8
		if(@yk_1>0)
			begin
				 set @yk_2=100*@yk_3/@yk_1
				 set @yk_4=100*@yk_5/@yk_1
				 set @yk_6=100*@yk_7/@yk_1
				 set @yk_8=100*@yk_9/@yk_1
				 set @zh_1=100*@zh_2/@yk_1 
			end
		 if(@yk_1=0)
			begin
				 set @yk_2=0
				 set @yk_4=0
				 set @yk_6=0
				 set @yk_8=0
				 set @zh_1=0
			end
			

		insert into mms_aReportYK_T7 
			values(@M_Date,1,@r_cols ,@yk_1),
				(@M_Date,2,@r_cols ,@yk_2),
				(@M_Date,3,@r_cols ,@yk_3),
				(@M_Date,4,@r_cols ,@yk_4),
				(@M_Date,5,@r_cols ,@yk_5),
				(@M_Date,6,@r_cols ,@yk_6),
				(@M_Date,7,@r_cols ,@yk_7),
				(@M_Date,8,@r_cols ,@yk_8),
				(@M_Date,9,@r_cols ,@yk_9),
				(@M_Date,10,@r_cols ,@zh_1),
				(@M_Date,11,@r_cols ,@zh_2)
				
		set @r_cols =@r_cols +1
	end
go

