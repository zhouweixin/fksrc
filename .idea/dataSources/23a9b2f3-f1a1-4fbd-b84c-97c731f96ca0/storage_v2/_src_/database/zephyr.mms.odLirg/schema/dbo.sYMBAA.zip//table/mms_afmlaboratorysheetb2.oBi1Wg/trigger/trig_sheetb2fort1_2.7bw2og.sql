create trigger [dbo].[Trig_SheetB2ForT1_2] on dbo.mms_afmLaboratorySheetB2
for update
as
declare @L_date date =null
declare @C_ID nvarchar(50) =''
select @L_date =ls_Date   ,@C_ID =classid   from inserted   
exec proc_aReportDay2_P1 @L_date,@C_ID,2
go

