CREATE trigger [dbo].[Trig_SheetSnForT2_3] on [dbo].[mms_afmLaboratorySheetSn]
for delete
as
declare @L_date date =null
select @L_date =ls_Date  from deleted    
exec proc_aReportDay_P2 @L_date,3
exec proc_aReportDay2_P2 @L_date,3
exec proc_insertDaySumValueSn @L_date,'',3,3
exec proc_insertDaySumCombineValueSn @L_date,'',3,3
go

