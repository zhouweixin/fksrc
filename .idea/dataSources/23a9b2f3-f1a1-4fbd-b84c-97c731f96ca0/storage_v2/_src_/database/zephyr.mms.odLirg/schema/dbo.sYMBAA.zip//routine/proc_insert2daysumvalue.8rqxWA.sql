CREATE procedure [dbo].[proc_insert2DaySumValue]
@D_Date date =null,
@C_Cid nvarchar(50)='',
@M_Mode int =0, -----------操作模式，1插入、2更新、3删除
@D_Mode int=0-------------数据内容，1运行数据、2化验数据
as

-----计算运行数据日报情况-------------------- 
if(@D_Mode =1)
	begin 
		declare @handlingCapacity decimal(18,2) =0
		declare @runTime decimal(18,2)=0
		declare @wt1 decimal(18,2)=0
		declare @wt2 decimal(18,2)=0
		declare @wt3 decimal(18,2)=0
		declare @wt4 decimal(18,2)=0
		declare @mineWherefrom varchar(50)=''
		declare @self23 nvarchar(50)=''
		select @handlingCapacity=handlingCapacity ,
			@runTime=runTime,
			@wt1=waitForWaterTime ,
			@wt2=waitForElectricityTime ,
			@wt3=waitForFixTime ,
			@wt4=waitElseTime ,
			@mineWherefrom=minewherefrom,
			@self23=self23
					from mms_afmPlantRun2 where run_date=@D_Date and classid=@C_Cid
		if(@M_Mode=1 or @M_Mode =2)
			begin
				if(@C_Cid ='早班')
					begin
						update mms_aTypicalDaySummry2 set MoringClass=@handlingCapacity
							where OrderCode='0101' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MoringClass=8
							where OrderCode='0601' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MoringClass=@runTime
							where OrderCode='0602'	and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MoringClass=@wt1+@wt2+@wt3+@wt4
							where OrderCode='0603' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MoringClass=@wt1
							where OrderCode='0604' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MoringClass=@wt2
							where OrderCode='0605' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MoringClass=@wt3
							where OrderCode='0606' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MoringClass=@wt4
							where OrderCode='0607' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MoringClass=100*@runTime/8
							where OrderCode='0608' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MoringClass=24*@handlingCapacity/nullif(@runTime,0)
							where OrderCode='0609' and MonthDate=@D_Date
					end
				if(@C_Cid ='中班')
					begin
						update mms_aTypicalDaySummry2 set MiddleClass=@handlingCapacity
							where OrderCode='0101' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MiddleClass=8
							where OrderCode='0601' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MiddleClass=@runTime
							where OrderCode='0602' and MonthDate=@D_Date	
						update mms_aTypicalDaySummry2 set MiddleClass=@wt1+@wt2+@wt3+@wt4
							where OrderCode='0603' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MiddleClass=@wt1
							where OrderCode='0604' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MiddleClass=@wt2
							where OrderCode='0605' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MiddleClass=@wt3
							where OrderCode='0606' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MiddleClass=@wt4
							where OrderCode='0607' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MiddleClass=100*@runTime/8
							where OrderCode='0608' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MiddleClass=24*@handlingCapacity/nullif(@runTime,0)
							where OrderCode='0609' and MonthDate=@D_Date
					end	
				if(@C_Cid ='晚班')
					begin
						update mms_aTypicalDaySummry2 set NightClass=@handlingCapacity
							where OrderCode='0101' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set NightClass=8
							where OrderCode='0601' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set NightClass=@runTime
							where OrderCode='0602' and MonthDate=@D_Date	
						update mms_aTypicalDaySummry2 set NightClass=@wt1+@wt2+@wt3+@wt4
							where OrderCode='0603' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set NightClass=@wt1
							where OrderCode='0604' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set NightClass=@wt2
							where OrderCode='0605' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set NightClass=@wt3
							where OrderCode='0606' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set NightClass=@wt4
							where OrderCode='0607' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set NightClass=100*@runTime/8
							where OrderCode='0608' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set NightClass=24*@handlingCapacity/nullif(@runTime,0)
							where OrderCode='0609' and MonthDate=@D_Date
					end
			end	
		if(@M_Mode=3)
			begin
				if(@C_Cid ='早班')
					begin
						update mms_aTypicalDaySummry2 set MoringClass=0
							where OrderCode='0101' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MoringClass=0
							where OrderCode='0601' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MoringClass=0
							where OrderCode='0602' and MonthDate=@D_Date	
						update mms_aTypicalDaySummry2 set MoringClass=0
							where OrderCode='0603' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MoringClass=0
							where OrderCode='0604' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MoringClass=0
							where OrderCode='0605' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MoringClass=0
							where OrderCode='0606' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MoringClass=0
							where OrderCode='0607' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MoringClass=0
							where OrderCode='0608' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MoringClass=0
							where OrderCode='0609' and MonthDate=@D_Date
					end
				if(@C_Cid ='中班')
					begin
						update mms_aTypicalDaySummry2 set MiddleClass=0
							where OrderCode='0101' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MiddleClass=0
							where OrderCode='0601' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MiddleClass=0
							where OrderCode='0602'	 and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MiddleClass=0
							where OrderCode='0603' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MiddleClass=0
							where OrderCode='0604' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MiddleClass=0
							where OrderCode='0605' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MiddleClass=0
							where OrderCode='0606' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MiddleClass=0
							where OrderCode='0607' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MiddleClass=0
							where OrderCode='0608' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set MiddleClass=0
							where OrderCode='0609' and MonthDate=@D_Date
					end	
				if(@C_Cid ='晚班')
					begin
						update mms_aTypicalDaySummry2 set NightClass=0
							where OrderCode='0101' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set NightClass=0
							where OrderCode='0601' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set NightClass=0
							where OrderCode='0602' and MonthDate=@D_Date	
						update mms_aTypicalDaySummry2 set NightClass=0
							where OrderCode='0603' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set NightClass=0
							where OrderCode='0604' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set NightClass=0
							where OrderCode='0605' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set NightClass=0
							where OrderCode='0606' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set NightClass=0
							where OrderCode='0607' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set NightClass=0
							where OrderCode='0608' and MonthDate=@D_Date
						update mms_aTypicalDaySummry2 set NightClass=0
							where OrderCode='0609' and MonthDate=@D_Date
					end				
			end
			-------计算当日和-------
			declare @handlingCapacity_day decimal(18,2) =0
			declare @runTime_day decimal(18,2)=0
			declare @wt1_day decimal(18,2)=0
			declare @wt2_day decimal(18,2)=0
			declare @wt3_day decimal(18,2)=0
			declare @wt4_day decimal(18,2)=0
			declare @mineWherefrom_day varchar(50)=''
			declare @self23_day nvarchar(50)=''
			select @handlingCapacity_day=sum(handlingCapacity) ,
				@runTime_day=sum(runTime),
				@wt1_day=sum(waitForWaterTime) ,
				@wt2_day=sum(waitForElectricityTime) ,
				@wt3_day=sum(waitForFixTime) ,
				@wt4_day=sum(waitElseTime) 
						from mms_afmPlantRun2 where run_date=@D_Date
						
			update mms_aTypicalDaySummry2 set SummryDay=@handlingCapacity_day
				where OrderCode='0101' and MonthDate=@D_Date
			update mms_aTypicalDaySummry2 set SummryDay=24
				where OrderCode='0601' and MonthDate=@D_Date
			update mms_aTypicalDaySummry2 set SummryDay=@runTime_day
				where OrderCode='0602' and MonthDate=@D_Date	
			update mms_aTypicalDaySummry2 set SummryDay=@wt1_day+@wt2_day+@wt3_day+@wt4_day
				where OrderCode='0603' and MonthDate=@D_Date
			update mms_aTypicalDaySummry2 set SummryDay=@wt1_day
				where OrderCode='0604' and MonthDate=@D_Date
			update mms_aTypicalDaySummry2 set SummryDay=@wt2_day
				where OrderCode='0605' and MonthDate=@D_Date
			update mms_aTypicalDaySummry2 set SummryDay=@wt3_day
				where OrderCode='0606' and MonthDate=@D_Date
			update mms_aTypicalDaySummry2 set SummryDay=@wt4_day
				where OrderCode='0607' and MonthDate=@D_Date
			update mms_aTypicalDaySummry2 set SummryDay=100*@runTime_day/24
				where OrderCode='0608' and MonthDate=@D_Date
			update mms_aTypicalDaySummry2 set SummryDay=24*@handlingCapacity_day/nullif(@runTime_day,0)
				where OrderCode='0609' and MonthDate=@D_Date
			-------计算月累计和-------
			declare @handlingCapacity_month decimal(18,2) =0
			declare @runTime_month  decimal(18,2)=0
			declare @wt1_month  decimal(18,2)=0
			declare @wt2_month  decimal(18,2)=0
			declare @wt3_month  decimal(18,2)=0
			declare @wt4_month  decimal(18,2)=0
			declare @mineWherefrom_month  varchar(50)=''
			declare @self23_month  nvarchar(50)=''
			---------处理日期关系--
				declare @StartDateTime datetime
				declare @EndDateTime datetime
				declare @iDays int
				if(day(@D_Date)<=25)
					select @StartDateTime = CONVERT(varchar(10), CONVERT(varchar(8),dateadd(month,-1,@D_Date),23)+'26' , 120)
				if(day(@D_Date)>25)
					select @StartDateTime = convert(varchar(8),@D_Date,21)+'26'
				select @EndDateTime = @D_Date
				select @iDays = datediff(day,convert(varchar(100),@StartDateTime,23),convert(varchar(100),@EndDateTime,23))
				set @iDays=@iDays +1
			select @handlingCapacity_month =sum(handlingCapacity) ,
				@runTime_month =sum(runTime),
				@wt1_month =sum(waitForWaterTime) ,
				@wt2_month =sum(waitForElectricityTime) ,
				@wt3_month =sum(waitForFixTime) ,
				@wt4_month =sum(waitElseTime) 
						from mms_afmPlantRun2 where run_date<=@D_Date and run_date>=@StartDateTime
			update mms_aTypicalDaySummry2 set SummryMonth=@handlingCapacity_month
				where OrderCode='0101' and MonthDate=@D_Date
			update mms_aTypicalDaySummry2 set SummryMonth=24*@iDays
				where OrderCode='0601' and MonthDate=@D_Date
			update mms_aTypicalDaySummry2 set SummryMonth=@runTime_month
				where OrderCode='0602' and MonthDate=@D_Date	
			update mms_aTypicalDaySummry2 set SummryMonth=@wt1_month+@wt2_month+@wt3_month+@wt4_month
				where OrderCode='0603' and MonthDate=@D_Date
			update mms_aTypicalDaySummry2 set SummryMonth=@wt1_month
				where OrderCode='0604' and MonthDate=@D_Date
			update mms_aTypicalDaySummry2 set SummryMonth=@wt2_month
				where OrderCode='0605' and MonthDate=@D_Date
			update mms_aTypicalDaySummry2 set SummryMonth=@wt3_month
				where OrderCode='0606' and MonthDate=@D_Date
			update mms_aTypicalDaySummry2 set SummryMonth=@wt4_month
				where OrderCode='0607' and MonthDate=@D_Date
			update mms_aTypicalDaySummry2 set SummryMonth=100*@runTime_month/(24*nullif(@iDays,0))
				where OrderCode='0608' and MonthDate=@D_Date
			update mms_aTypicalDaySummry2 set SummryMonth=24*@handlingCapacity_month/nullif(@runTime_month,0)
				where OrderCode='0609' and MonthDate=@D_Date			
			-------分矿源计算累计和-----
			if(@mineWherefrom='高椅山矿')
				begin
					declare @handlingCapacity_gys decimal(18,2) =0
					declare @runTime_gys  decimal(18,2)=0
					declare @wt1_gys  decimal(18,2)=0
					declare @wt2_gys  decimal(18,2)=0
					declare @wt3_gys  decimal(18,2)=0
					declare @wt4_gys  decimal(18,2)=0
					declare @mineWherefrom_gys  varchar(50)=''
					declare @self23_gys  nvarchar(50)=''
					---------处理日期关系--
						declare @StartDateTime_gys datetime
						declare @EndDateTime_gys datetime
						declare @iDays_gys int
						if(day(@D_Date)<=25)
							select @StartDateTime_gys = CONVERT(varchar(10), CONVERT(varchar(8),dateadd(month,-1,@D_Date),23)+'26' , 120)
						if(day(@D_Date)>25)
							select @StartDateTime_gys = convert(varchar(8),@D_Date,21)+'26'
						select @EndDateTime_gys = @D_Date
						select @iDays_gys = datediff(day,convert(varchar(100),@StartDateTime_gys,23),convert(varchar(100),@EndDateTime_gys,23))
						set @iDays_gys=@iDays_gys +1
					select @handlingCapacity_gys =sum(handlingCapacity) ,
						@runTime_gys =sum(runTime),
						@wt1_gys =sum(waitForWaterTime) ,
						@wt2_gys =sum(waitForElectricityTime) ,
						@wt3_gys =sum(waitForFixTime) ,
						@wt4_gys =sum(waitElseTime) 
								from mms_afmPlantRun2 where run_date<=@D_Date and run_date>=@StartDateTime_gys
					update mms_aTypicalDaySummry2 set gys=@handlingCapacity_gys
						where OrderCode='0101' and MonthDate=@D_Date
					update mms_aTypicalDaySummry2 set gys=24*@iDays_gys
						where OrderCode='0601' and MonthDate=@D_Date
					update mms_aTypicalDaySummry2 set gys=@runTime_gys
						where OrderCode='0602' and MonthDate=@D_Date	
					update mms_aTypicalDaySummry2 set gys=@wt1_gys+@wt2_gys+@wt3_gys+@wt4_gys
						where OrderCode='0603' and MonthDate=@D_Date
					update mms_aTypicalDaySummry2 set gys=@wt1_gys
						where OrderCode='0604' and MonthDate=@D_Date
					update mms_aTypicalDaySummry2 set gys=@wt2_gys
						where OrderCode='0605' and MonthDate=@D_Date
					update mms_aTypicalDaySummry2 set gys=@wt3_gys
						where OrderCode='0606' and MonthDate=@D_Date
					update mms_aTypicalDaySummry2 set gys=@wt4_gys
						where OrderCode='0607' and MonthDate=@D_Date
					update mms_aTypicalDaySummry2 set gys=100*@runTime_gys/(24*nullif(@iDays_gys,0))
						where OrderCode='0608' and MonthDate=@D_Date
					update mms_aTypicalDaySummry2 set gys=24*@handlingCapacity_gys/nullif(@runTime_gys,0)
						where OrderCode='0609' and MonthDate=@D_Date									
				end	
			if(@mineWherefrom='宏发矿')
				begin
					declare @handlingCapacity_hf decimal(18,2) =0
					declare @runTime_hf  decimal(18,2)=0
					declare @wt1_hf  decimal(18,2)=0
					declare @wt2_hf  decimal(18,2)=0
					declare @wt3_hf  decimal(18,2)=0
					declare @wt4_hf  decimal(18,2)=0
					declare @mineWherefrom_hf  varchar(50)=''
					declare @self23_hf  nvarchar(50)=''
					---------处理日期关系--
						declare @StartDateTime_hf datetime
						declare @EndDateTime_hf datetime
						declare @iDays_hf int
						if(day(@D_Date)<=25)
							select @StartDateTime_hf = CONVERT(varchar(10), CONVERT(varchar(8),dateadd(month,-1,@D_Date),23)+'26' , 120)
						if(day(@D_Date)>25)
							select @StartDateTime_hf = convert(varchar(8),@D_Date,21)+'26'
						select @EndDateTime_hf = @D_Date
						select @iDays_hf = datediff(day,convert(varchar(100),@StartDateTime_hf,23),convert(varchar(100),@EndDateTime_hf,23))
						set @iDays_hf=@iDays_hf +1
					select @handlingCapacity_hf =sum(handlingCapacity) ,
						@runTime_hf =sum(runTime),
						@wt1_hf =sum(waitForWaterTime) ,
						@wt2_hf =sum(waitForElectricityTime) ,
						@wt3_hf =sum(waitForFixTime) ,
						@wt4_hf =sum(waitElseTime) 
								from mms_afmPlantRun2 where run_date<=@D_Date and run_date>=@StartDateTime_hf
					update mms_aTypicalDaySummry2 set hf=@handlingCapacity_hf
						where OrderCode='0101' and MonthDate=@D_Date
					update mms_aTypicalDaySummry2 set hf=24*@iDays_hf
						where OrderCode='0601' and MonthDate=@D_Date
					update mms_aTypicalDaySummry2 set hf=@runTime_hf
						where OrderCode='0602' and MonthDate=@D_Date	
					update mms_aTypicalDaySummry2 set hf=@wt1_hf+@wt2_hf+@wt3_hf+@wt4_hf
						where OrderCode='0603' and MonthDate=@D_Date
					update mms_aTypicalDaySummry2 set hf=@wt1_hf
						where OrderCode='0604' and MonthDate=@D_Date
					update mms_aTypicalDaySummry2 set hf=@wt2_hf
						where OrderCode='0605' and MonthDate=@D_Date
					update mms_aTypicalDaySummry2 set hf=@wt3_hf
						where OrderCode='0606' and MonthDate=@D_Date
					update mms_aTypicalDaySummry2 set hf=@wt4_hf
						where OrderCode='0607' and MonthDate=@D_Date
					update mms_aTypicalDaySummry2 set hf=100*@runTime_hf/(24*nullif(@iDays_hf,0))
						where OrderCode='0608' and MonthDate=@D_Date
					update mms_aTypicalDaySummry2 set hf=24*@handlingCapacity_hf/nullif(@runTime_hf,0)
						where OrderCode='0609' and MonthDate=@D_Date									
				end	
			if(@mineWherefrom='易鑫矿')
				begin
					declare @handlingCapacity_yx decimal(18,2) =0
					declare @runTime_yx  decimal(18,2)=0
					declare @wt1_yx  decimal(18,2)=0
					declare @wt2_yx  decimal(18,2)=0
					declare @wt3_yx  decimal(18,2)=0
					declare @wt4_yx  decimal(18,2)=0
					declare @mineWherefrom_yx  varchar(50)=''
					declare @self23_yx  nvarchar(50)=''
					---------处理日期关系--
						declare @StartDateTime_yx datetime
						declare @EndDateTime_yx datetime
						declare @iDays_yx int
						if(day(@D_Date)<=25)
							select @StartDateTime_yx = CONVERT(varchar(10), CONVERT(varchar(8),dateadd(month,-1,@D_Date),23)+'26' , 120)
						if(day(@D_Date)>25)
							select @StartDateTime_yx = convert(varchar(8),@D_Date,21)+'26'
						select @EndDateTime_yx = @D_Date
						select @iDays_yx = datediff(day,convert(varchar(100),@StartDateTime_yx,23),convert(varchar(100),@EndDateTime_yx,23))
						set @iDays_yx=@iDays_yx +1
					select @handlingCapacity_yx =sum(handlingCapacity) ,
						@runTime_yx =sum(runTime),
						@wt1_yx =sum(waitForWaterTime) ,
						@wt2_yx =sum(waitForElectricityTime) ,
						@wt3_yx =sum(waitForFixTime) ,
						@wt4_yx =sum(waitElseTime) 
								from mms_afmPlantRun2 where run_date<=@D_Date and run_date>=@StartDateTime_yx
					update mms_aTypicalDaySummry2 set yx=@handlingCapacity_yx
						where OrderCode='0101' and MonthDate=@D_Date
					update mms_aTypicalDaySummry2 set yx=24*@iDays_yx
						where OrderCode='0601' and MonthDate=@D_Date
					update mms_aTypicalDaySummry2 set yx=@runTime_yx
						where OrderCode='0602' and MonthDate=@D_Date	
					update mms_aTypicalDaySummry2 set yx=@wt1_yx+@wt2_yx+@wt3_yx+@wt4_yx
						where OrderCode='0603' and MonthDate=@D_Date
					update mms_aTypicalDaySummry2 set yx=@wt1_yx
						where OrderCode='0604' and MonthDate=@D_Date
					update mms_aTypicalDaySummry2 set yx=@wt2_yx
						where OrderCode='0605' and MonthDate=@D_Date
					update mms_aTypicalDaySummry2 set yx=@wt3_yx
						where OrderCode='0606' and MonthDate=@D_Date
					update mms_aTypicalDaySummry2 set yx=@wt4_yx
						where OrderCode='0607' and MonthDate=@D_Date
					update mms_aTypicalDaySummry2 set yx=100*@runTime_yx/(24*nullif(@iDays_yx,0))
						where OrderCode='0608' and MonthDate=@D_Date
					update mms_aTypicalDaySummry2 set yx=24*@handlingCapacity_yx/nullif(@runTime_yx,0)
						where OrderCode='0609' and MonthDate=@D_Date									
				end					
			

	end 

	

		declare @yk_1 DECIMAL(18,4) =0
		declare @yk_2 DECIMAL(18,4) =0
		declare @yk_3 DECIMAL(18,4) =0
		declare @yk_4 DECIMAL(18,4) =0
		declare @yk_5 DECIMAL(18,4) =0
		declare @yk_6 DECIMAL(18,4) =0
		declare @yk_7 DECIMAL(18,4) =0
		declare @yk_8 DECIMAL(18,4) =0
		declare @yk_9 DECIMAL(18,4) =0
		declare @PbSb_1 DECIMAL(18,4) =0
		declare @PbSb_2 DECIMAL(18,4) =0
		declare @PbSb_3 DECIMAL(18,4) =0
		declare @PbSb_4 DECIMAL(18,4) =0
		declare @PbSb_5 DECIMAL(18,4) =0
		declare @PbSb_6 DECIMAL(18,4) =0
		declare @PbSb_7 DECIMAL(18,4) =0
		declare @Zn_1 DECIMAL(18,4) =0
		declare @Zn_2 DECIMAL(18,4) =0
		declare @Zn_3 DECIMAL(18,4) =0
		declare @Zn_4 DECIMAL(18,4) =0
		
		declare @StartDateTime_la datetime
		declare @EndDateTime_la datetime
		declare @iDays_la int
		if(day(@D_Date)<=25)
			select @StartDateTime_La = CONVERT(varchar(10), CONVERT(varchar(8),dateadd(month,-1,@D_Date),23)+'26' , 120)
		if(day(@D_Date)>25)
			select @StartDateTime_la = convert(varchar(8),@D_Date,21)+'26'
		select @EndDateTime_la = @D_Date
		select @iDays_la = datediff(day,convert(varchar(100),@StartDateTime_la,23),convert(varchar(100),@EndDateTime_la,23))
		set @iDays=@iDays +1
-----化验数据填充日报-------------	
if(@D_Mode =2)
begin
	if(@M_Mode=1 or @M_Mode=2)
	begin
		select @yk_1 =YK_1,
				@yk_2 =YK_2,
				@yk_3 =YK_3,
				@yk_4 =YK_4,
				@yk_5 =YK_5,
				@yk_6 =YK_6,
				@yk_7 =YK_7,
				@yk_8 =YK_8,
				@yk_9 =YK_9,
				@pbsb_1 =PbSb_1,
				@pbsb_3 =PbSb_3,
				@pbsb_6 =PbSb_6,
				@pbsb_2 =PbSb_2,
				@pbsb_4 =PbSb_4,
				@pbsb_5 =PbSb_5,
				@pbsb_7 =PbSb_7,		
				@zn_1 =Zn_1,
				@zn_3 =Zn_3,
				@zn_2 =Zn_2,
				@zn_4 =Zn_4
		 from mms_aReportDay2_T1 where R_Date =@D_Date and R_CID=@C_Cid
		 if(@C_Cid='晚班')
			begin
				update	mms_aTypicalDaySummry2 set NightClass=@yk_1
					where MonthDate=@D_Date and OrderCode='0101'
				update	mms_aTypicalDaySummry2 set NightClass=@yk_2
					where MonthDate=@D_Date and OrderCode='0102'
				update	mms_aTypicalDaySummry2 set NightClass=@yk_3
					where MonthDate=@D_Date and OrderCode='0103'
				update	mms_aTypicalDaySummry2 set NightClass=@yk_4
					where MonthDate=@D_Date and OrderCode='0104'
				update	mms_aTypicalDaySummry2 set NightClass=@yk_5
					where MonthDate=@D_Date and OrderCode='0105'
				update	mms_aTypicalDaySummry2 set NightClass=@yk_6
					where MonthDate=@D_Date and OrderCode='0106'
				update	mms_aTypicalDaySummry2 set NightClass=@yk_7
					where MonthDate=@D_Date and OrderCode='0107'
				update	mms_aTypicalDaySummry2 set NightClass=@yk_8
					where MonthDate=@D_Date and OrderCode='0108'
				update	mms_aTypicalDaySummry2 set NightClass=@yk_9
					where MonthDate=@D_Date and OrderCode='0109'
				update	mms_aTypicalDaySummry2 set NightClass=@pbsb_1
					where MonthDate=@D_Date and OrderCode='0201'
				update	mms_aTypicalDaySummry2 set NightClass=@pbsb_2
					where MonthDate=@D_Date and OrderCode='0202'
				update	mms_aTypicalDaySummry2 set NightClass=@pbsb_3
					where MonthDate=@D_Date and OrderCode='0203'
				update	mms_aTypicalDaySummry2 set NightClass=@pbsb_4
					where MonthDate=@D_Date and OrderCode='0204'
				update	mms_aTypicalDaySummry2 set NightClass=@pbsb_5
					where MonthDate=@D_Date and OrderCode='0205'
				update	mms_aTypicalDaySummry2 set NightClass=@pbsb_6
					where MonthDate=@D_Date and OrderCode='0206'
				update	mms_aTypicalDaySummry2 set NightClass=@pbsb_7
					where MonthDate=@D_Date and OrderCode='0207'
				update	mms_aTypicalDaySummry2 set NightClass=@zn_1
					where MonthDate=@D_Date and OrderCode='0501'
				update	mms_aTypicalDaySummry2 set NightClass=@zn_2
					where MonthDate=@D_Date and OrderCode='0502'
				update	mms_aTypicalDaySummry2 set NightClass=@zn_3
					where MonthDate=@D_Date and OrderCode='0503'
				update	mms_aTypicalDaySummry2 set NightClass=@zn_4
					where MonthDate=@D_Date and OrderCode='0504'
						
			end
		 if(@C_Cid='早班')
			begin
				update	mms_aTypicalDaySummry2 set MoringClass=@yk_1
					where MonthDate=@D_Date and OrderCode='0101'
				update	mms_aTypicalDaySummry2 set MoringClass=@yk_2
					where MonthDate=@D_Date and OrderCode='0102'
				update	mms_aTypicalDaySummry2 set MoringClass=@yk_3
					where MonthDate=@D_Date and OrderCode='0103'
				update	mms_aTypicalDaySummry2 set MoringClass=@yk_4
					where MonthDate=@D_Date and OrderCode='0104'
				update	mms_aTypicalDaySummry2 set MoringClass=@yk_5
					where MonthDate=@D_Date and OrderCode='0105'
				update	mms_aTypicalDaySummry2 set MoringClass=@yk_6
					where MonthDate=@D_Date and OrderCode='0106'
				update	mms_aTypicalDaySummry2 set MoringClass=@yk_7
					where MonthDate=@D_Date and OrderCode='0107'
				update	mms_aTypicalDaySummry2 set MoringClass=@yk_8
					where MonthDate=@D_Date and OrderCode='0108'
				update	mms_aTypicalDaySummry2 set MoringClass=@yk_9
					where MonthDate=@D_Date and OrderCode='0109'
				update	mms_aTypicalDaySummry2 set MoringClass=@pbsb_1
					where MonthDate=@D_Date and OrderCode='0201'
				update	mms_aTypicalDaySummry2 set MoringClass=@pbsb_2
					where MonthDate=@D_Date and OrderCode='0202'
				update	mms_aTypicalDaySummry2 set MoringClass=@pbsb_3
					where MonthDate=@D_Date and OrderCode='0203'
				update	mms_aTypicalDaySummry2 set MoringClass=@pbsb_4
					where MonthDate=@D_Date and OrderCode='0204'
				update	mms_aTypicalDaySummry2 set MoringClass=@pbsb_5
					where MonthDate=@D_Date and OrderCode='0205'
				update	mms_aTypicalDaySummry2 set MoringClass=@pbsb_6
					where MonthDate=@D_Date and OrderCode='0206'
				update	mms_aTypicalDaySummry2 set MoringClass=@pbsb_7
					where MonthDate=@D_Date and OrderCode='0207'
				update	mms_aTypicalDaySummry2 set MoringClass=@zn_1
					where MonthDate=@D_Date and OrderCode='0501'
				update	mms_aTypicalDaySummry2 set MoringClass=@zn_2
					where MonthDate=@D_Date and OrderCode='0502'
				update	mms_aTypicalDaySummry2 set MoringClass=@zn_3
					where MonthDate=@D_Date and OrderCode='0503'
				update	mms_aTypicalDaySummry2 set MoringClass=@zn_4
					where MonthDate=@D_Date and OrderCode='0504'
			end		
		 if(@C_Cid='中班')
			begin
				update	mms_aTypicalDaySummry2 set MiddleClass=@yk_1
					where MonthDate=@D_Date and OrderCode='0101'
				update	mms_aTypicalDaySummry2 set MiddleClass=@yk_2
					where MonthDate=@D_Date and OrderCode='0102'
				update	mms_aTypicalDaySummry2 set MiddleClass=@yk_3
					where MonthDate=@D_Date and OrderCode='0103'
				update	mms_aTypicalDaySummry2 set MiddleClass=@yk_4
					where MonthDate=@D_Date and OrderCode='0104'
				update	mms_aTypicalDaySummry2 set MiddleClass=@yk_5
					where MonthDate=@D_Date and OrderCode='0105'
				update	mms_aTypicalDaySummry2 set MiddleClass=@yk_6
					where MonthDate=@D_Date and OrderCode='0106'
				update	mms_aTypicalDaySummry2 set MiddleClass=@yk_7
					where MonthDate=@D_Date and OrderCode='0107'
				update	mms_aTypicalDaySummry2 set MiddleClass=@yk_8
					where MonthDate=@D_Date and OrderCode='0108'
				update	mms_aTypicalDaySummry2 set MiddleClass=@yk_9
					where MonthDate=@D_Date and OrderCode='0109'
				update	mms_aTypicalDaySummry2 set MiddleClass=@pbsb_1
					where MonthDate=@D_Date and OrderCode='0201'
				update	mms_aTypicalDaySummry2 set MiddleClass=@pbsb_2
					where MonthDate=@D_Date and OrderCode='0202'
				update	mms_aTypicalDaySummry2 set MiddleClass=@pbsb_3
					where MonthDate=@D_Date and OrderCode='0203'
				update	mms_aTypicalDaySummry2 set MiddleClass=@pbsb_4
					where MonthDate=@D_Date and OrderCode='0204'
				update	mms_aTypicalDaySummry2 set MiddleClass=@pbsb_5
					where MonthDate=@D_Date and OrderCode='0205'
				update	mms_aTypicalDaySummry2 set MiddleClass=@pbsb_6
					where MonthDate=@D_Date and OrderCode='0206'
				update	mms_aTypicalDaySummry2 set MiddleClass=@pbsb_7
					where MonthDate=@D_Date and OrderCode='0207'
				update	mms_aTypicalDaySummry2 set MiddleClass=@zn_1
					where MonthDate=@D_Date and OrderCode='0501'
				update	mms_aTypicalDaySummry2 set MiddleClass=@zn_2
					where MonthDate=@D_Date and OrderCode='0502'
				update	mms_aTypicalDaySummry2 set MiddleClass=@zn_3
					where MonthDate=@D_Date and OrderCode='0503'
				update	mms_aTypicalDaySummry2 set MiddleClass=@zn_4
					where MonthDate=@D_Date and OrderCode='0504'
			end					

-----化验数据单日合计-------------------

		set @yk_1=0
		set @yk_2=0
		set @yk_3=0
		set @yk_4=0
		set @yk_5=0
		set @yk_6=0
		set @yk_7=0
		set @yk_8=0
		set @yk_9=0
		set @PbSb_1=0
		set @PbSb_2=0
		set @PbSb_3=0
		set @PbSb_4=0
		set @PbSb_5=0
		set @PbSb_6=0
		set @PbSb_7=0
		set @Zn_1=0
		set @Zn_2=0
		set @Zn_3=0
		set @Zn_4=0
			select @yk_1 =SUM(YK_1), @yk_3 =SUM(YK_3),@yk_5 =SUM(YK_5),@yk_7 =SUM(YK_7),@yk_9 =SUM(YK_9),
			@pbsb_1 =SUM(PbSb_1),@pbsb_3 =SUM(PbSb_3),@pbsb_6 =SUM(PbSb_6),
			@zn_1 =SUM(Zn_1),@zn_3 =SUM(Zn_3)
			 from mms_aReportDay2_T1 where R_Date =@D_Date 
			 if(@yk_1>0)
				begin
					 set @yk_2=100*@yk_3/@yk_1
					 set @yk_4=100*@yk_5/@yk_1
					 set @yk_6=100*@yk_7/@yk_1
					 set @yk_8=100*@yk_9/@yk_1
				end
			 if(@yk_1=0)
				begin
					 set @yk_2=0
					 set @yk_4=0
					 set @yk_6=0
					 set @yk_8=0
				end
			 if(@pbsb_1=0)
				set	@pbsb_2=0
			 else
				set @pbsb_2 =100*@pbsb_3/@pbsb_1
			 if(@yk_3=0)
				set @pbsb_4=0
			 else 
				set @pbsb_4 =100*@pbsb_3/@yk_3
			 if(@pbsb_1=0)
				set @pbsb_5=0
			 else
				set @pbsb_5 =100*@pbsb_6/@pbsb_1

			 if(@yk_7=0)
				set @pbsb_7=0
			 else
				set @pbsb_7 =100*@pbsb_6/@yk_7
			 
			 if(@zn_1=0)
				set @zn_2=0
			 else
				set @zn_2 =100*@zn_3/@zn_1
			 if(@yk_5=0)
				set @zn_4=0
			 else 
				set @zn_4 =100*@zn_3/@yk_5
				update	mms_aTypicalDaySummry2 set SummryDay=@yk_1
					where MonthDate=@D_Date and OrderCode='0101'
				update	mms_aTypicalDaySummry2 set SummryDay=@yk_2
					where MonthDate=@D_Date and OrderCode='0102'
				update	mms_aTypicalDaySummry2 set SummryDay=@yk_3
					where MonthDate=@D_Date and OrderCode='0103'
				update	mms_aTypicalDaySummry2 set SummryDay=@yk_4
					where MonthDate=@D_Date and OrderCode='0104'
				update	mms_aTypicalDaySummry2 set SummryDay=@yk_5
					where MonthDate=@D_Date and OrderCode='0105'
				update	mms_aTypicalDaySummry2 set SummryDay=@yk_6
					where MonthDate=@D_Date and OrderCode='0106'
				update	mms_aTypicalDaySummry2 set SummryDay=@yk_7
					where MonthDate=@D_Date and OrderCode='0107'
				update	mms_aTypicalDaySummry2 set SummryDay=@yk_8
					where MonthDate=@D_Date and OrderCode='0108'
				update	mms_aTypicalDaySummry2 set SummryDay=@yk_9
					where MonthDate=@D_Date and OrderCode='0109'
				update	mms_aTypicalDaySummry2 set SummryDay=@pbsb_1
					where MonthDate=@D_Date and OrderCode='0201'
				update	mms_aTypicalDaySummry2 set SummryDay=@pbsb_2
					where MonthDate=@D_Date and OrderCode='0202'
				update	mms_aTypicalDaySummry2 set SummryDay=@pbsb_3
					where MonthDate=@D_Date and OrderCode='0203'
				update	mms_aTypicalDaySummry2 set SummryDay=@pbsb_4
					where MonthDate=@D_Date and OrderCode='0204'
				update	mms_aTypicalDaySummry2 set SummryDay=@pbsb_5
					where MonthDate=@D_Date and OrderCode='0205'
				update	mms_aTypicalDaySummry2 set SummryDay=@pbsb_6
					where MonthDate=@D_Date and OrderCode='0206'
				update	mms_aTypicalDaySummry2 set SummryDay=@pbsb_7
					where MonthDate=@D_Date and OrderCode='0207'
				update	mms_aTypicalDaySummry2 set SummryDay=@zn_1
					where MonthDate=@D_Date and OrderCode='0501'
				update	mms_aTypicalDaySummry2 set SummryDay=@zn_2
					where MonthDate=@D_Date and OrderCode='0502'
				update	mms_aTypicalDaySummry2 set SummryDay=@zn_3
					where MonthDate=@D_Date and OrderCode='0503'
				update	mms_aTypicalDaySummry2 set SummryDay=@zn_4
					where MonthDate=@D_Date and OrderCode='0504'

------化验数据月累计-----------
		---------------------------月累计----
		set @yk_1=0
		set @yk_2=0
		set @yk_3=0
		set @yk_4=0
		set @yk_5=0
		set @yk_6=0
		set @yk_7=0
		set @yk_8=0
		set @yk_9=0
		set @PbSb_1=0
		set @PbSb_2=0
		set @PbSb_3=0
		set @PbSb_4=0
		set @PbSb_5=0
		set @PbSb_6=0
		set @PbSb_7=0
		set @Zn_1=0
		set @Zn_2=0
		set @Zn_3=0
		set @Zn_4=0
			select @yk_1 =SUM(YK_1), @yk_3 =SUM(YK_3),@yk_5 =SUM(YK_5),@yk_7 =SUM(YK_7),@yk_9 =SUM(YK_9),
			@pbsb_1 =SUM(PbSb_1),@pbsb_3 =SUM(PbSb_3),@pbsb_6 =SUM(PbSb_6),
			@zn_1 =SUM(Zn_1),@zn_3 =SUM(Zn_3)
			 from mms_aReportDay2_T1 where R_Date <=@D_Date and R_Date>=@StartDateTime_la 
			 if(@yk_1>0)
				begin
					 set @yk_2=100*@yk_3/@yk_1
					 set @yk_4=100*@yk_5/@yk_1
					 set @yk_6=100*@yk_7/@yk_1
					 set @yk_8=100*@yk_9/@yk_1
				end
			 if(@yk_1=0)
				begin
					 set @yk_2=0
					 set @yk_4=0
					 set @yk_6=0
					 set @yk_8=0
				end
			 if(@pbsb_1=0)
				set	@pbsb_2=0
			 else
				set @pbsb_2 =100*@pbsb_3/@pbsb_1
			 if(@yk_3=0)
				set @pbsb_4=0
			 else 
				set @pbsb_4 =100*@pbsb_3/@yk_3
			 if(@pbsb_1=0)
				set @pbsb_5=0
			 else
				set @pbsb_5 =100*@pbsb_6/@pbsb_1

			 if(@yk_7=0)
				set @pbsb_7=0
			 else
				set @pbsb_7 =100*@pbsb_6/@yk_7
			 
			 if(@zn_1=0)
				set @zn_2=0
			 else
				set @zn_2 =100*@zn_3/@zn_1
			 if(@yk_5=0)
				set @zn_4=0
			 else 
				set @zn_4 =100*@zn_3/@yk_5
				update	mms_aTypicalDaySummry2 set SummryMonth=@yk_1
					where MonthDate=@D_Date and OrderCode='0101'
				update	mms_aTypicalDaySummry2 set SummryMonth=@yk_2
					where MonthDate=@D_Date and OrderCode='0102'
				update	mms_aTypicalDaySummry2 set SummryMonth=@yk_3
					where MonthDate=@D_Date and OrderCode='0103'
				update	mms_aTypicalDaySummry2 set SummryMonth=@yk_4
					where MonthDate=@D_Date and OrderCode='0104'
				update	mms_aTypicalDaySummry2 set SummryMonth=@yk_5
					where MonthDate=@D_Date and OrderCode='0105'
				update	mms_aTypicalDaySummry2 set SummryMonth=@yk_6
					where MonthDate=@D_Date and OrderCode='0106'
				update	mms_aTypicalDaySummry2 set SummryMonth=@yk_7
					where MonthDate=@D_Date and OrderCode='0107'
				update	mms_aTypicalDaySummry2 set SummryMonth=@yk_8
					where MonthDate=@D_Date and OrderCode='0108'
				update	mms_aTypicalDaySummry2 set SummryMonth=@yk_9
					where MonthDate=@D_Date and OrderCode='0109'
				update	mms_aTypicalDaySummry2 set SummryMonth=@pbsb_1
					where MonthDate=@D_Date and OrderCode='0201'
				update	mms_aTypicalDaySummry2 set SummryMonth=@pbsb_2
					where MonthDate=@D_Date and OrderCode='0202'
				update	mms_aTypicalDaySummry2 set SummryMonth=@pbsb_3
					where MonthDate=@D_Date and OrderCode='0203'
				update	mms_aTypicalDaySummry2 set SummryMonth=@pbsb_4
					where MonthDate=@D_Date and OrderCode='0204'
				update	mms_aTypicalDaySummry2 set SummryMonth=@pbsb_5
					where MonthDate=@D_Date and OrderCode='0205'
				update	mms_aTypicalDaySummry2 set SummryMonth=@pbsb_6
					where MonthDate=@D_Date and OrderCode='0206'
				update	mms_aTypicalDaySummry2 set SummryMonth=@pbsb_7
					where MonthDate=@D_Date and OrderCode='0207'
				update	mms_aTypicalDaySummry2 set SummryMonth=@zn_1
					where MonthDate=@D_Date and OrderCode='0501'
				update	mms_aTypicalDaySummry2 set SummryMonth=@zn_2
					where MonthDate=@D_Date and OrderCode='0502'
				update	mms_aTypicalDaySummry2 set SummryMonth=@zn_3
					where MonthDate=@D_Date and OrderCode='0503'
				update	mms_aTypicalDaySummry2 set SummryMonth=@zn_4
					where MonthDate=@D_Date and OrderCode='0504'
		
		--------------------------高椅山月累计--------------
		set @yk_1=0
		set @yk_2=0
		set @yk_3=0
		set @yk_4=0
		set @yk_5=0
		set @yk_6=0
		set @yk_7=0
		set @yk_8=0
		set @yk_9=0
		set @PbSb_1=0
		set @PbSb_2=0
		set @PbSb_3=0
		set @PbSb_4=0
		set @PbSb_5=0
		set @PbSb_6=0
		set @PbSb_7=0
		set @Zn_1=0
		set @Zn_2=0
		set @Zn_3=0
		set @Zn_4=0
		select @yk_1 =SUM(a.YK_1), @yk_3 =SUM(a.YK_3),@yk_5 =SUM(a.YK_5),@yk_7 =SUM(a.YK_7),@yk_9 =SUM(a.YK_9),
			@pbsb_1 =SUM(a.PbSb_1),@pbsb_3 =SUM(a.PbSb_3),@pbsb_6 =SUM(a.PbSb_6),
			@zn_1 =SUM(a.Zn_1),@zn_3 =SUM(a.Zn_3)
		from mms_afmPlantRun2 b inner join mms_aReportDay2_T1 a 
			on a.R_Date=b.run_date and a.R_CID=b.classid	 
		where a.R_Date <=@D_Date and a.R_Date>=@StartDateTime_la and b.minewherefrom='高椅山矿'
			  
			 if(@yk_1>0)
				begin
					 set @yk_2=100*@yk_3/@yk_1
					 set @yk_4=100*@yk_5/@yk_1
					 set @yk_6=100*@yk_7/@yk_1
					 set @yk_8=100*@yk_9/@yk_1
				end
			 if(@yk_1=0)
				begin
					 set @yk_2=0
					 set @yk_4=0
					 set @yk_6=0
					 set @yk_8=0
				end
			 if(@pbsb_1=0)
				set	@pbsb_2=0
			 else
				set @pbsb_2 =100*@pbsb_3/@pbsb_1
			 if(@yk_3=0)
				set @pbsb_4=0
			 else 
				set @pbsb_4 =100*@pbsb_3/@yk_3
			 if(@pbsb_1=0)
				set @pbsb_5=0
			 else
				set @pbsb_5 =100*@pbsb_6/@pbsb_1

			 if(@yk_7=0)
				set @pbsb_7=0
			 else
				set @pbsb_7 =100*@pbsb_6/@yk_7
			 
			 if(@zn_1=0)
				set @zn_2=0
			 else
				set @zn_2 =100*@zn_3/@zn_1
			 if(@yk_5=0)
				set @zn_4=0
			 else 
				set @zn_4 =100*@zn_3/@yk_5
				update	mms_aTypicalDaySummry2 set gys=@yk_1
					where MonthDate=@D_Date and OrderCode='0101'
				update	mms_aTypicalDaySummry2 set gys=@yk_2
					where MonthDate=@D_Date and OrderCode='0102'
				update	mms_aTypicalDaySummry2 set gys=@yk_3
					where MonthDate=@D_Date and OrderCode='0103'
				update	mms_aTypicalDaySummry2 set gys=@yk_4
					where MonthDate=@D_Date and OrderCode='0104'
				update	mms_aTypicalDaySummry2 set gys=@yk_5
					where MonthDate=@D_Date and OrderCode='0105'
				update	mms_aTypicalDaySummry2 set gys=@yk_6
					where MonthDate=@D_Date and OrderCode='0106'
				update	mms_aTypicalDaySummry2 set gys=@yk_7
					where MonthDate=@D_Date and OrderCode='0107'
				update	mms_aTypicalDaySummry2 set gys=@yk_8
					where MonthDate=@D_Date and OrderCode='0108'
				update	mms_aTypicalDaySummry2 set gys=@yk_9
					where MonthDate=@D_Date and OrderCode='0109'
				update	mms_aTypicalDaySummry2 set gys=@pbsb_1
					where MonthDate=@D_Date and OrderCode='0201'
				update	mms_aTypicalDaySummry2 set gys=@pbsb_2
					where MonthDate=@D_Date and OrderCode='0202'
				update	mms_aTypicalDaySummry2 set gys=@pbsb_3
					where MonthDate=@D_Date and OrderCode='0203'
				update	mms_aTypicalDaySummry2 set gys=@pbsb_4
					where MonthDate=@D_Date and OrderCode='0204'
				update	mms_aTypicalDaySummry2 set gys=@pbsb_5
					where MonthDate=@D_Date and OrderCode='0205'
				update	mms_aTypicalDaySummry2 set gys=@pbsb_6
					where MonthDate=@D_Date and OrderCode='0206'
				update	mms_aTypicalDaySummry2 set gys=@pbsb_7
					where MonthDate=@D_Date and OrderCode='0207'
				update	mms_aTypicalDaySummry2 set gys=@zn_1
					where MonthDate=@D_Date and OrderCode='0501'
				update	mms_aTypicalDaySummry2 set gys=@zn_2
					where MonthDate=@D_Date and OrderCode='0502'
				update	mms_aTypicalDaySummry2 set gys=@zn_3
					where MonthDate=@D_Date and OrderCode='0503'
				update	mms_aTypicalDaySummry2 set gys=@zn_4
					where MonthDate=@D_Date and OrderCode='0504'
		--------------------------易鑫月累计---------------
		set @yk_1=0
		set @yk_2=0
		set @yk_3=0
		set @yk_4=0
		set @yk_5=0
		set @yk_6=0
		set @yk_7=0
		set @yk_8=0
		set @yk_9=0
		set @PbSb_1=0
		set @PbSb_2=0
		set @PbSb_3=0
		set @PbSb_4=0
		set @PbSb_5=0
		set @PbSb_6=0
		set @PbSb_7=0
		set @Zn_1=0
		set @Zn_2=0
		set @Zn_3=0
		set @Zn_4=0
		select @yk_1 =SUM(a.YK_1), @yk_3 =SUM(a.YK_3),@yk_5 =SUM(a.YK_5),@yk_7 =SUM(a.YK_7),@yk_9 =SUM(a.YK_9),
			@pbsb_1 =SUM(a.PbSb_1),@pbsb_3 =SUM(a.PbSb_3),@pbsb_6 =SUM(a.PbSb_6),
			@zn_1 =SUM(a.Zn_1),@zn_3 =SUM(a.Zn_3)
		from mms_afmPlantRun2 b inner join mms_aReportDay2_T1 a 
			on a.R_Date=b.run_date and a.R_CID=b.classid	 
		where a.R_Date <=@D_Date and a.R_Date>=@StartDateTime_la and b.minewherefrom='易鑫矿'
			  
			 if(@yk_1>0)
				begin
					 set @yk_2=100*@yk_3/@yk_1
					 set @yk_4=100*@yk_5/@yk_1
					 set @yk_6=100*@yk_7/@yk_1
					 set @yk_8=100*@yk_9/@yk_1
				end
			 if(@yk_1=0)
				begin
					 set @yk_2=0
					 set @yk_4=0
					 set @yk_6=0
					 set @yk_8=0
				end
			 if(@pbsb_1=0)
				set	@pbsb_2=0
			 else
				set @pbsb_2 =100*@pbsb_3/@pbsb_1
			 if(@yk_3=0)
				set @pbsb_4=0
			 else 
				set @pbsb_4 =100*@pbsb_3/@yk_3
			 if(@pbsb_1=0)
				set @pbsb_5=0
			 else
				set @pbsb_5 =100*@pbsb_6/@pbsb_1

			 if(@yk_7=0)
				set @pbsb_7=0
			 else
				set @pbsb_7 =100*@pbsb_6/@yk_7
			 
			 if(@zn_1=0)
				set @zn_2=0
			 else
				set @zn_2 =100*@zn_3/@zn_1
			 if(@yk_5=0)
				set @zn_4=0
			 else 
				set @zn_4 =100*@zn_3/@yk_5
				update	mms_aTypicalDaySummry2 set yx=@yk_1
					where MonthDate=@D_Date and OrderCode='0101'
				update	mms_aTypicalDaySummry2 set yx=@yk_2
					where MonthDate=@D_Date and OrderCode='0102'
				update	mms_aTypicalDaySummry2 set yx=@yk_3
					where MonthDate=@D_Date and OrderCode='0103'
				update	mms_aTypicalDaySummry2 set yx=@yk_4
					where MonthDate=@D_Date and OrderCode='0104'
				update	mms_aTypicalDaySummry2 set yx=@yk_5
					where MonthDate=@D_Date and OrderCode='0105'
				update	mms_aTypicalDaySummry2 set yx=@yk_6
					where MonthDate=@D_Date and OrderCode='0106'
				update	mms_aTypicalDaySummry2 set yx=@yk_7
					where MonthDate=@D_Date and OrderCode='0107'
				update	mms_aTypicalDaySummry2 set yx=@yk_8
					where MonthDate=@D_Date and OrderCode='0108'
				update	mms_aTypicalDaySummry2 set yx=@yk_9
					where MonthDate=@D_Date and OrderCode='0109'
				update	mms_aTypicalDaySummry2 set yx=@pbsb_1
					where MonthDate=@D_Date and OrderCode='0201'
				update	mms_aTypicalDaySummry2 set yx=@pbsb_2
					where MonthDate=@D_Date and OrderCode='0202'
				update	mms_aTypicalDaySummry2 set yx=@pbsb_3
					where MonthDate=@D_Date and OrderCode='0203'
				update	mms_aTypicalDaySummry2 set yx=@pbsb_4
					where MonthDate=@D_Date and OrderCode='0204'
				update	mms_aTypicalDaySummry2 set yx=@pbsb_5
					where MonthDate=@D_Date and OrderCode='0205'
				update	mms_aTypicalDaySummry2 set yx=@pbsb_6
					where MonthDate=@D_Date and OrderCode='0206'
				update	mms_aTypicalDaySummry2 set yx=@pbsb_7
					where MonthDate=@D_Date and OrderCode='0207'
				update	mms_aTypicalDaySummry2 set yx=@zn_1
					where MonthDate=@D_Date and OrderCode='0501'
				update	mms_aTypicalDaySummry2 set yx=@zn_2
					where MonthDate=@D_Date and OrderCode='0502'
				update	mms_aTypicalDaySummry2 set yx=@zn_3
					where MonthDate=@D_Date and OrderCode='0503'
				update	mms_aTypicalDaySummry2 set yx=@zn_4
					where MonthDate=@D_Date and OrderCode='0504'		
		--------------------------宏发月累计-------------------
		set @yk_1=0
		set @yk_2=0
		set @yk_3=0
		set @yk_4=0
		set @yk_5=0
		set @yk_6=0
		set @yk_7=0
		set @yk_8=0
		set @yk_9=0
		set @PbSb_1=0
		set @PbSb_2=0
		set @PbSb_3=0
		set @PbSb_4=0
		set @PbSb_5=0
		set @PbSb_6=0
		set @PbSb_7=0
		set @Zn_1=0
		set @Zn_2=0
		set @Zn_3=0
		set @Zn_4=0
		select @yk_1 =SUM(a.YK_1), @yk_3 =SUM(a.YK_3),@yk_5 =SUM(a.YK_5),@yk_7 =SUM(a.YK_7),@yk_9 =SUM(a.YK_9),
			@pbsb_1 =SUM(a.PbSb_1),@pbsb_3 =SUM(a.PbSb_3),@pbsb_6 =SUM(a.PbSb_6),
			@zn_1 =SUM(a.Zn_1),@zn_3 =SUM(a.Zn_3)
		from mms_afmPlantRun2 b inner join mms_aReportDay2_T1 a 
			on a.R_Date=b.run_date and a.R_CID=b.classid	 
		where a.R_Date <=@D_Date and a.R_Date>=@StartDateTime_la and b.minewherefrom='宏发矿'
			  
			 if(@yk_1>0)
				begin
					 set @yk_2=100*@yk_3/@yk_1
					 set @yk_4=100*@yk_5/@yk_1
					 set @yk_6=100*@yk_7/@yk_1
					 set @yk_8=100*@yk_9/@yk_1
				end
			 if(@yk_1=0)
				begin
					 set @yk_2=0
					 set @yk_4=0
					 set @yk_6=0
					 set @yk_8=0
				end
			 if(@pbsb_1=0)
				set	@pbsb_2=0
			 else
				set @pbsb_2 =100*@pbsb_3/@pbsb_1
			 if(@yk_3=0)
				set @pbsb_4=0
			 else 
				set @pbsb_4 =100*@pbsb_3/@yk_3
			 if(@pbsb_1=0)
				set @pbsb_5=0
			 else
				set @pbsb_5 =100*@pbsb_6/@pbsb_1

			 if(@yk_7=0)
				set @pbsb_7=0
			 else
				set @pbsb_7 =100*@pbsb_6/@yk_7
			 
			 if(@zn_1=0)
				set @zn_2=0
			 else
				set @zn_2 =100*@zn_3/@zn_1
			 if(@yk_5=0)
				set @zn_4=0
			 else 
				set @zn_4 =100*@zn_3/@yk_5
				update	mms_aTypicalDaySummry2 set hf=@yk_1
					where MonthDate=@D_Date and OrderCode='0101'
				update	mms_aTypicalDaySummry2 set hf=@yk_2
					where MonthDate=@D_Date and OrderCode='0102'
				update	mms_aTypicalDaySummry2 set hf=@yk_3
					where MonthDate=@D_Date and OrderCode='0103'
				update	mms_aTypicalDaySummry2 set hf=@yk_4
					where MonthDate=@D_Date and OrderCode='0104'
				update	mms_aTypicalDaySummry2 set hf=@yk_5
					where MonthDate=@D_Date and OrderCode='0105'
				update	mms_aTypicalDaySummry2 set hf=@yk_6
					where MonthDate=@D_Date and OrderCode='0106'
				update	mms_aTypicalDaySummry2 set hf=@yk_7
					where MonthDate=@D_Date and OrderCode='0107'
				update	mms_aTypicalDaySummry2 set hf=@yk_8
					where MonthDate=@D_Date and OrderCode='0108'
				update	mms_aTypicalDaySummry2 set hf=@yk_9
					where MonthDate=@D_Date and OrderCode='0109'
				update	mms_aTypicalDaySummry2 set hf=@pbsb_1
					where MonthDate=@D_Date and OrderCode='0201'
				update	mms_aTypicalDaySummry2 set hf=@pbsb_2
					where MonthDate=@D_Date and OrderCode='0202'
				update	mms_aTypicalDaySummry2 set hf=@pbsb_3
					where MonthDate=@D_Date and OrderCode='0203'
				update	mms_aTypicalDaySummry2 set hf=@pbsb_4
					where MonthDate=@D_Date and OrderCode='0204'
				update	mms_aTypicalDaySummry2 set hf=@pbsb_5
					where MonthDate=@D_Date and OrderCode='0205'
				update	mms_aTypicalDaySummry2 set hf=@pbsb_6
					where MonthDate=@D_Date and OrderCode='0206'
				update	mms_aTypicalDaySummry2 set hf=@pbsb_7
					where MonthDate=@D_Date and OrderCode='0207'
				update	mms_aTypicalDaySummry2 set hf=@zn_1
					where MonthDate=@D_Date and OrderCode='0501'
				update	mms_aTypicalDaySummry2 set hf=@zn_2
					where MonthDate=@D_Date and OrderCode='0502'
				update	mms_aTypicalDaySummry2 set hf=@zn_3
					where MonthDate=@D_Date and OrderCode='0503'
				update	mms_aTypicalDaySummry2 set hf=@zn_4
					where MonthDate=@D_Date and OrderCode='0504'	
	end	
	if(@M_Mode=3)	
	begin	
		 if(@C_Cid='晚班')
			begin
				update	mms_aTypicalDaySummry2 set NightClass=0
					where MonthDate=@D_Date and OrderCode='0101'
				update	mms_aTypicalDaySummry2 set NightClass=0
					where MonthDate=@D_Date and OrderCode='0102'
				update	mms_aTypicalDaySummry2 set NightClass=0
					where MonthDate=@D_Date and OrderCode='0103'
				update	mms_aTypicalDaySummry2 set NightClass=0
					where MonthDate=@D_Date and OrderCode='0104'
				update	mms_aTypicalDaySummry2 set NightClass=0
					where MonthDate=@D_Date and OrderCode='0105'
				update	mms_aTypicalDaySummry2 set NightClass=0
					where MonthDate=@D_Date and OrderCode='0106'
				update	mms_aTypicalDaySummry2 set NightClass=0
					where MonthDate=@D_Date and OrderCode='0107'
				update	mms_aTypicalDaySummry2 set NightClass=0
					where MonthDate=@D_Date and OrderCode='0108'
				update	mms_aTypicalDaySummry2 set NightClass=0
					where MonthDate=@D_Date and OrderCode='0109'
				update	mms_aTypicalDaySummry2 set NightClass=0
					where MonthDate=@D_Date and OrderCode='0201'
				update	mms_aTypicalDaySummry2 set NightClass=0
					where MonthDate=@D_Date and OrderCode='0202'
				update	mms_aTypicalDaySummry2 set NightClass=0
					where MonthDate=@D_Date and OrderCode='0203'
				update	mms_aTypicalDaySummry2 set NightClass=0
					where MonthDate=@D_Date and OrderCode='0204'
				update	mms_aTypicalDaySummry2 set NightClass=0
					where MonthDate=@D_Date and OrderCode='0205'
				update	mms_aTypicalDaySummry2 set NightClass=0
					where MonthDate=@D_Date and OrderCode='0206'
				update	mms_aTypicalDaySummry2 set NightClass=0
					where MonthDate=@D_Date and OrderCode='0207'
				update	mms_aTypicalDaySummry2 set NightClass=0
					where MonthDate=@D_Date and OrderCode='0501'
				update	mms_aTypicalDaySummry2 set NightClass=0
					where MonthDate=@D_Date and OrderCode='0502'
				update	mms_aTypicalDaySummry2 set NightClass=0
					where MonthDate=@D_Date and OrderCode='0503'
				update	mms_aTypicalDaySummry2 set NightClass=0
					where MonthDate=@D_Date and OrderCode='0504'
			end
		 if(@C_Cid='早班')
			begin
				update	mms_aTypicalDaySummry2 set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0101'
				update	mms_aTypicalDaySummry2 set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0102'
				update	mms_aTypicalDaySummry2 set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0103'
				update	mms_aTypicalDaySummry2 set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0104'
				update	mms_aTypicalDaySummry2 set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0105'
				update	mms_aTypicalDaySummry2 set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0106'
				update	mms_aTypicalDaySummry2 set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0107'
				update	mms_aTypicalDaySummry2 set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0108'
				update	mms_aTypicalDaySummry2 set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0109'
				update	mms_aTypicalDaySummry2 set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0201'
				update	mms_aTypicalDaySummry2 set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0202'
				update	mms_aTypicalDaySummry2 set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0203'
				update	mms_aTypicalDaySummry2 set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0204'
				update	mms_aTypicalDaySummry2 set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0205'
				update	mms_aTypicalDaySummry2 set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0206'
				update	mms_aTypicalDaySummry2 set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0207'
				update	mms_aTypicalDaySummry2 set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0501'
				update	mms_aTypicalDaySummry2 set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0502'
				update	mms_aTypicalDaySummry2 set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0503'
				update	mms_aTypicalDaySummry2 set MoringClass=0
					where MonthDate=@D_Date and OrderCode='0504'
			end		
		 if(@C_Cid='中班')
			begin
				update	mms_aTypicalDaySummry2 set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0101'
				update	mms_aTypicalDaySummry2 set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0102'
				update	mms_aTypicalDaySummry2 set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0103'
				update	mms_aTypicalDaySummry2 set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0104'
				update	mms_aTypicalDaySummry2 set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0105'
				update	mms_aTypicalDaySummry2 set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0106'
				update	mms_aTypicalDaySummry2 set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0107'
				update	mms_aTypicalDaySummry2 set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0108'
				update	mms_aTypicalDaySummry2 set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0109'
				update	mms_aTypicalDaySummry2 set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0201'
				update	mms_aTypicalDaySummry2 set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0202'
				update	mms_aTypicalDaySummry2 set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0203'
				update	mms_aTypicalDaySummry2 set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0204'
				update	mms_aTypicalDaySummry2 set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0205'
				update	mms_aTypicalDaySummry2 set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0206'
				update	mms_aTypicalDaySummry2 set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0207'
				update	mms_aTypicalDaySummry2 set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0501'
				update	mms_aTypicalDaySummry2 set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0502'
				update	mms_aTypicalDaySummry2 set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0503'
				update	mms_aTypicalDaySummry2 set MiddleClass=0
					where MonthDate=@D_Date and OrderCode='0504'
			end				
	end
end

go

