------------------T4_acc表上的三类触发器-------------------------------
create trigger [dbo].[Trig_T42AccForReport_update] on [dbo].[mms_aReportDay2_T4_Acc]
for update
as
declare @L_date date =null
select @L_date =R_Date  from inserted   
exec proc_insert2DaySumValue @L_date,'',2,222
go

