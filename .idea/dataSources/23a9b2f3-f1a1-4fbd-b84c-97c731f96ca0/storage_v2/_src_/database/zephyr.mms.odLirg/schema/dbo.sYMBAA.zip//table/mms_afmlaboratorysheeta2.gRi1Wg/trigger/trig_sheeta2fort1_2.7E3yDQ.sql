create trigger [dbo].[Trig_SheetA2ForT1_2] on dbo.mms_afmLaboratorySheetA2
for update
as
declare @L_date date =null
declare @C_ID nvarchar(50) =''
select @L_date =LS_Date  ,@C_ID =ClassID   from inserted   
exec proc_aReportDay2_P1 @L_date,@C_ID,2
go

