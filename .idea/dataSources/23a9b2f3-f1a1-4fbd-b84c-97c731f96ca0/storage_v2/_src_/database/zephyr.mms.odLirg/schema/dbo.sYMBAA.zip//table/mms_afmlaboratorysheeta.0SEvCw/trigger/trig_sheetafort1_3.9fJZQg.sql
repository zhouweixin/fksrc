create trigger Trig_SheetAForT1_3 on dbo.mms_afmLaboratorySheetA
for delete
as
declare @L_date date =null
declare @C_ID nvarchar(50) =''
select @L_date =LS_Date  ,@C_ID =ClassID   from deleted    
exec proc_aReportDay_P1 @L_date,@C_ID,3
go

