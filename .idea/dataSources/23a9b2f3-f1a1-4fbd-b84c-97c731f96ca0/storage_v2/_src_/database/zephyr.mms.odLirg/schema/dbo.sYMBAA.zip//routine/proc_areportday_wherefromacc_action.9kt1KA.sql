
CREATE procedure [dbo].[proc_aReportDay_WhereFromAcc_Action]
@W_date date =null,
@WhereFromName nvarchar(50) =null
as
declare @ColNum int =0
if(@WhereFromName ='宏发矿')
	set @ColNum=6
if(@WhereFromName ='高椅山矿')
	set @ColNum=7
if(@WhereFromName ='易鑫矿')
	set @ColNum=8
	
declare @yk1 decimal(18,4) =0
declare @yk2 decimal(18,4) =0
declare @yk3 decimal(18,4) =0
declare @yk4 decimal(18,4) =0
declare @yk5 decimal(18,4) =0
declare @yk6 decimal(18,4) =0
declare @yk7 decimal(18,4) =0
declare @yk8 decimal(18,4) =0
declare @yk9 decimal(18,4) =0
declare @pbsb1 decimal(18,4) =0
declare @pbsb2 decimal(18,4) =0
declare @pbsb3 decimal(18,4) =0
declare @pbsb4 decimal(18,4) =0
declare @pbsb5 decimal(18,4) =0
declare @pbsb6 decimal(18,4) =0
declare @pbsb7 decimal(18,4) =0
declare @zn1 decimal(18,4) =0
declare @zn2 decimal(18,4) =0
declare @zn3 decimal(18,4) =0
declare @zn4 decimal(18,4) =0
declare @sn_xn1 decimal(18,4) =0
declare @sn_xn2 decimal(18,4) =0
declare @sn_xn3 decimal(18,4) =0
declare @sn_xn4 decimal(18,4) =0
declare @sn_zx1 decimal(18,4) =0
declare @sn_zx2 decimal(18,4) =0
declare @sn_zx3 decimal(18,4) =0
declare @sn_zx4 decimal(18,4) =0
declare @run1 decimal(18,4) =0
declare @run2 decimal(18,4) =0
declare @run3 decimal(18,4) =0
declare @run4 decimal(18,4) =0
declare @run5 decimal(18,4) =0
declare @run6 decimal(18,4) =0
declare @run7 decimal(18,4) =0
declare @run8 decimal(18,4) =0
declare @run9 decimal(18,4) =0
declare @tempCount int =0

set @tempCount=(select 	COUNT(*)
					from mms_aReportDay_T1 a
					inner join mms_afmPlantRun b
					on a.R_Date =b.run_date and a.R_CID =b.classid 
					inner join mms_aReportDay_T2 c
					on a.R_Date =c.R_Date and a.R_CID =c.R_CID 
					inner join mms_aReportDay_T3 d
					on a.R_Date =d.R_Date and a.R_CID =d.R_CID 
					where b.minewherefrom =@WhereFromName and a.R_Date <=@W_date and MONTH(a.R_Date)=MONTH(@W_date))

if(	@tempCount>0)
	begin				
		select 	@yk1=sum(YK_1),@yk3=sum(YK_3),@yk5=sum(YK_5),@yk7=sum(YK_7),@yk9=sum(YK_9),
				@pbsb1=sum(PbSb_1),@pbsb3=sum(PbSb_3),@pbsb6=sum(PbSb_6),
				@zn1 =SUM(Zn_1 ),@zn3=SUM(Zn_3),
				@sn_xn1=SUM(Sn_XN_1),@sn_xn3=SUM(Sn_XN_3),@sn_zx1=SUM(Sn_ZX_1),@sn_zx3=SUM(Sn_ZX_3),
				@run1 =SUM(Run_1 ),@run2 =SUM(Run_2 ),@run3 =SUM(Run_3 ),@run4 =SUM(Run_4 ),@run5 =SUM(Run_5 ),
				@run6 =SUM(Run_6 ),@run7 =SUM(Run_7 )
		from mms_aReportDay_T1 a
		inner join mms_afmPlantRun b
		on a.R_Date =b.run_date and a.R_CID =b.classid 
		inner join mms_aReportDay_T2 c
		on a.R_Date =c.R_Date and a.R_CID =c.R_CID 
		inner join mms_aReportDay_T3 d
		on a.R_Date =d.R_Date and a.R_CID =d.R_CID 
		where b.minewherefrom =@WhereFromName and a.R_Date <=@W_date and MONTH(a.R_Date)=MONTH(@W_date)
		if(@yk1=0)
			begin
				set @yk2=0
				set @yk4=0
				set @yk6=0
				set @yk8=0
			end
		else
			begin
				set @yk2=100*@yk3/@yk1
				set @yk4=100*@yk5/@yk1
				set @yk6=100*@yk7/@yk1
				set @yk8=100*@yk9/@yk1
			end
			
		if(@pbsb1=0)
			begin
				set @pbsb2 =0
				set @pbsb5 =0
			end
		else
			begin
				set @pbsb2 =100*@pbsb3/@pbsb1
				set @pbsb5 =100*@pbsb6/@pbsb1
			end
			
		if(@yk3=0)
			set @pbsb4=0
		else
			set @pbsb4 =100*@pbsb3/@yk3
			
		if(@yk7=0)
			set @pbsb7=0
		else
			set @pbsb7 =100*@pbsb6/@yk7

		if(@zn1=0)
			set @zn2=0
		else
			set @zn2=100*@zn3/@zn1 
			
		if(@yk5=0)
			set @zn4=0
		else
			set @zn4 =100*@zn3 /@yk5

		if(@sn_xn1=0)
			set @sn_xn2=0
		else
			set @sn_xn2=100*@sn_xn3/@sn_xn1
			
		if(	@yk9=0)
			begin
				set @sn_xn4=0
				set @sn_zx4 =0
			end
		else
			begin
				set @sn_xn4=100*@sn_xn3/@yk9
				set @sn_zx4=100*@sn_zx3/@yk9	
			end

		if(@sn_zx1=0)
			set @sn_zx1=0
		else
			set @sn_zx1=100*@sn_zx3/@sn_zx1

		if(@run1=0)
			set @run8=0
		else
			set @run8=100*@run2/@run1

		if(@run2=0)
			set @run9=0
		else
			set @run9=24*@yk1/@run2
end

declare @tempW int =0
set @tempW =(select COUNT(*) from mms_aReportDayWhereFromAcc where R_date =@W_date and WhereFrom =@WhereFromName)
if(@tempW =0)
	begin
		insert into mms_aReportDayWhereFromAcc values(@W_date,@WhereFromName,@yk1,@yk2,@yk3,@yk4,@yk5,@yk6,@yk7,@yk8,@yk9,
			@pbsb1 ,@pbsb2 ,@pbsb3 ,@pbsb4 ,@pbsb5 ,@pbsb6 ,@pbsb7 ,
			@zn1 ,@zn2 ,@zn3 ,@zn4 ,
			@sn_xn1,@sn_xn2,@sn_xn3,@sn_xn4,@sn_zx1,@sn_zx2,@sn_zx3,@sn_zx4,
			@run1,@run2,@run3,@run4,@run5,@run6,@run7,@run8,@run9)
		insert into mms_aReportDay_T7 values(@W_date ,1,@ColNum,@yk1 ),
											(@W_date ,2,@ColNum,@yk2 ),
											(@W_date ,3,@ColNum,@yk3 ),
											(@W_date ,4,@ColNum,@yk4 ),
											(@W_date ,5,@ColNum,@yk5 ),
											(@W_date ,6,@ColNum,@yk6 ),
											(@W_date ,7,@ColNum,@yk7 ),
											(@W_date ,8,@ColNum,@yk8 ),
											(@W_date ,9,@ColNum,@yk9 ),
											(@W_date ,10,@ColNum,@pbsb1),
											(@W_date ,11,@ColNum,@pbsb2),
											(@W_date ,12,@ColNum,@pbsb3),
											(@W_date ,13,@ColNum,@pbsb4),
											(@W_date ,14,@ColNum,@pbsb5),
											(@W_date ,15,@ColNum,@pbsb6),
											(@W_date ,16,@ColNum,@pbsb7),
											(@W_date ,17,@ColNum,@zn1),
											(@W_date ,18,@ColNum,@zn2),
											(@W_date ,19,@ColNum,@zn3),
											(@W_date ,20,@ColNum,@zn4),
											(@W_date ,21,@ColNum,@sn_xn1),
											(@W_date ,22,@ColNum,@sn_xn2),
											(@W_date ,23,@ColNum,@sn_xn3),
											(@W_date ,24,@ColNum,@sn_xn4),
											(@W_date ,25,@ColNum,@sn_zx1),
											(@W_date ,26,@ColNum,@sn_zx2),
											(@W_date ,27,@ColNum,@sn_zx3),
											(@W_date ,28,@ColNum,@sn_zx4),
											(@W_date ,29,@ColNum,@run1),
											(@W_date ,30,@ColNum,@run2),
											(@W_date ,31,@ColNum,@run3),
											(@W_date ,32,@ColNum,@run4),
											(@W_date ,33,@ColNum,@run5),
											(@W_date ,34,@ColNum,@run6),
											(@W_date ,35,@ColNum,@run7),
											(@W_date ,36,@ColNum,@run8),
											(@W_date ,37,@ColNum,@run9)
	end
else
	begin
		update mms_aReportDayWhereFromAcc
			set Yk_1 =@yk1 ,
				Yk_2 =@yk2 ,
				Yk_3 =@yk3 ,
				Yk_4 =@yk4 ,
				Yk_5 =@yk5 ,
				Yk_6 =@yk6 ,
				Yk_7 =@yk7 ,
				Yk_8 =@yk8 ,
				Yk_9 =@yk9 ,
				pbsb_1 =@pbsb1 ,
				pbsb_2 =@pbsb2 ,
				pbsb_3 =@pbsb3 ,
				pbsb_4 =@pbsb4 ,
				pbsb_5 =@pbsb5 ,
				pbsb_6 =@pbsb6 ,
				pbsb_7 =@pbsb7 ,
				zn_1=@zn1 ,
				zn_2=@zn2 ,
				zn_3=@zn3 ,
				zn_4=@zn4 ,
				sn_xn_1=@sn_xn1 ,
				sn_xn_2=@sn_xn2 ,
				sn_xn_3=@sn_xn3 ,
				sn_xn_4=@sn_xn4 ,
				sn_zn_1=@sn_zx1 ,
				sn_zn_2=@sn_zx2 ,
				sn_zn_3=@sn_zx3 ,
				sn_zn_4=@sn_zx4 ,
				run_1 =@run1 ,
				run_2 =@run2 ,
				run_3 =@run3 ,
				run_4 =@run4 ,
				run_5 =@run5 ,
				run_6 =@run6 ,
				run_7 =@run7 ,
				run_8 =@run8 ,
				run_9 =@run9 
		where R_date =@W_date and WhereFrom =@WhereFromName
		
		update mms_aReportDay_T7 
			set ReportValue =@yk1 
		  where R_Rows =1 and R_Cols =@ColNum and ReportDate=@W_date
		update mms_aReportDay_T7 
			set ReportValue =@yk2 
		  where R_Rows =2 and R_Cols =@ColNum and ReportDate=@W_date 
		update mms_aReportDay_T7 
			set ReportValue =@yk3 
		  where R_Rows =3 and R_Cols =@ColNum and ReportDate=@W_date 
		update mms_aReportDay_T7 
			set ReportValue =@yk4 
		  where R_Rows =4 and R_Cols =@ColNum and ReportDate=@W_date 
		update mms_aReportDay_T7 
			set ReportValue =@yk5 
		  where R_Rows =5 and R_Cols =@ColNum and ReportDate=@W_date 
		update mms_aReportDay_T7 
			set ReportValue =@yk6 
		  where R_Rows =6 and R_Cols =@ColNum and ReportDate=@W_date 
		update mms_aReportDay_T7 
			set ReportValue =@yk7 
		  where R_Rows =7 and R_Cols =@ColNum and ReportDate=@W_date 
		update mms_aReportDay_T7 
			set ReportValue =@yk8 
		  where R_Rows =8 and R_Cols =@ColNum and ReportDate=@W_date 
		update mms_aReportDay_T7 
			set ReportValue =@yk9 
		  where R_Rows =9 and R_Cols =@ColNum and ReportDate=@W_date 
		update mms_aReportDay_T7 
			set ReportValue =@pbsb1  
		  where R_Rows =10 and R_Cols =@ColNum and ReportDate=@W_date 
		update mms_aReportDay_T7 
			set ReportValue =@pbsb2 
		  where R_Rows =11 and R_Cols =@ColNum and ReportDate=@W_date 
		update mms_aReportDay_T7 
			set ReportValue =@pbsb3 
		  where R_Rows =12 and R_Cols =@ColNum and ReportDate=@W_date 
		update mms_aReportDay_T7 
			set ReportValue =@pbsb4 
		  where R_Rows =13 and R_Cols =@ColNum and ReportDate=@W_date 
		update mms_aReportDay_T7 
			set ReportValue =@pbsb5 
		  where R_Rows =14 and R_Cols =@ColNum and ReportDate=@W_date 
		update mms_aReportDay_T7 
			set ReportValue =@pbsb6 
		  where R_Rows =15 and R_Cols =@ColNum and ReportDate=@W_date 
		update mms_aReportDay_T7 
			set ReportValue =@pbsb7 
		  where R_Rows =16 and R_Cols =@ColNum and ReportDate=@W_date 
		update mms_aReportDay_T7 
			set ReportValue =@zn1  
		  where R_Rows =17 and R_Cols =@ColNum and ReportDate=@W_date 
		update mms_aReportDay_T7 
			set ReportValue =@zn2 
		  where R_Rows =18 and R_Cols =@ColNum and ReportDate=@W_date 
		update mms_aReportDay_T7 
			set ReportValue =@zn3 
		  where R_Rows =19 and R_Cols =@ColNum and ReportDate=@W_date 
		update mms_aReportDay_T7 
			set ReportValue =@zn4 
		  where R_Rows =20 and R_Cols =@ColNum and ReportDate=@W_date 
		update mms_aReportDay_T7 
			set ReportValue =@sn_xn1 
		  where R_Rows =21 and R_Cols =@ColNum and ReportDate=@W_date 
		update mms_aReportDay_T7 
			set ReportValue =@sn_xn2 
		  where R_Rows =22 and R_Cols =@ColNum and ReportDate=@W_date 
		update mms_aReportDay_T7 
			set ReportValue =@sn_xn3 
		  where R_Rows =23 and R_Cols =@ColNum and ReportDate=@W_date 
		update mms_aReportDay_T7 
			set ReportValue =@sn_xn4 
		  where R_Rows =24 and R_Cols =@ColNum and ReportDate=@W_date  
		update mms_aReportDay_T7 
			set ReportValue =@sn_zx1 
		  where R_Rows =25 and R_Cols =@ColNum and ReportDate=@W_date
		update mms_aReportDay_T7 
			set ReportValue =@sn_zx2 
		  where R_Rows =26 and R_Cols =@ColNum and ReportDate=@W_date 
		update mms_aReportDay_T7 
			set ReportValue =@sn_zx3 
		  where R_Rows =27 and R_Cols =@ColNum and ReportDate=@W_date 
		update mms_aReportDay_T7 
			set ReportValue =@sn_zx4 
		  where R_Rows =28 and R_Cols =@ColNum and ReportDate=@W_date 
		update mms_aReportDay_T7 
			set ReportValue =@run1  
		  where R_Rows =29 and R_Cols =@ColNum and ReportDate=@W_date  
		update mms_aReportDay_T7 
			set ReportValue =@run2 
		  where R_Rows =30 and R_Cols =@ColNum and ReportDate=@W_date
		update mms_aReportDay_T7 
			set ReportValue =@run3 
		  where R_Rows =31 and R_Cols =@ColNum and ReportDate=@W_date
		update mms_aReportDay_T7 
			set ReportValue =@run4 
		  where R_Rows =32 and R_Cols =@ColNum and ReportDate=@W_date
		update mms_aReportDay_T7 
			set ReportValue =@run5 
		  where R_Rows =33 and R_Cols =@ColNum and ReportDate=@W_date
		update mms_aReportDay_T7 
			set ReportValue =@run6 
		  where R_Rows =34 and R_Cols =@ColNum and ReportDate=@W_date
		update mms_aReportDay_T7 
			set ReportValue =@run7 
		  where R_Rows =35 and R_Cols =@ColNum and ReportDate=@W_date
		update mms_aReportDay_T7 
			set ReportValue =@run8 
		  where R_Rows =36 and R_Cols =@ColNum and ReportDate=@W_date
		update mms_aReportDay_T7 
			set ReportValue =@run9 
		  where R_Rows =37 and R_Cols =@ColNum and ReportDate=@W_date
	end
go

