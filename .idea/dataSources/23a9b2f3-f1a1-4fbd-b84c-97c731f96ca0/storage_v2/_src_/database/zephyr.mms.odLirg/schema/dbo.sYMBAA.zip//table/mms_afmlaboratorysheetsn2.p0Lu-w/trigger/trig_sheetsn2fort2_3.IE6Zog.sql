create trigger [dbo].[Trig_SheetSn2ForT2_3] on [dbo].[mms_afmLaboratorySheetSn2]
for delete
as
declare @L_date date =null
select @L_date =ls_Date  from deleted    
exec proc_aReportDay2_P2 @L_date,3
go

