 
 CREATE PROCEDURE p_killAllSpid @dbname varchar(20) AS declare @spid varchar(20) declare #spid cursor for select spid=cast(spid as varchar(20)) from master..sysprocesses where dbid=db_id(@dbname) open #spid fetch next from #spid into @spid while @@fetch_status=0 begin   exec('kill '+@spid)  fetch next from #spid into @spid end  close #spid deallocate #spid ;

 go

