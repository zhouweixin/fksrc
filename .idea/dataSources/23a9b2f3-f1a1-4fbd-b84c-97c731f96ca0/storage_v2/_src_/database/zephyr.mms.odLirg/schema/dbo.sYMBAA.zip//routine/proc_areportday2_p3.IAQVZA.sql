CREATE procedure [dbo].[proc_aReportDay2_P3]
@ClassDate date =null,
@ClassID nvarchar(50) ='',
@M_Mode int =0
as
-----条件判断变量----------
declare @tempRun int =null
--------运行情况数据变量----------
declare @HandlingCapacity_Class DECIMAL(18,4)
declare @Run_time DECIMAL(18,4) =0
declare @Stop_time DECIMAL(18,4) =0
declare @CalendarTime DECIMAL(18,4) =0
declare @WaitForWater_time DECIMAL(18,4) =0
declare @WaitForElectricity_time DECIMAL(18,4) =0
declare @WaitForFix_time DECIMAL(18,4) =0
declare @WaitForElse_time DECIMAL(18,4) =0
declare @QM_RunPercent DECIMAL(18,4) =0
declare @MineWhereFrom nvarchar(50) =''
declare @RDPC DECIMAL(18,4) =0  --Reduced daily processing capacity 折合日处理量

------------系统变量-------------------------------
declare @errString nvarchar(255)

set @tempRun =(select COUNT(*) from mms_afmPlantRun2 where  run_date=@ClassDate and ClassID =@ClassID )
if (@tempRun > 0)
	begin
-------第一步：获取运行情况数据---------------
		--set @HandlingCapacity_Class =(select handlingCapacity from mms_afmPlantRun2 where run_date =@ClassDate and classid =@ClassID);		
		--set @Run_time =(select runTime  from mms_afmPlantRun2 where run_date =@ClassDate and classid =@ClassID)
		--set @WaitForWater_time =(select waitForWaterTime  from mms_afmPlantRun2 where run_date =@ClassDate and classid =@ClassID)
		--set @WaitForElectricity_time =(select waitForElectricityTime  from mms_afmPlantRun2 where run_date =@ClassDate and classid =@ClassID)
		--set @WaitForFix_time =(select waitForFixTime  from mms_afmPlantRun2 where run_date =@ClassDate and classid =@ClassID)
		--set @WaitForElse_time =(select waitElseTime  from mms_afmPlantRun2 where run_date =@ClassDate and classid =@ClassID)
		--set @MineWhereFrom =(select minewherefrom  from mms_afmPlantRun2 where run_date =@ClassDate and classid =@ClassID)
select @HandlingCapacity_Class=handlingCapacity,
		@Run_time=runTime,
		@WaitForWater_time=waitForWaterTime,
		@WaitForElectricity_time=waitForElectricityTime,
		@WaitForFix_time=waitForFixTime,
		@WaitForElse_time=waitElseTime,
		@MineWhereFrom=minewherefrom from mms_afmPlantRun2 where run_date =@ClassDate and classid =@ClassID
		--------第二步：进行其它变量计算---------------------------
	set @CalendarTime =8
	set @Stop_time =@WaitForWater_time + @WaitForElectricity_time + @WaitForFix_time + @WaitForElse_time
	set @QM_RunPercent =100*@Run_time/@CalendarTime
	set @RDPC =@HandlingCapacity_Class/nullif(@Run_time,0)*24
		
		--------第三步：更新T3、T7表------------------
		declare @temp_Cols int =0
	
		if(@ClassID ='早班')
			set @temp_Cols =1
		if(@ClassID ='中班')
			set @temp_Cols =2
		if(@ClassID ='晚班')
			set @temp_Cols =3
			

		
		if (@M_Mode =1) ----插入
			begin
				insert into mms_aReportDay2_T3 (R_Date ,R_CID ,Run_1 ,Run_2 ,Run_3 ,Run_4 ,Run_5 ,Run_6 ,Run_7 ,Run_8 ,Run_9 )
						values(@ClassDate ,@ClassID ,@CalendarTime, @Run_time, @Stop_time,
						@WaitForWater_time, @WaitForElectricity_time, @WaitForFix_time, @WaitForElse_time,
						@QM_RunPercent,@RDPC)
				insert into mms_aReportDay2_T7 (ReportDate ,R_Rows ,R_Cols ,ReportValue )
						values(@ClassDate,29,@temp_Cols,@CalendarTime),
						(@ClassDate,30,@temp_Cols,@Run_time),
						(@ClassDate,31,@temp_Cols,@Stop_time),
						(@ClassDate,32,@temp_Cols,@WaitForWater_time),
						(@ClassDate,33,@temp_Cols,@WaitForElectricity_time),						
						(@ClassDate,34,@temp_Cols,@WaitForFix_time),
						(@ClassDate,35,@temp_Cols,@WaitForElse_time),
						(@ClassDate,36,@temp_Cols,@QM_RunPercent),
						(@ClassDate,37,@temp_Cols,@RDPC)			
			end
		if (@M_Mode =2) ----更新
			begin
				update mms_aReportDay2_T3
					set Run_1=@CalendarTime ,Run_2=@Run_time ,Run_3=@Stop_time ,Run_4=@WaitForWater_time ,
						Run_5=@WaitForElectricity_time ,Run_6=@WaitForFix_time ,Run_7 =@WaitForElse_time,
						Run_8=@QM_RunPercent ,Run_9=@RDPC 					
				where  R_Date =@ClassDate and R_CID =@ClassID
				
				update mms_aReportDay2_T7 
					set ReportValue=@CalendarTime where ReportDate =@ClassDate and R_Rows =29 and R_Cols =@temp_Cols 
				update mms_aReportDay2_T7 
					set ReportValue=@Run_time where ReportDate =@ClassDate and R_Rows =30 and R_Cols =@temp_Cols 
				update mms_aReportDay2_T7 
					set ReportValue=@Stop_time where ReportDate =@ClassDate and R_Rows =31 and R_Cols =@temp_Cols 
				update mms_aReportDay2_T7 
					set ReportValue=@WaitForWater_time where ReportDate =@ClassDate and R_Rows =32 and R_Cols =@temp_Cols 
				update mms_aReportDay2_T7 
					set ReportValue=@WaitForElectricity_time where ReportDate =@ClassDate and R_Rows =33 and R_Cols =@temp_Cols 
				update mms_aReportDay2_T7 
					set ReportValue=@WaitForFix_time where ReportDate =@ClassDate and R_Rows =34 and R_Cols =@temp_Cols 
				update mms_aReportDay2_T7 
					set ReportValue=@WaitForElse_time where ReportDate =@ClassDate and R_Rows =35 and R_Cols =@temp_Cols 
				update mms_aReportDay2_T7 
					set ReportValue=@QM_RunPercent where ReportDate =@ClassDate and R_Rows =36 and R_Cols =@temp_Cols
				update mms_aReportDay2_T7 
					set ReportValue=@RDPC where ReportDate =@ClassDate and R_Rows =37 and R_Cols =@temp_Cols  		
			end
	end
if(@M_Mode =3)  -------删除
	begin
		if (@tempRun = 0)
			begin
				delete from mms_aReportDay2_T3 where  R_Date =@ClassDate and R_CID =@ClassID
				delete from mms_aReportDay2_T7 where ReportDate =@ClassDate  and R_Cols =@temp_Cols and (R_Rows between 29 and 37)
			end
	end
go

