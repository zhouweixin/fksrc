CREATE VIEW dbo.Day_Quota_Step2
AS
SELECT     day_date, day_PS_CLL / day_PS_RunTime AS day_PS_Taixiao, 100 * (1 - day_YK_ZL / day_YK_SZL) AS day_Shuifen, day_YK_ZL / day_QM_RunTime AS day_YK_Taixiao, 
                      day_P75_L / day_YK_ZL AS day_P75, day_P38_L / day_YK_ZL AS day_P38, 100 * day_YK_Pb_JSL / day_YK_ZL AS day_YK_Pb_Pw, 100 * day_YK_Zn_JSL / day_YK_ZL AS day_YK_Zn_Pw, 
                      1000 * day_YK_Ag_JSL / day_YK_ZL AS day_YK_Ag_Pw, 100 * day_Pb_Pb_JSL / day_JKZL_Pb AS day_Pb_Pb_Pw, 100 * day_Pb_Zn_JSL / day_JKZL_Pb AS day_Pb_Zn_Pw, 
                      1000 * day_Pb_Ag_JSL / day_JKZL_Pb AS day_Pb_Ag_Pw, 100 * day_JKZL_Pb / day_YK_ZL AS day_Pb_CL, 100 * day_Zn_Pb_JSL / day_JKZL_Zn AS day_Zn_Pb_Pw, 
                      100 * day_Zn_Zn_JSL / day_JKZL_Zn AS day_Zn_Zn_Pw, 100 * day_Zn_Ag_JSL / day_JKZL_Zn AS day_Zn_Ag_Pw, 100 * day_JKZL_Zn / day_YK_ZL AS day_Zn_CL, 
                      day_YK_Pb_JSL - day_Pb_Pb_JSL - day_Zn_Pb_JSL AS day_WK_Pb_JSL, day_YK_Zn_JSL - day_Zn_Zn_JSL - day_Pb_Zn_JSL AS day_WK_Zn_JSL, 
                      day_YK_Ag_JSL - day_Zn_Ag_JSL - day_Pb_Ag_JSL AS day_WK_Ag_JSL
FROM         dbo.Day_Quota_Step1
go

