CREATE trigger [dbo].[Trig_T2ForT5_3] on [dbo].[mms_aReportDay_T2]
for delete
as
declare @L_date date =null
declare @L_CID nvarchar(50)=''
select @L_date =R_Date ,@L_CID=R_CID from deleted     
exec proc_aReportDay_P5 @L_date,3
exec proc_insertDaySumValueSn @L_date,@L_CID,3,1
exec proc_insertDaySumCombineValueSn @L_date,@L_CID,3,1
go

