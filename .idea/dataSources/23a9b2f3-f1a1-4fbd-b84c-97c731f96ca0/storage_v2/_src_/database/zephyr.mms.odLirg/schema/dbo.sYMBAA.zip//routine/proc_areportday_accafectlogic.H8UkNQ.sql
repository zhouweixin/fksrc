create procedure proc_aReportDay_AccAfectLogic
@A_Date date =null
as
declare @tempDate date =null
declare @tCount int =0
set @tCount =(select COUNT(*) from mms_aReportDay_T4_Acc 
			where R_Date >@A_Date and  MONTH(R_Date)=MONTH(@A_Date))
if(@tCount >0)
	begin 
		DECLARE TableCursor CURSOR 
		LOCAL
		FOR					
		select R_Date  
			from mms_aReportDay_T4_Acc 
			where R_Date >@A_Date and  MONTH (R_Date)=MONTH (@A_Date)
		OPEN TableCursor
		FETCH NEXT FROM TableCursor INTO @tempDate
		while @@FETCH_STATUS =0
			begin
				exec proc_aReportDay_AccAfectAction @tempDate
				FETCH NEXT FROM TableCursor INTO @tempDate
			end
		CLOSE TableCursor
		DEALLOCATE TableCursor
	end
go

