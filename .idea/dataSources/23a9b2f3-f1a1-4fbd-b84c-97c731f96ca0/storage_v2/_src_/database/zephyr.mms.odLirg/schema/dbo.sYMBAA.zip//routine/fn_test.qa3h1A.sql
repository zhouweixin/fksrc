CREATE function [dbo].[fn_test](@a_date date)
returns table
as 
return (select SUM(YK_1) yk1,SUM(YK_3) yk3,SUM(YK_5) yk5  
			from mms_aReportDay_T4
		where R_Date <=@a_date  
)
go

