 
 create procedure p_RestoreDb 
 @bkfile nvarchar(1000),   
 @dbname sysname='',      
 @dbpath nvarchar(260)='', 
 @retype nvarchar(10)='DB', 
 @filenumber int=1,   
 @overexist bit=1,        
 @password nvarchar(20)=''  
 as 
 declare @sql varchar(8000) 
   
  
 if isnull(@dbname,'')='' 
  select @sql=reverse(@bkfile) 
   ,@sql=case when charindex('.',@sql)=0 then @sql 
    else substring(@sql,charindex('.',@sql)+1,1000) end 
   ,@sql=case when charindex('\',@sql)=0 then @sql 
    else left(@sql,charindex('\',@sql)-1) end 
   ,@dbname=reverse(@sql) 
   
  
 if isnull(@dbpath,'')='' 
 begin 
  select @dbpath=rtrim(reverse(filename)) from master..sysfiles where name='master' 
  select @dbpath=reverse(substring(@dbpath,charindex('\',@dbpath),4000)) 
 end 
   
  
 set @sql='restore '+case @retype when 'LOG' then 'log ' else 'database ' end+@dbname 
  +' from disk='''+@bkfile+'''' 
  +' with file='+cast(@filenumber as varchar) 
  +case when @overexist=1 and @retype in('DB','DBNOR') then ',replace' else '' end 
  +case @retype when 'DBNOR' then ',NORECOVERY' else ',RECOVERY' end 
  +case isnull(@password,'') when '' then '' else ',PASSWORD='''+@password+'''' end 
   
 if @retype='DB' or @retype='DBNOR' 
 begin 
  
  declare @lfn nvarchar(128),@tp char(1),@i int,@s varchar(1000) 
   
  --ȡ��ݿ�汾��Ϣ 
  declare @dbVersion nvarchar(10) 
  set @dbVersion=LTRIM(RTRIM(SUBSTRING(@@version,21,6))) 
 if @dbVersion='2000' 
 	begin 
 		create table #tb(ln nvarchar(128),pn nvarchar(260),tp char(1),fgn nvarchar(128),sz numeric(20,0),Msz numeric(20,0)) 
  --�ӱ����ļ��л�ȡ��Ϣ 
  set @s='restore filelistonly from disk='''+@bkfile+'''' 
   ++case isnull(@password,'') when '' then '' else ' with PASSWORD='''+@password+'''' end 
  insert into #tb exec(@s) 
  declare #f cursor for select ln,tp from #tb 
  open #f 
  fetch next from #f into @lfn,@tp 
  set @i=0 
  while @@fetch_status=0 
  begin 
   select @sql=@sql+',move '''+@lfn+''' to '''+@dbpath+@dbname+cast(@i as nvarchar) 
    +case @tp when 'D' then '.mdf''' else '.ldf''' end 
    ,@i=@i+1 
   fetch next from #f into @lfn,@tp 
  end 
  close #f 
  deallocate #f 
 	end 
 else 
 	begin 
 	create table #tb1(ln nvarchar(128),pn nvarchar(260),tp char(1),fgn nvarchar(128),sz numeric(20,0),Msz numeric(20,0),FileId bigint,CreateLSN numeric(25,0), 
 	DropLSN numeric(25,0) NULL,UniqueID uniqueidentifier,ReadOnlyLSN numeric(25,0) NULL,ReadWriteLSN numeric(25,0) NULL,BackupSizeInBytes bigint, 
 	SourceBlockSize int,FileGroupID int,LogGroupGUID uniqueidentifier NULL,DifferentialBaseLSN numeric(25,0) NULL,DifferentialBaseGUID uniqueidentifier, 
 	IsReadOnly bit,IsPresent bit) 
  --�ӱ����ļ��л�ȡ��Ϣ 
  set @s='restore filelistonly from disk='''+@bkfile+'''' 
   ++case isnull(@password,'') when '' then '' else ' with PASSWORD='''+@password+'''' end 
  insert into #tb1 exec(@s) 
  declare #f cursor for select ln,tp from #tb1 
  open #f 
  fetch next from #f into @lfn,@tp 
  set @i=0 
  while @@fetch_status=0 
  begin 
   select @sql=@sql+',move '''+@lfn+''' to '''+@dbpath+@dbname+cast(@i as nvarchar) 
    +case @tp when 'D' then '.mdf''' else '.ldf''' end 
    ,@i=@i+1 
   fetch next from #f into @lfn,@tp 
  end 
  close #f 
  deallocate #f 
 	end 
  
 end 
   
  
 exec(@sql);

 go

