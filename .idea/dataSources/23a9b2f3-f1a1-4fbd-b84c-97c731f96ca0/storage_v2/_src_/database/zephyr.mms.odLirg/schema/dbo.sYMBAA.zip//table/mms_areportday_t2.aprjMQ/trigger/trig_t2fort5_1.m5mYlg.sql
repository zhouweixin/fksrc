CREATE trigger [dbo].[Trig_T2ForT5_1] on [dbo].[mms_aReportDay_T2]
for insert
as
declare @L_date date =null
declare @L_CID nvarchar(50)=''
select @L_date =R_Date ,@L_CID=R_CID from inserted    
exec proc_aReportDay_P5 @L_date,1
exec proc_aReportDay_WhereFromAcc_Logic @L_date
exec proc_insertDaySumValueSn @L_date,@L_CID,1,1
exec proc_insertDaySumCombineValueSn @L_date,@L_CID,1,1
go

