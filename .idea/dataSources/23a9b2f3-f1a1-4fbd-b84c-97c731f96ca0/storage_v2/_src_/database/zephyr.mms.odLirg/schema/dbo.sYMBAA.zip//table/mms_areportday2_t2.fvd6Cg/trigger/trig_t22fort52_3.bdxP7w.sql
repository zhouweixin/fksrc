CREATE trigger [dbo].[Trig_T22ForT52_3] on [dbo].[mms_aReportDay2_T2]
for delete
as
declare @L_date date =null
select @L_date =R_Date  from deleted     
exec proc_aReportDay2_P5 @L_date,3
go

