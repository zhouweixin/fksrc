create trigger Trig_forYKBalance_Delete on dbo.mms_afmYkWeightList
for delete
as
declare @L_date date =null 
select @L_date =wl_date    from deleted   
exec proc_aReportYKBalance @L_date
go

