Create procedure [dbo].[proc_CreateDaySumTypical]
@A_Date date =null
as
declare @c_count int =0
select @c_count=COUNT(*) from mms_aTypicalDaySummry where MonthDate=@A_Date 
if(@c_count=0)
begin
	insert into mms_aTypicalDaySummry values(convert(varchar(10),@A_Date,23),'0101','原矿','处理原矿量','吨',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0102','原矿','铅品位','%',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0103','原矿','铅金属量','吨',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0104','原矿','锌品位','%',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0105','原矿','锌金属量','吨',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0106','原矿','锑品位','%',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0107','原矿','锑金属量','吨',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0108','原矿','锡品位','%',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0109','原矿','锡金属量','吨',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0201','铅锑精矿','实物量','吨',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0202','铅锑精矿','铅品位','%',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0203','铅锑精矿','铅金属量','吨',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0204','铅锑精矿','铅回收率','%',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0205','铅锑精矿','锑品位','%',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0206','铅锑精矿','锑金属量','吨',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0207','铅锑精矿','锑回收率','%',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0301','锡细泥','实物量','吨',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0302','锡细泥','锡品位','%',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0303','锡细泥','锡金属量','吨',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0304','锡细泥','锡回收率','%',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0401','锡重选','实物量','吨',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0402','锡重选','锡品位','%',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0403','锡重选','锡金属量','吨',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0404','锡重选','锡回收率','%',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0501','锌精矿','实物量','吨',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0502','锌精矿','锌品位','%',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0503','锌精矿','锌金属量','吨',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0504','锌精矿','锌回收率','%',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0601','运行情况','日历世间','h',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0602','运行情况','行车时间','h',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0603','运行情况','停车时间','h',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0604','运行情况','待水','h',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0605','运行情况','待电','h',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0606','运行情况','维修','h',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0607','运行情况','其它','h',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0608','运行情况','球磨机运转率','%',0,0,0,0,0,0,0,0),
		(convert(varchar(10),@A_Date,23),'0609','运行情况','平均日处理','吨',0,0,0,0,0,0,0,0)
	end
go

