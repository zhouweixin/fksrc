/*从班组指标和品位指标合并视图中查询计算指标值*/
CREATE VIEW dbo.Class_Calc_Step2
AS
SELECT     date AS s2date, c1 AS s2c1, c6 / c4 AS PStaixiao, Yk_ZL / c5 AS QMTaixiao, Yk_ZL * pw1 / 100 AS YK_Pb_JSL, Yk_ZL * pw2 / 100 AS YK_Zn_JSL, Yk_ZL * pw3 / 1000 AS YK_Ag_JSL, 
                      100 * JKCL_Pb_1 / JKCL_Pb_2 AS JKCL_Pb, Yk_ZL * JKCL_Pb_1 / JKCL_Pb_2 AS JKZL_Pb, pw4 / 100 * Yk_ZL * JKCL_Pb_1 / JKCL_Pb_2 AS Pb_Pb_JSL, 
                      pw5 / 100 * Yk_ZL * JKCL_Pb_1 / JKCL_Pb_2 AS Pb_Zn_JSL, pw6 / 1000 * Yk_ZL * JKCL_Pb_1 / JKCL_Pb_2 AS Pb_Ag_JSL, 100 * JKCL_Zn_1 / JKCL_Zn_2 AS JKCL_Zn, 
                      Yk_ZL * JKCL_Zn_1 / JKCL_Zn_2 AS JKZL_Zn, pw10 / 100 * Yk_ZL * JKCL_Zn_1 / JKCL_Zn_2 AS Zn_Pb_JSL, pw11 / 100 * Yk_ZL * JKCL_Zn_1 / JKCL_Zn_2 AS Zn_Zn_JSL, 
                      pw12 / 1000 * Yk_ZL * JKCL_Zn_1 / JKCL_Zn_2 AS Zn_Ag_JSL, Yk_ZL * ((1 - JKCL_Zn_1 / JKCL_Zn_2) - JKCL_Pb_1 / JKCL_Pb_2) AS Wk_ZL, (pw13 / 100 * Yk_ZL) * ((1 - JKCL_Zn_1 / JKCL_Zn_2) 
                      - JKCL_Pb_1 / JKCL_Pb_2) AS Wk_Pb_JSL, (pw14 / 100 * Yk_ZL) * ((1 - JKCL_Zn_1 / JKCL_Zn_2) - JKCL_Pb_1 / JKCL_Pb_2) AS Wk_Zn_JSL, (pw14 / 1000 * Yk_ZL) * ((1 - JKCL_Zn_1 / JKCL_Zn_2) 
                      - JKCL_Pb_1 / JKCL_Pb_2) AS Wk_Ag_JSL, Yk_ZL * c8 AS P75_L, Yk_ZL * c9 AS P38_L
FROM         dbo.Class_Calc_Step1
go

