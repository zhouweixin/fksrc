create procedure proc_aReportRunMonth_Logic
@A_Date date =null
as
declare @tempDate date =null
declare @tCount int =0
set @tCount =(select COUNT(*) from mms_aReportDay_T6 
			where R_Date >=@A_Date and  year(R_Date)=year(@A_Date))
if(@tCount >0)
	begin 
		DECLARE TableCursor CURSOR 
		LOCAL
		FOR					
		select distinct R_Date  
			from mms_aReportDay_T6 
			where R_Date >=@A_Date and  year (R_Date)=year (@A_Date)
		OPEN TableCursor
		FETCH NEXT FROM TableCursor INTO @tempDate
		while @@FETCH_STATUS =0
			begin
				exec proc_aReportRunMonth @tempDate
				FETCH NEXT FROM TableCursor INTO @tempDate
			end
		CLOSE TableCursor
		DEALLOCATE TableCursor
	end
go

