create trigger [dbo].[Trig_SheetSn2ForT2_2] on [dbo].[mms_afmLaboratorySheetSn2]
for update
as
declare @L_date date =null
select @L_date =ls_Date  from inserted    
exec proc_aReportDay2_P2 @L_date,2
go

