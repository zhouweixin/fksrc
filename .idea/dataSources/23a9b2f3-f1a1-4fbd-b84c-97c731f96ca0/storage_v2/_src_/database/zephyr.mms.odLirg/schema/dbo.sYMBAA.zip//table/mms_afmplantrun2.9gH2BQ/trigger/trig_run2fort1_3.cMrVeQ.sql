CREATE trigger [dbo].[Trig_Run2ForT1_3] on [dbo].[mms_afmPlantRun2]
for delete
as
declare @L_date date =null
declare @C_ID nvarchar(50) =''
select @L_date =run_date ,@C_ID =classid from deleted     
--exec proc_aReportDay2_P1 @L_date,@C_ID,3
--exec proc_aReportDay2_P3 @L_date,@C_ID,3
exec proc_insert2DaySumValue @L_date,@C_ID,3,1

exec proc_CreateDaySumCombineTypical @L_date
exec proc_insertDaySumCombineValue @L_date,@C_ID,3,1
go

