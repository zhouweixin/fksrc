CREATE trigger [dbo].[Trig_T22ForT52_1] on [dbo].[mms_aReportDay2_T2]
for insert
as
declare @L_date date =null
select @L_date =R_Date  from inserted    
exec proc_aReportDay2_P5 @L_date,1
exec proc_aReportDay2_WhereFromAcc_Logic @L_date
go

