CREATE trigger [dbo].[Trig_T4ForT4Acc_Delete] on [dbo].[mms_aReportDay_T4]
for delete
as
declare @L_date date =null
select @L_date =R_Date      from deleted    
exec proc_aReportDay_AccStatus @L_date,3,1
exec proc_aReportMonth_Logic @L_date
exec proc_aReportYk_Logic @L_date
go

