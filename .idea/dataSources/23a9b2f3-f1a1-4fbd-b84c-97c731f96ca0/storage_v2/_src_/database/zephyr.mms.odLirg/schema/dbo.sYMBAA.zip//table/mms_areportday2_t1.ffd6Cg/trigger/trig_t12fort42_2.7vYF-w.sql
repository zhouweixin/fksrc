CREATE trigger [dbo].[Trig_T12ForT42_2] on [dbo].[mms_aReportDay2_T1]
for update
as
declare @L_date date =null
declare @C_CID nvarchar(50) =''
select @L_date =R_Date,@C_CID=R_CID  from inserted    
exec proc_aReportDay2_P4 @L_date,2
exec proc_aReportDay2_WhereFromAcc_Logic @L_date
exec proc_aReportYKBalance @L_date 
exec proc_insert2DaySumValue @L_date,@C_CID,2,2

exec proc_insertDaySumCombineValue @L_date,@C_CID,2,2
go

