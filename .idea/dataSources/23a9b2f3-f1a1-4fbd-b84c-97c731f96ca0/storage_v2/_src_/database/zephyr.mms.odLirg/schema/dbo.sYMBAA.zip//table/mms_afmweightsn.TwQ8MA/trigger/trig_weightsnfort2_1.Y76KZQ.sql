CREATE trigger [dbo].[Trig_WeightSnForT2_1] on [dbo].[mms_afmWeightSn]
for insert
as
declare @L_date date =null
select @L_date =snw_date   from inserted    
exec proc_aReportDay_P2 @L_date,1
exec proc_aReportDay2_P2 @L_date,1
exec proc_insertDaySumValueSn @L_date,'',1,2
exec proc_insertDaySumCombineValueSn @L_date,'',1,2
go

