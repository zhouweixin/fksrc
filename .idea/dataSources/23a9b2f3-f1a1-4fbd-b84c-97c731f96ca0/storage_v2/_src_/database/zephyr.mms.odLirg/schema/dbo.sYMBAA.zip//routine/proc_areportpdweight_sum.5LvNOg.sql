--select * from mms_aReportPDWeight
CREATE procedure [dbo].[proc_aReportPDWeight_Sum]
@S_date date =null
as 
declare @C8_Sum decimal(18,2) =0
declare @C16_Sum decimal(18,2) =0
declare @C24_Sum decimal(18,2) =0

declare @C81 decimal(18,2) =0
declare @C161 decimal(18,2) =0
declare @C241 decimal(18,2) =0

declare @C8_2 decimal(18,2) =0
declare @C16_2 decimal(18,2) =0
declare @C24_2 decimal(18,2) =0


----------------计算1系列---------------------------------------------------


select @C81=C8 ,@C161=C16, @C241=C24 from mms_aReportPDWeight
 where R_date =@S_date AND R_ValueID='285'

select @C8_2=C8 ,@C16_2=C16, @C24_2=C24 from mms_aReportPDWeight 
	where R_date =@S_date and R_ValueID='287'
	
set @C8_Sum =@C81-@C8_2
set @C16_Sum =@C161-@C16_2
set @C24_Sum =@C241-@C24_2

declare @t_c int =0
select @t_c=COUNT(*) from mms_aReportPDWeight where R_date =@S_date and R_OrderCode =3
if(@t_c=0)
	insert into mms_aReportPDWeight values(3,'','Ⅰ系列','小计',@C8_Sum,@C16_Sum,@C24_Sum,@S_date)
if(@t_c >0)
	update 	mms_aReportPDWeight set C8 =@C8_Sum,C16=@C16_Sum,C24=@C24_Sum
	where R_date =@S_date and R_OrderCode =3
---------------------处理量更新到运行情况表---begin
if(@C8_Sum>0)
	begin
		declare @t_plantrun8 int =0
		select @t_plantrun8 =COUNT(*) from mms_afmPlantRun where run_date=@S_date and classid ='晚班'

		if(@t_plantrun8 =0)
			insert into mms_afmPlantRun values(dbo.fn_getPlantRunNewID(),@S_date,'晚班',@C8_Sum,8,0,0,0,0,'高椅山矿','23冶')
		else
			update mms_afmPlantRun set handlingCapacity =@C8_Sum 
			where run_date =@S_date and classid ='晚班'	
	end
if(@C16_Sum >0)
	begin	
		declare @t_plantrun16 int =0
		select @t_plantrun16 =COUNT(*) from mms_afmPlantRun where run_date =@S_date and classid ='早班'
		if(@t_plantrun16 =0)
			insert into mms_afmPlantRun values(dbo.fn_getPlantRunNewID(),@S_date,'早班',@C16_Sum,8,0,0,0,0,'高椅山矿','23冶')
		else
			update mms_afmPlantRun set handlingCapacity =@C16_Sum 
			where run_date =@S_date and classid ='早班'	
	end	
if(@C24_Sum>0)
	begin
		declare @t_plantrun24 int =0
		select @t_plantrun24 =COUNT(*) from mms_afmPlantRun where run_date =@S_date and classid ='中班'
		if(@t_plantrun24 =0)
			insert into mms_afmPlantRun values(dbo.fn_getPlantRunNewID(),@S_date,'中班',@C24_Sum,8,0,0,0,0,'高椅山矿','23冶')
		else
			update mms_afmPlantRun set handlingCapacity =@C24_Sum 
			where run_date =@S_date and classid ='中班'	
	end
------------------------------end

----------------计算2系列---------------------------------------------------
declare @C8_Sum2 decimal(18,2) =0
declare @C16_Sum2 decimal(18,2) =0
declare @C24_Sum2 decimal(18,2) =0

declare @C281 decimal(18,2) =0
declare @C2161 decimal(18,2) =0
declare @C2241 decimal(18,2) =0

declare @C28_2 decimal(18,2) =0
declare @C216_2 decimal(18,2) =0
declare @C224_2 decimal(18,2) =0

select @C281=C8 ,@C2161=C16, @C2241=C24 from mms_aReportPDWeight 
	where R_date =@S_date AND R_ValueID='286'

select @C28_2=C8 ,@C216_2=C16, @C224_2=C24 from mms_aReportPDWeight 
	where R_date =@S_date and R_ValueID='288'
	
set @C8_Sum2 =@C281-@C28_2
set @C16_Sum2 =@C2161-@C216_2
set @C24_Sum2 =@C2241-@C224_2

select @t_c=COUNT(*) from mms_aReportPDWeight where R_date =@S_date and R_OrderCode =6
if(@t_c=0)
	insert into mms_aReportPDWeight values(6,'','Ⅱ系列','小计',@C8_Sum2,@C16_Sum2,@C24_Sum2,@S_date)
if(@t_c >0)
	update 	mms_aReportPDWeight set C8 =@C8_Sum2,C16=@C16_Sum2,C24=@C24_Sum2
	where R_date =@S_date and R_OrderCode =6
---------------------处理量更新到运行情况表Ⅱ---begin
if(@C8_Sum2>0)
	begin
		declare @t2_plantrun8 int =0
		select @t2_plantrun8 =COUNT(*) from mms_afmPlantRun2 where run_date=@S_date and classid ='晚班'

		if(@t2_plantrun8 =0)
			insert into mms_afmPlantRun2 values(dbo.fn_getPlantRun2NewID(),@S_date,'晚班',@C8_Sum2,8,0,0,0,0,'高椅山矿','23冶')
		else
			update mms_afmPlantRun2 set handlingCapacity =@C8_Sum2
			where run_date =@S_date and classid ='晚班'	
	end
if(@C16_Sum2 >0)
	begin	
		declare @t2_plantrun16 int =0
		select @t2_plantrun16 =COUNT(*) from mms_afmPlantRun2 where run_date =@S_date and classid ='早班'
		if(@t2_plantrun16 =0)
			insert into mms_afmPlantRun2 values(dbo.fn_getPlantRun2NewID(),@S_date,'早班',@C16_Sum2,8,0,0,0,0,'高椅山矿','23冶')
		else
			update mms_afmPlantRun2 set handlingCapacity =@C16_Sum2 
			where run_date =@S_date and classid ='早班'	
	end	
if(@C24_Sum2>0)
	begin
		declare @t2_plantrun24 int =0
		select @t2_plantrun24 =COUNT(*) from mms_afmPlantRun2 where run_date =@S_date and classid ='中班'
		if(@t2_plantrun24 =0)
			insert into mms_afmPlantRun2 values(dbo.fn_getPlantRun2NewID(),@S_date,'中班',@C24_Sum2,8,0,0,0,0,'高椅山矿','23冶')
		else
			update mms_afmPlantRun2 set handlingCapacity =@C24_Sum2 
			where run_date =@S_date and classid ='中班'	
	end
------------------------------end
go

