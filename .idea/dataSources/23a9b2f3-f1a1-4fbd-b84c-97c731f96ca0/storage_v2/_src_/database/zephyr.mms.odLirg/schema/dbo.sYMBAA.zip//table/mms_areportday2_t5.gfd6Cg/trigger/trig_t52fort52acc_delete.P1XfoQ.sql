create trigger [dbo].[Trig_T52ForT52Acc_Delete] on [dbo].[mms_aReportDay2_T5]
for delete
as
declare @L_date date =null
select @L_date =R_Date      from deleted    
exec proc_aReportDay2_AccStatus @L_date,3,2
go

