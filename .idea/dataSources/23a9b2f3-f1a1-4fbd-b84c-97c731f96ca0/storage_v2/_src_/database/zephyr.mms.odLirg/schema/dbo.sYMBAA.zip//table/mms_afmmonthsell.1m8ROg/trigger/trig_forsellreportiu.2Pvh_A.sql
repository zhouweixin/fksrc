------------------sheetA表上的三类触发器-------------------------------
CREATE trigger [dbo].[Trig_forSellReportIU] on [dbo].[mms_afmMonthSell]
for insert ,update
as
declare @L_date date =null 
select @L_date =SellMonth  from inserted
exec proc_aReportJKSell @L_date   
-------------找到日期之后的所有日期更新--------------------
declare @tCount int =0
declare @tempDate date =''
set @tCount =(select COUNT(*) from mms_afmMonthSell 
			where SellMonth >@L_date and YEAR(SellMonth)=YEAR(@L_date))
if(@tCount >0)
	begin 
		DECLARE TableCursor CURSOR 
		LOCAL
		FOR					
		select distinct SellMonth  
			from mms_afmMonthSell 
			where SellMonth >@L_date and YEAR(SellMonth)=YEAR(@L_date)
		OPEN TableCursor
		FETCH NEXT FROM TableCursor INTO @tempDate
		while @@FETCH_STATUS =0
			begin
				exec proc_aReportJKSell @tempDate 
				--print @tempDate
				FETCH NEXT FROM TableCursor INTO @tempDate
			end
		CLOSE TableCursor
		DEALLOCATE TableCursor
	end
go

