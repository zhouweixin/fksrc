CREATE VIEW dbo.mms_YKWeightSummry_Report
AS
SELECT     wl_date, COUNT(*) AS CarCount, SUM(g1w3) AS G1w3_Sum, SUM(g2w3) AS G2w3_Sum, wherefrom
FROM         dbo.mms_afmYkWeightList
GROUP BY wherefrom, wl_date
go

