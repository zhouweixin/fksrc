create procedure [dbo].[proc_aReportDay2_P2]
@ClassDate date =null,
@M_Mode int =0
as
-----条件判断变量----------
declare @Sn_Weight int =null
declare @Sn_Sheet int =null
-------锡称重数据-------------
declare @snZX_Class0_W DECIMAL(18,4) =0
declare @snZX_Class8_W DECIMAL(18,4) =0
declare @snZX_Class16_W DECIMAL(18,4) =0
declare @snXN_W DECIMAL(18,4) =0
-------锡化验数据-----------------
declare @snZX_Class0_Q DECIMAL(18,4) =0
declare @snZX_Class8_Q DECIMAL(18,4) =0
declare @snZX_Class16_Q DECIMAL(18,4) =0
declare @snXN_Q DECIMAL(18,4) =0

---------------计算变量，锡细泥------------------------------------
declare @SnXN_Weight DECIMAL(18,4) =0
declare @SnXN_Quota_Sn DECIMAL(18,4) =0
declare @SnXN_Metallicity_Sn DECIMAL(18,4) =0
declare @SnXN_ConcentrateRecovery_Sn DECIMAL(18,4) =0
---------------计算变量，锡重选------------------------------------
declare @SnZX_Weight0 DECIMAL(18,4) =0
declare @SnZX_Quota_Sn0 DECIMAL(18,4) =0
declare @SnZX_Metallicity_Sn0 DECIMAL(18,4) =0
declare @SnZX_ConcentrateRecovery_Sn0 DECIMAL(18,4) =0

declare @SnZX_Weight8 DECIMAL(18,4) =0
declare @SnZX_Quota_Sn8 DECIMAL(18,4) =0
declare @SnZX_Metallicity_Sn8 DECIMAL(18,4) =0
declare @SnZX_ConcentrateRecovery_Sn8 DECIMAL(18,4) =0

declare @SnZX_Weight16 DECIMAL(18,4) =0
declare @SnZX_Quota_Sn16 DECIMAL(18,4) =0
declare @SnZX_Metallicity_Sn16 DECIMAL(18,4) =0
declare @SnZX_ConcentrateRecovery_Sn16 DECIMAL(18,4) =0


set @Sn_Sheet =(select COUNT(*) from mms_afmLaboratorySheetSn where ls_Date =@ClassDate)
set @Sn_Weight=(select COUNT(*) from mms_afmWeightSn where snw_date =@ClassDate )
	--条件判断-------------------
if(@Sn_Sheet +@Sn_Weight =2)
	begin
	------------------------------------------------------
	------条件满足，获取原始数据---------------------------
	-------------------------------------------------------
		-------第一步：获取锡称重数据------------------
		set @snXN_W=(select snXN from mms_afmWeightSn where snw_date =@ClassDate )
		set @snZX_Class0_W=(select snZX_class0 from mms_afmWeightSn where snw_date =@ClassDate )
		set @snZX_Class8_W=(select snZX_class8 from mms_afmWeightSn where snw_date =@ClassDate )
		set @snZX_Class16_W=(select snZX_class16 from mms_afmWeightSn where snw_date =@ClassDate )
		-------第二步：获取锡化验数据------------------
		set @snXN_Q=(select snXN from mms_afmLaboratorySheetSn where ls_Date =@ClassDate )
		set @snZX_Class0_Q=(select SnZX_0class from mms_afmLaboratorySheetSn where ls_Date =@ClassDate )
		set @snZX_Class8_Q=(select snZX_8class from mms_afmLaboratorySheetSn where ls_Date =@ClassDate )
		set @snZX_Class16_Q=(select snZX_16class from mms_afmLaboratorySheetSn where ls_Date =@ClassDate )			
	-------------------------------------------------------
	------获取原始数据后，进行其它变量计算---------------------------
	-------------------------------------------------------
		---------第三步：计算锡数据------------------------------
		---------锡细泥计算--------------------------------------
		set @SnXN_Weight=@snXN_W
		set @SnXN_Quota_Sn=@snXN_Q/100
		set @SnXN_Metallicity_Sn=@SnXN_Weight*@SnXN_Quota_Sn
		--set @SnXN_ConcentrateRecovery_Sn =@SnXN_Metallicity_Sn /@yk_sn_B
		---------锡重选计算----早，中，晚----------------------------------
		set @SnZX_Weight0 =@snZX_Class0_W
		set @SnZX_Quota_Sn0  =@snZX_Class0_Q/100
		set @SnZX_Metallicity_Sn0 = @SnZX_Weight0 *@SnZX_Quota_Sn0
		
		set @SnZX_Weight8 =@snZX_Class8_W
		set @SnZX_Quota_Sn8  =@snZX_Class8_Q/100
		set @SnZX_Metallicity_Sn8 = @SnZX_Weight8  *@SnZX_Quota_Sn8
		
		set @SnZX_Weight16 =@snZX_Class16_W
		set @SnZX_Quota_Sn16  =@snZX_Class16_Q/100
		set @SnZX_Metallicity_Sn16 = @SnZX_Weight16 *@SnZX_Quota_Sn16	
		
		set @SnXN_Quota_Sn=@SnXN_Quota_Sn*100
		set @SnZX_Quota_Sn0  =@SnZX_Quota_Sn0*100
		set @SnZX_Quota_Sn8  =@SnZX_Quota_Sn8*100
		set @SnZX_Quota_Sn16  =@SnZX_Quota_Sn16*100
		
		if(@M_Mode =1)
			begin
		insert into mms_aReportDay2_T2(R_Date,R_CID ,Sn_XN_1,Sn_XN_2,Sn_XN_3,Sn_XN_4,Sn_ZX_1,Sn_ZX_2,Sn_ZX_3,Sn_ZX_4) 
			values(@ClassDate ,'早班', 0,0,0,0,@SnZX_Weight0,@SnZX_Quota_Sn0,@SnZX_Metallicity_Sn0,0)
		insert into mms_aReportDay2_T2(R_Date,R_CID ,Sn_XN_1,Sn_XN_2,Sn_XN_3,Sn_XN_4,Sn_ZX_1,Sn_ZX_2,Sn_ZX_3,Sn_ZX_4) 
			values(@ClassDate ,'中班', 0,0,0,0,@SnZX_Weight8,@SnZX_Quota_Sn8,@SnZX_Metallicity_Sn8,0)
		insert into mms_aReportDay2_T2(R_Date,R_CID ,Sn_XN_1,Sn_XN_2,Sn_XN_3,Sn_XN_4,Sn_ZX_1,Sn_ZX_2,Sn_ZX_3,Sn_ZX_4) 
			values(@ClassDate ,'晚班', @SnXN_Weight,@SnXN_Quota_Sn,@SnXN_Metallicity_Sn,0,@SnZX_Weight16,@SnZX_Quota_Sn16,@SnZX_Metallicity_Sn16,0)
			----------------------细泥数据，早班----------------------------------------------------------------------
				insert into mms_aReportDay2_T7(ReportDate ,R_Rows ,R_Cols ,ReportValue ) values(@ClassDate ,21,1,0)
				insert into mms_aReportDay2_T7(ReportDate ,R_Rows ,R_Cols ,ReportValue ) values(@ClassDate ,22,1,0)
				insert into mms_aReportDay2_T7(ReportDate ,R_Rows ,R_Cols ,ReportValue ) values(@ClassDate ,23,1,0)
				insert into mms_aReportDay2_T7(ReportDate ,R_Rows ,R_Cols ,ReportValue ) values(@ClassDate ,24,1,0)
			----------------------细泥数据，中班----------------------------------------------------------------------
				insert into mms_aReportDay2_T7(ReportDate ,R_Rows ,R_Cols ,ReportValue ) values(@ClassDate ,21,2,0)
				insert into mms_aReportDay2_T7(ReportDate ,R_Rows ,R_Cols ,ReportValue ) values(@ClassDate ,22,2,0)
				insert into mms_aReportDay2_T7(ReportDate ,R_Rows ,R_Cols ,ReportValue ) values(@ClassDate ,23,2,0)
				insert into mms_aReportDay2_T7(ReportDate ,R_Rows ,R_Cols ,ReportValue ) values(@ClassDate ,24,2,0)
			----------------------细泥数据，晚班----------------------------------------------------------------------
				insert into mms_aReportDay2_T7(ReportDate ,R_Rows ,R_Cols ,ReportValue ) values(@ClassDate ,21,3,@SnXN_Weight)
				insert into mms_aReportDay2_T7(ReportDate ,R_Rows ,R_Cols ,ReportValue ) values(@ClassDate ,22,3,@SnXN_Quota_Sn)
				insert into mms_aReportDay2_T7(ReportDate ,R_Rows ,R_Cols ,ReportValue ) values(@ClassDate ,23,3,@SnXN_Metallicity_Sn)
				insert into mms_aReportDay2_T7(ReportDate ,R_Rows ,R_Cols ,ReportValue ) values(@ClassDate ,24,3,0)
			----------------------重选数据，早班----------------------------------------------------------------------
				insert into mms_aReportDay2_T7(ReportDate ,R_Rows ,R_Cols ,ReportValue ) values(@ClassDate ,25,1,@SnZX_Weight0)
				insert into mms_aReportDay2_T7(ReportDate ,R_Rows ,R_Cols ,ReportValue ) values(@ClassDate ,26,1,@SnZX_Quota_Sn0)
				insert into mms_aReportDay2_T7(ReportDate ,R_Rows ,R_Cols ,ReportValue ) values(@ClassDate ,27,1,@SnZX_Metallicity_Sn0)
				insert into mms_aReportDay2_T7(ReportDate ,R_Rows ,R_Cols ,ReportValue ) values(@ClassDate ,28,1,0)
			----------------------重选数据，中班----------------------------------------------------------------------
				insert into mms_aReportDay2_T7(ReportDate ,R_Rows ,R_Cols ,ReportValue ) values(@ClassDate ,25,2,@SnZX_Weight8)
				insert into mms_aReportDay2_T7(ReportDate ,R_Rows ,R_Cols ,ReportValue ) values(@ClassDate ,26,2,@SnZX_Quota_Sn8)
				insert into mms_aReportDay2_T7(ReportDate ,R_Rows ,R_Cols ,ReportValue ) values(@ClassDate ,27,2,@SnZX_Metallicity_Sn8)
				insert into mms_aReportDay2_T7(ReportDate ,R_Rows ,R_Cols ,ReportValue ) values(@ClassDate ,28,2,0)
			----------------------重选数据，晚班----------------------------------------------------------------------
				insert into mms_aReportDay2_T7(ReportDate ,R_Rows ,R_Cols ,ReportValue ) values(@ClassDate ,25,3,@SnZX_Weight16)
				insert into mms_aReportDay2_T7(ReportDate ,R_Rows ,R_Cols ,ReportValue ) values(@ClassDate ,26,3,@SnZX_Quota_Sn16)
				insert into mms_aReportDay2_T7(ReportDate ,R_Rows ,R_Cols ,ReportValue ) values(@ClassDate ,27,3,@SnZX_Metallicity_Sn16)
				insert into mms_aReportDay2_T7(ReportDate ,R_Rows ,R_Cols ,ReportValue ) values(@ClassDate ,28,3,0)		

			end
		if(@M_Mode =2)
			begin
				delete from mms_aReportDay2_T2 where R_Date =@ClassDate 
				insert into mms_aReportDay2_T2(R_Date,R_CID ,Sn_XN_1,Sn_XN_2,Sn_XN_3,Sn_XN_4,Sn_ZX_1,Sn_ZX_2,Sn_ZX_3,Sn_ZX_4) 
					values(@ClassDate ,'早班', 0,0,0,0,@SnZX_Weight0,@SnZX_Quota_Sn0,@SnZX_Metallicity_Sn0,0)
				insert into mms_aReportDay2_T2(R_Date,R_CID ,Sn_XN_1,Sn_XN_2,Sn_XN_3,Sn_XN_4,Sn_ZX_1,Sn_ZX_2,Sn_ZX_3,Sn_ZX_4) 
					values(@ClassDate ,'中班', 0,0,0,0,@SnZX_Weight8,@SnZX_Quota_Sn8,@SnZX_Metallicity_Sn8,0)
				insert into mms_aReportDay2_T2(R_Date,R_CID ,Sn_XN_1,Sn_XN_2,Sn_XN_3,Sn_XN_4,Sn_ZX_1,Sn_ZX_2,Sn_ZX_3,Sn_ZX_4) 
					values(@ClassDate ,'晚班', @SnXN_Weight,@SnXN_Quota_Sn,@SnXN_Metallicity_Sn,0,@SnZX_Weight16,@SnZX_Quota_Sn16,@SnZX_Metallicity_Sn16,0)
				----------细泥数据-------------
				update mms_aReportDay2_T7 set ReportValue =@SnXN_Weight where ReportDate =@ClassDate and R_Rows =21 and R_Cols =3
				update mms_aReportDay2_T7 set ReportValue =@SnXN_Quota_Sn where ReportDate =@ClassDate and R_Rows =22 and R_Cols =3
				update mms_aReportDay2_T7 set ReportValue =@SnXN_Metallicity_Sn where ReportDate =@ClassDate and R_Rows =23 and R_Cols =3
				-----------重选数据，早班--------------
				update mms_aReportDay2_T7 set ReportValue =@SnZX_Weight0 where ReportDate =@ClassDate and R_Rows =25 and R_Cols =1
				update mms_aReportDay2_T7 set ReportValue =@SnZX_Quota_Sn0 where ReportDate =@ClassDate and R_Rows =26 and R_Cols =1
				update mms_aReportDay2_T7 set ReportValue =@SnZX_Metallicity_Sn0 where ReportDate =@ClassDate and R_Rows =27 and R_Cols =1
				-----------重选数据，中班--------------
				update mms_aReportDay2_T7 set ReportValue =@SnZX_Weight8 where ReportDate =@ClassDate and R_Rows =25 and R_Cols =2
				update mms_aReportDay2_T7 set ReportValue =@SnZX_Quota_Sn8 where ReportDate =@ClassDate and R_Rows =26 and R_Cols =2
				update mms_aReportDay2_T7 set ReportValue =@SnZX_Metallicity_Sn8 where ReportDate =@ClassDate and R_Rows =27 and R_Cols =2
				-----------重选数据，晚班--------------
				update mms_aReportDay2_T7 set ReportValue =@SnZX_Weight16 where ReportDate =@ClassDate and R_Rows =25 and R_Cols =3
				update mms_aReportDay2_T7 set ReportValue =@SnZX_Quota_Sn16 where ReportDate =@ClassDate and R_Rows =26 and R_Cols =3
				update mms_aReportDay2_T7 set ReportValue =@SnZX_Metallicity_Sn16 where ReportDate =@ClassDate and R_Rows =27 and R_Cols =3

			end 				
	end
if(@M_Mode =3)
begin
	if(@Sn_Sheet +@Sn_Weight =0)
		begin
			delete from mms_aReportDay2_T2 where R_Date =@ClassDate 
			delete from mms_aReportDay2_T7 where ReportDate =@ClassDate  and (R_Cols between 1 and 3) and (R_Rows between 21 and 28)
		end	
end
go

