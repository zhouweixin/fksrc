/****** Script for SelectTopNRows command from SSMS  ******/
CREATE VIEW dbo._VDosingCalc_Step2
AS
SELECT     DosingLocation, MedicamentType, MAX(AccValue) - MIN(AccValue) AS value, MAX(AccValue) AS maxValue, MIN(AccValue) AS minValue, CONVERT(nvarchar(10), 
                      Timestampe, 120) AS cs2date, (CASE WHEN DATENAME(hh, Timestampe) >= 0 AND DATENAME(hh, Timestampe) < 8 THEN '8' WHEN DATENAME(hh, Timestampe) 
                      >= 8 AND DATENAME(hh, Timestampe) < 16 THEN '16' WHEN DATENAME(hh, Timestampe) >= 16 AND DATENAME(hh, Timestampe) < 24 THEN '24' END) AS hh
FROM         dbo._VDosingCalc_step1
GROUP BY DosingLocation, MedicamentType, CONVERT(nvarchar(10), Timestampe, 120), (CASE WHEN DATENAME(hh, Timestampe) >= 0 AND DATENAME(hh, Timestampe) 
                      < 8 THEN '8' WHEN DATENAME(hh, Timestampe) >= 8 AND DATENAME(hh, Timestampe) < 16 THEN '16' WHEN DATENAME(hh, Timestampe) >= 16 AND 
                      DATENAME(hh, Timestampe) < 24 THEN '24' END)
go

