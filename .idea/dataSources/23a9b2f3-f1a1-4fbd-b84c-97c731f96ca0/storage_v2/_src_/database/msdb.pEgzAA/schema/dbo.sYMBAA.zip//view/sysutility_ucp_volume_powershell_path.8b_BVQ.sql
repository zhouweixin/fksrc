CREATE VIEW dbo.sysutility_ucp_volume_powershell_path AS
(    
    SELECT vo.physical_server_name
        , vo.volume_name
        , vo.volume_device_id
        , N'SQLSERVER:\Utility\'+CASE WHEN 0 = CHARINDEX(N'\', CONVERT(SYSNAME, SERVERPROPERTY(N'ServerName')), 1) THEN CONVERT(SYSNAME, SERVERPROPERTY(N'ServerName')) + N'\DEFAULT' ELSE CONVERT(SYSNAME, SERVERPROPERTY(N'ServerName')) END 
         +N'\Computers\'+msdb.dbo.fn_encode_sqlname_for_powershell(vo.physical_server_name) 
         +N'\Volumes\'+msdb.dbo.fn_encode_sqlname_for_powershell(vo.volume_name) AS powershell_path
    FROM msdb.dbo.sysutility_ucp_volumes vo 
)
go

