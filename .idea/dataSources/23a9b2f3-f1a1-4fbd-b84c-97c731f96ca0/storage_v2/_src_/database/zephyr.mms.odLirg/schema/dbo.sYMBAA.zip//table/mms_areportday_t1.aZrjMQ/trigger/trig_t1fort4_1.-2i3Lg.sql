CREATE trigger [dbo].[Trig_T1ForT4_1] on [dbo].[mms_aReportDay_T1]
for insert
as
declare @L_date date =null
declare @C_CID nvarchar(50) =''
select @L_date =R_Date ,@C_CID=R_CID from inserted   
exec proc_aReportDay_P4 @L_date,1
exec proc_aReportDay_WhereFromAcc_Logic @L_date
exec proc_aReportYKBalance @L_date 
--------
exec proc_insertDaySumValue @L_date,@C_CID,1,2

exec proc_insertDaySumCombineValue @L_date,@C_CID,1,2
go

