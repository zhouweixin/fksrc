create trigger [dbo].[Trig_SheetSn2ForT2_1] on [dbo].[mms_afmLaboratorySheetSn2]
for insert
as
declare @L_date date =null
select @L_date =ls_Date  from inserted    
exec proc_aReportDay2_P2 @L_date,1
go

