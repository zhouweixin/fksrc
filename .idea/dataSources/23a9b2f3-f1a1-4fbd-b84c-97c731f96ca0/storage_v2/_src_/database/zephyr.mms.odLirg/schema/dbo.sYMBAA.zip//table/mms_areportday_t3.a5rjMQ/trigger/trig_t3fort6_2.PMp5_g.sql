CREATE trigger [dbo].[Trig_T3ForT6_2] on [dbo].[mms_aReportDay_T3]
for update
as
declare @L_date date =null
select @L_date =R_Date  from inserted    
exec proc_aReportDay_P6 @L_date,2
exec proc_aReportDay_WhereFromAcc_Logic @L_date
go

