create procedure [dbo].[proc_aReportDay2_AccStatus]
@A_Date date =null,
@M_Mode int =null, --1插入，2更新，3删除
@Master int =null --1sheet t1调用，2 Sn T5调用 ,3 Run T6调用
as


declare @temp_status int =0
set @temp_status =(select COUNT(*) from status_aReportDay2 where R_date =@A_Date )
if(@M_Mode  =1)
	begin
		if(@Master =1)
			begin				
				if( @temp_status =0)
					insert into status_aReportDay2 values(@A_Date ,1,0,0)
				else
					update status_aReportDay2 
						set T4 = T4+1
					where R_date=@A_Date
			end
		if(@Master  =2)
			begin				
				if( @temp_status =0)
					insert into status_aReportDay2 values(@A_Date ,0,1,0)
				else
					update status_aReportDay2 
						set T5 = T5+1
					where R_date=@A_Date					
			end
		if(@Master  =3)
			begin				
				if( @temp_status =0)
					insert into status_aReportDay2 values(@A_Date ,0,0,1)
				else
					update status_aReportDay2 
						set T6 = T6+1
					where R_date=@A_Date	
			end											
	end


if(@M_Mode  =2)
	begin
		if(@Master =1)
			update status_aReportDay2  set T4 = T4+1 where R_date=@A_Date
		if(@Master  =2)
			update status_aReportDay2 set T5 = T5+1 where R_date=@A_Date
		if(@Master  =3)
			update status_aReportDay2 set T6 = T6+1 where R_date=@A_Date				
	end	

if (@M_Mode =3)
	begin
		if(@Master =1)
			update status_aReportDay2  set T4 = 0 where R_date=@A_Date
		if(@Master  =2)
			update status_aReportDay2 set T5 = 0 where R_date=@A_Date
		if(@Master  =3)
			update status_aReportDay2 set T6 = 0 where R_date=@A_Date	
	end


go

