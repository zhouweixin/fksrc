CREATE procedure [dbo].[proc_aReportDay_P4]
@D_Date date =null,
@M_Mode int =0 -----------操作模式，1插入、2更新、3删除
as
-----条件判断变量----------
declare @tempRun int =null
-----日合计变量声明------------
declare @yk_1 DECIMAL(18,4) =0
declare @yk_2 DECIMAL(18,4) =0
declare @yk_3 DECIMAL(18,4) =0
declare @yk_4 DECIMAL(18,4) =0
declare @yk_5 DECIMAL(18,4) =0
declare @yk_6 DECIMAL(18,4) =0
declare @yk_7 DECIMAL(18,4) =0
declare @yk_8 DECIMAL(18,4) =0
declare @yk_9 DECIMAL(18,4) =0
declare @pbsb_1 DECIMAL(18,4) =0
declare @pbsb_2 DECIMAL(18,4) =0
declare @pbsb_3 DECIMAL(18,4) =0
declare @pbsb_4 DECIMAL(18,4) =0
declare @pbsb_5 DECIMAL(18,4) =0
declare @pbsb_6 DECIMAL(18,4) =0
declare @pbsb_7 DECIMAL(18,4) =0
declare @zn_1 DECIMAL(18,4) =0
declare @zn_2 DECIMAL(18,4) =0
declare @zn_3 DECIMAL(18,4) =0
declare @zn_4 DECIMAL(18,4) =0

select @yk_1 =SUM(YK_1), @yk_3 =SUM(YK_3),@yk_5 =SUM(YK_5),@yk_7 =SUM(YK_7),@yk_9 =SUM(YK_9),
@pbsb_1 =SUM(PbSb_1),@pbsb_3 =SUM(PbSb_3),@pbsb_6 =SUM(PbSb_6),
@zn_1 =SUM(Zn_1),@zn_3 =SUM(Zn_3)
 from mms_aReportDay_T1 where R_Date =@D_Date 
 if(@yk_1>0)
	begin
		 set @yk_2=100*@yk_3/@yk_1
		 set @yk_4=100*@yk_5/@yk_1
		 set @yk_6=100*@yk_7/@yk_1
		 set @yk_8=100*@yk_9/@yk_1
	end
 if(@yk_1=0)
	begin
		 set @yk_2=0
		 set @yk_4=0
		 set @yk_6=0
		 set @yk_8=0
	end
 if(@pbsb_1=0)
	set	@pbsb_2=0
 else
	set @pbsb_2 =100*@pbsb_3/@pbsb_1
 if(@yk_3=0)
	set @pbsb_4=0
 else 
	set @pbsb_4 =100*@pbsb_3/@yk_3
 if(@pbsb_1=0)
	set @pbsb_5=0
 else
	set @pbsb_5 =100*@pbsb_6/@pbsb_1

 if(@yk_7=0)
	set @pbsb_7=0
 else
	set @pbsb_7 =100*@pbsb_6/@yk_7
 
 if(@zn_1=0)
	set @zn_2=0
 else
    set @zn_2 =100*@zn_3/@zn_1
 if(@yk_5=0)
	set @zn_4=0
 else 
	set @zn_4 =100*@zn_3/@yk_5
 
 declare @temp_t4 int =0
 set @temp_t4=(select COUNT(*) from mms_aReportDay_T4 where R_Date =@D_Date )
 ----------------------处理插入模式-----------------------------------------
if(@M_Mode =1)
	begin
		if(@temp_t4 =0)
			begin
 				insert into mms_aReportDay_T4 values(@D_Date ,@yk_1,@yk_2,@yk_3,@yk_4,@yk_5,@yk_6,@yk_7,@yk_8,@yk_9,
						@pbsb_1,@pbsb_2,@pbsb_3,@pbsb_4,@pbsb_5,@pbsb_6,@pbsb_7,
						@zn_1 ,@zn_2 ,@zn_3 ,@zn_4 )
				
				insert into mms_aReportDay_T7 values(@D_Date,1,4,@yk_1),
											(@D_Date,2,4,@yk_2),
											(@D_Date,3,4,@yk_3),
											(@D_Date,4,4,@yk_4),
											(@D_Date,5,4,@yk_5),
											(@D_Date,6,4,@yk_6),
											(@D_Date,7,4,@yk_7),
											(@D_Date,8,4,@yk_8),
											(@D_Date,9,4,@yk_9),
											(@D_Date,10,4,@pbsb_1),
											(@D_Date,11,4,@pbsb_2),
											(@D_Date,12,4,@pbsb_3),
											(@D_Date,13,4,@pbsb_4),
											(@D_Date,14,4,@pbsb_5),
											(@D_Date,15,4,@pbsb_6),
											(@D_Date,16,4,@pbsb_7),
											(@D_Date,17,4,@zn_1),
											(@D_Date,18,4,@zn_2),
											(@D_Date,19,4,@zn_3),
											(@D_Date,20,4,@zn_4)
			end
		else
			begin
				update mms_aReportDay_T4 
					set YK_1 =@yk_1,
						YK_2 =@yk_2,
						YK_3 =@yk_3,
						YK_4 =@yk_4,
						YK_5 =@yk_5,
						YK_6 =@yk_6,
						YK_7 =@yk_7,
						YK_8 =@yk_8,
						YK_9 =@yk_9,
						PbSb_1 =@pbsb_1,
						PbSb_2 =@pbsb_2,
						PbSb_3 =@pbsb_3,
						PbSb_4 =@pbsb_4,
						PbSb_5 =@pbsb_5,
						PbSb_6 =@pbsb_6,
						PbSb_7 =@pbsb_7,
						Zn_1 =@zn_1,
						Zn_2 =@zn_2,
						Zn_3 =@zn_3,
						Zn_4 =@zn_4
				where R_Date =@D_Date 
			----------------------------更新T7-------------------------
				update mms_aReportDay_T7 
					set ReportValue =@yk_1 
				where ReportDate =@D_Date and R_Rows =1 and R_Cols =4
				update mms_aReportDay_T7 
					set ReportValue =@yk_2 
				where ReportDate =@D_Date and R_Rows =2 and R_Cols =4
				update mms_aReportDay_T7 
					set ReportValue =@yk_3 
				where ReportDate =@D_Date and R_Rows =3 and R_Cols =4
				update mms_aReportDay_T7 
					set ReportValue =@yk_4 
				where ReportDate =@D_Date and R_Rows =4 and R_Cols =4
				update mms_aReportDay_T7 
					set ReportValue =@yk_5 
				where ReportDate =@D_Date and R_Rows =5 and R_Cols =4
				update mms_aReportDay_T7 
					set ReportValue =@yk_6 
				where ReportDate =@D_Date and R_Rows =6 and R_Cols =4
				update mms_aReportDay_T7 
					set ReportValue =@yk_7 
				where ReportDate =@D_Date and R_Rows =7 and R_Cols =4
				update mms_aReportDay_T7 
					set ReportValue =@yk_8 
				where ReportDate =@D_Date and R_Rows =8 and R_Cols =4
				update mms_aReportDay_T7 
					set ReportValue =@yk_9 
				where ReportDate =@D_Date and R_Rows =9 and R_Cols =4
				update mms_aReportDay_T7 
					set ReportValue =@pbsb_1 
				where ReportDate =@D_Date and R_Rows =10 and R_Cols =4
				update mms_aReportDay_T7 
					set ReportValue =@pbsb_2 
				where ReportDate =@D_Date and R_Rows =11 and R_Cols =4
				update mms_aReportDay_T7 
					set ReportValue =@pbsb_3 
				where ReportDate =@D_Date and R_Rows =12 and R_Cols =4
				update mms_aReportDay_T7 
					set ReportValue =@pbsb_4 
				where ReportDate =@D_Date and R_Rows =13 and R_Cols =4
				update mms_aReportDay_T7 
					set ReportValue =@pbsb_5 
				where ReportDate =@D_Date and R_Rows =14 and R_Cols =4
				update mms_aReportDay_T7 
					set ReportValue =@pbsb_6 
				where ReportDate =@D_Date and R_Rows =15 and R_Cols =4
				update mms_aReportDay_T7 
					set ReportValue =@pbsb_7 
				where ReportDate =@D_Date and R_Rows =16 and R_Cols =4
				update mms_aReportDay_T7 
					set ReportValue =@zn_1  
				where ReportDate =@D_Date and R_Rows =17 and R_Cols =4
				update mms_aReportDay_T7 
					set ReportValue =@zn_2 
				where ReportDate =@D_Date and R_Rows =18 and R_Cols =4
				update mms_aReportDay_T7 
					set ReportValue =@zn_3 
				where ReportDate =@D_Date and R_Rows =19 and R_Cols =4
				update mms_aReportDay_T7 
					set ReportValue =@zn_4 
				where ReportDate =@D_Date and R_Rows =20 and R_Cols =4					
			end
	end
	-------------------处理更新模式----------------------
if(@M_Mode =2)
	begin
	----------------------------更新T4-------------
		update mms_aReportDay_T4 
			set YK_1 =@yk_1,
				YK_2 =@yk_2,
				YK_3 =@yk_3,
				YK_4 =@yk_4,
				YK_5 =@yk_5,
				YK_6 =@yk_6,
				YK_7 =@yk_7,
				YK_8 =@yk_8,
				YK_9 =@yk_9,
				PbSb_1 =@pbsb_1,
				PbSb_2 =@pbsb_2,
				PbSb_3 =@pbsb_3,
				PbSb_4 =@pbsb_4,
				PbSb_5 =@pbsb_5,
				PbSb_6 =@pbsb_6,
				PbSb_7 =@pbsb_7,
				Zn_1 =@zn_1,
				Zn_2 =@zn_2,
				Zn_3 =@zn_3,
				Zn_4 =@zn_4
		where R_Date =@D_Date 
	----------------------------更新T7-------------------------
		update mms_aReportDay_T7 
			set ReportValue =@yk_1 
		where ReportDate =@D_Date and R_Rows =1 and R_Cols =4
		update mms_aReportDay_T7 
			set ReportValue =@yk_2 
		where ReportDate =@D_Date and R_Rows =2 and R_Cols =4
		update mms_aReportDay_T7 
			set ReportValue =@yk_3 
		where ReportDate =@D_Date and R_Rows =3 and R_Cols =4
		update mms_aReportDay_T7 
			set ReportValue =@yk_4 
		where ReportDate =@D_Date and R_Rows =4 and R_Cols =4
		update mms_aReportDay_T7 
			set ReportValue =@yk_5 
		where ReportDate =@D_Date and R_Rows =5 and R_Cols =4
		update mms_aReportDay_T7 
			set ReportValue =@yk_6 
		where ReportDate =@D_Date and R_Rows =6 and R_Cols =4
		update mms_aReportDay_T7 
			set ReportValue =@yk_7 
		where ReportDate =@D_Date and R_Rows =7 and R_Cols =4
		update mms_aReportDay_T7 
			set ReportValue =@yk_8 
		where ReportDate =@D_Date and R_Rows =8 and R_Cols =4
		update mms_aReportDay_T7 
			set ReportValue =@yk_9 
		where ReportDate =@D_Date and R_Rows =9 and R_Cols =4
		update mms_aReportDay_T7 
			set ReportValue =@pbsb_1 
		where ReportDate =@D_Date and R_Rows =10 and R_Cols =4
		update mms_aReportDay_T7 
			set ReportValue =@pbsb_2 
		where ReportDate =@D_Date and R_Rows =11 and R_Cols =4
		update mms_aReportDay_T7 
			set ReportValue =@pbsb_3 
		where ReportDate =@D_Date and R_Rows =12 and R_Cols =4
		update mms_aReportDay_T7 
			set ReportValue =@pbsb_4 
		where ReportDate =@D_Date and R_Rows =13 and R_Cols =4
		update mms_aReportDay_T7 
			set ReportValue =@pbsb_5 
		where ReportDate =@D_Date and R_Rows =14 and R_Cols =4
		update mms_aReportDay_T7 
			set ReportValue =@pbsb_6 
		where ReportDate =@D_Date and R_Rows =15 and R_Cols =4
		update mms_aReportDay_T7 
			set ReportValue =@pbsb_7 
		where ReportDate =@D_Date and R_Rows =16 and R_Cols =4
		update mms_aReportDay_T7 
			set ReportValue =@zn_1  
		where ReportDate =@D_Date and R_Rows =17 and R_Cols =4
		update mms_aReportDay_T7 
			set ReportValue =@zn_2 
		where ReportDate =@D_Date and R_Rows =18 and R_Cols =4
		update mms_aReportDay_T7 
			set ReportValue =@zn_3 
		where ReportDate =@D_Date and R_Rows =19 and R_Cols =4
		update mms_aReportDay_T7 
			set ReportValue =@zn_4 
		where ReportDate =@D_Date and R_Rows =20 and R_Cols =4		
	end
-------------------------处理删除模式---------------------
if(@M_Mode =3)
	begin
		delete from mms_aReportDay_T4 where @D_Date =@D_Date 
		delete from mms_aReportDay_T7 where R_Cols =4 and ReportDate =@D_Date and (R_Rows between 1 and 20)
	end
go

