CREATE VIEW dbo._VDosingCalc_ClassByMonth
AS
SELECT     e.MedicamentType, e.moring, e.middle, f.accvalue AS night, e.cmonth
FROM         (SELECT     c.MedicamentType, c.accvalue AS moring, d.accvalue AS middle, d.cmonth
                       FROM          (SELECT     MedicamentType, accvalue, cmonth
                                               FROM          (SELECT     MedicamentType, SUM(value) AS accvalue, dbo.fn_getYearMonth(cs2date) AS cmonth, hh
                                                                       FROM          (SELECT     DosingLocation, MedicamentType, value, maxValue, minValue, cs2date, hh
                                                                                               FROM          dbo._VDosingCalc_Step2) AS a
                                                                       GROUP BY MedicamentType, dbo.fn_getYearMonth(cs2date), hh) AS b
                                               WHERE      (hh = 8)) AS c INNER JOIN
                                                  (SELECT     MedicamentType, accvalue, cmonth
                                                    FROM          (SELECT     MedicamentType, SUM(value) AS accvalue, dbo.fn_getYearMonth(cs2date) AS cmonth, hh
                                                                            FROM          (SELECT     DosingLocation, MedicamentType, value, maxValue, minValue, cs2date, hh
                                                                                                    FROM          dbo._VDosingCalc_Step2 AS _VDosingCalc_Step2_2) AS a_2
                                                                            GROUP BY MedicamentType, dbo.fn_getYearMonth(cs2date), hh) AS c_1
                                                    WHERE      (hh = 16)) AS d ON d.MedicamentType = c.MedicamentType AND d.cmonth = c.cmonth) AS e INNER JOIN
                          (SELECT     MedicamentType, accvalue, cmonth
                            FROM          (SELECT     MedicamentType, SUM(value) AS accvalue, dbo.fn_getYearMonth(cs2date) AS cmonth, hh
                                                    FROM          (SELECT     DosingLocation, MedicamentType, value, maxValue, minValue, cs2date, hh
                                                                            FROM          dbo._VDosingCalc_Step2 AS _VDosingCalc_Step2_1) AS a_1
                                                    GROUP BY MedicamentType, dbo.fn_getYearMonth(cs2date), hh) AS b_1
                            WHERE      (hh = 24)) AS f ON e.MedicamentType = f.MedicamentType AND e.cmonth = f.cmonth
go

