CREATE trigger [dbo].[Trig_T6ForT6Acc_Delete] on [dbo].[mms_aReportDay_T6]
for delete
as
declare @L_date date =null
select @L_date =R_Date      from deleted    
exec proc_aReportDay_AccStatus @L_date,3,3
exec proc_aReportRunMonth_Logic @L_date
go

