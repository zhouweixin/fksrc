CREATE trigger [dbo].[Trig_T4ForT4Acc_update] on [dbo].[mms_aReportDay_T4]
for update
as
declare @L_date date =null
select @L_date =R_Date  from inserted   
exec proc_aReportDay_AccStatus @L_date,2,1
exec proc_aReportMonth_Logic @L_date
exec proc_aReportYk_Logic @L_date
go

