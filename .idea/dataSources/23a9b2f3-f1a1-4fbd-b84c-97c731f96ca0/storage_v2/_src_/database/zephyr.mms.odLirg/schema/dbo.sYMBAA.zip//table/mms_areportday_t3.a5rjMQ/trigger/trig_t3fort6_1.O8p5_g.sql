CREATE trigger [dbo].[Trig_T3ForT6_1] on [dbo].[mms_aReportDay_T3]
for insert
as
declare @L_date date =null
select @L_date =R_Date  from inserted    
exec proc_aReportDay_P6 @L_date,1
exec proc_aReportDay_WhereFromAcc_Logic @L_date
go

