create trigger [dbo].[Trig_T52ForT52Acc_update] on [dbo].[mms_aReportDay2_T5]
for update
as
declare @L_date date =null
select @L_date =R_Date  from inserted   
exec proc_aReportDay2_AccStatus @L_date,2,2
go

