

CREATE function [dbo].[GetChild](@type varchar(100),@value varchar(1024))
returns @Tree table (ID varchar(1024))
As
begin  
	if @type = 'Sys_Organize'
	begin
		insert into @Tree select OrganizeCode from Sys_Organize where OrganizeCode=@value  
		while @@rowcount<>0  
		insert into @Tree select a.OrganizeCode from Sys_Organize a   
		inner join @Tree b on a.ParentCode=b.ID and not exists(select 1 from @Tree where ID=a.OrganizeCode)  
	end
	return  
end
go

