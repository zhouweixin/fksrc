CREATE VIEW dbo._VReportSell
AS
SELECT     TOP (100) PERCENT tt1.C_Name AS Product, tt2.C_Name AS Quota, tt3.C_Name AS Unit, r1.ReportValue AS Q1, r2.ReportValue AS Q2, r3.ReportValue AS Q3, r4.ReportValue AS Q4, 
                      r1.ReportDate AS MonthDate, r1.R_Rows AS OrderCode
FROM         (SELECT     R_Rows, ReportValue, ReportDate
                       FROM          dbo.mms_aReportSell_T7
                       WHERE      (R_Cols = 1)) AS r1 INNER JOIN
                          (SELECT     R_Rows, C_Name
                            FROM          dbo.mms_aReportSell_TT
                            WHERE      (R_Cols = 1)) AS tt1 ON r1.R_Rows = tt1.R_Rows INNER JOIN
                          (SELECT     R_Rows, C_Name
                            FROM          dbo.mms_aReportSell_TT AS mms_aReportSell_TT_2
                            WHERE      (R_Cols = 2)) AS tt2 ON r1.R_Rows = tt2.R_Rows INNER JOIN
                          (SELECT     R_Rows, C_Name
                            FROM          dbo.mms_aReportSell_TT AS mms_aReportSell_TT_1
                            WHERE      (R_Cols = 3)) AS tt3 ON r1.R_Rows = tt3.R_Rows INNER JOIN
                          (SELECT     R_Rows, ReportValue, ReportDate
                            FROM          dbo.mms_aReportSell_T7 AS mms_aReportSell_T7_4
                            WHERE      (R_Cols = 2)) AS r2 ON r1.R_Rows = r2.R_Rows AND r1.ReportDate = r2.ReportDate INNER JOIN
                          (SELECT     R_Rows, ReportValue, ReportDate
                            FROM          dbo.mms_aReportSell_T7 AS mms_aReportSell_T7_3
                            WHERE      (R_Cols = 3)) AS r3 ON r1.R_Rows = r3.R_Rows AND r1.ReportDate = r3.ReportDate INNER JOIN
                          (SELECT     R_Rows, ReportValue, ReportDate
                            FROM          dbo.mms_aReportSell_T7 AS mms_aReportSell_T7_2
                            WHERE      (R_Cols = 4)) AS r4 ON r1.R_Rows = r4.R_Rows AND r1.ReportDate = r4.ReportDate
ORDER BY OrderCode
go

