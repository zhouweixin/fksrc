create procedure [dbo].[proc_updateAllData]
as

declare @aa decimal(18,2)=0
declare @tempDate nvarchar(50)=''
declare @str nvarchar(50)=''
begin---run---
	DECLARE TableCursor CURSOR 
	LOCAL
	FOR					
	select ID   
		from mms_afmPlantRun 
	OPEN TableCursor
	FETCH NEXT FROM TableCursor INTO @tempDate
	while @@FETCH_STATUS =0
		begin				
			select @aa =waitElseTime  
			from mms_afmPlantRun 
			where ID=@tempDate
			set @aa=@aa+1				
			update mms_afmPlantRun set waitElseTime=@aa
			where ID=@tempDate	
			set @aa=@aa-1				
			update mms_afmPlantRun set waitElseTime=@aa
			where ID=@tempDate					
			FETCH NEXT FROM TableCursor INTO @tempDate
		end
	CLOSE TableCursor
	DEALLOCATE TableCursor		
end---run-------
begin--------run2---------------
	DECLARE TableCursor CURSOR 
	LOCAL
	FOR					
	select ID   
		from mms_afmPlantRun2 
	OPEN TableCursor
	FETCH NEXT FROM TableCursor INTO @tempDate
	while @@FETCH_STATUS =0
		begin				
			select @aa =waitElseTime  
			from mms_afmPlantRun2 
			where ID=@tempDate
			set @aa=@aa+1				
			update mms_afmPlantRun2 set waitElseTime=@aa
			where ID=@tempDate	
			set @aa=@aa-1				
			update mms_afmPlantRun2 set waitElseTime=@aa
			where ID=@tempDate					
			FETCH NEXT FROM TableCursor INTO @tempDate
		end
	CLOSE TableCursor
	DEALLOCATE TableCursor
end-------run2-----------------------------------------		
begin-------SheetA----------------------------------------
	DECLARE TableCursor CURSOR 
	LOCAL
	FOR					
	select ID   
		from mms_afmLaboratorySheetA 
	OPEN TableCursor
	FETCH NEXT FROM TableCursor INTO @tempDate
	while @@FETCH_STATUS =0
		begin				
			select @str =laboratorian  
			from mms_afmLaboratorySheetA 
			where ID=@tempDate
			
			set @str=@str+'###'				
			update mms_afmLaboratorySheetA set laboratorian=@str
			where ID=@tempDate
				
			set @str=REPLACE(@str,'###','')				
			update mms_afmLaboratorySheetA set laboratorian=@str
			where ID=@tempDate					
			FETCH NEXT FROM TableCursor INTO @tempDate
		end
	CLOSE TableCursor
	DEALLOCATE TableCursor
end--------SheetA------		
begin-------SheetA2----------------------------------------
	DECLARE TableCursor CURSOR 
	LOCAL
	FOR					
	select ID   
		from mms_afmLaboratorySheetA2 
	OPEN TableCursor
	FETCH NEXT FROM TableCursor INTO @tempDate
	while @@FETCH_STATUS =0
		begin				
			select @str =laboratorian  
			from mms_afmLaboratorySheetA2 
			where ID=@tempDate
			
			set @str=@str+'###'				
			update mms_afmLaboratorySheetA2 set laboratorian=@str
			where ID=@tempDate
				
			set @str=REPLACE(@str,'###','')				
			update mms_afmLaboratorySheetA2 set laboratorian=@str
			where ID=@tempDate					
			FETCH NEXT FROM TableCursor INTO @tempDate
		end
	CLOSE TableCursor
	DEALLOCATE TableCursor
end--------SheetA2------		
begin-------SheetB----------------------------------------
	DECLARE TableCursor CURSOR 
	LOCAL
	FOR					
	select ID   
		from mms_afmLaboratorySheetB 
	OPEN TableCursor
	FETCH NEXT FROM TableCursor INTO @tempDate
	while @@FETCH_STATUS =0
		begin				
			select @str =laboratorian  
			from mms_afmLaboratorySheetB 
			where ID=@tempDate
			
			set @str=@str+'###'				
			update mms_afmLaboratorySheetB set laboratorian=@str
			where ID=@tempDate
				
			set @str=REPLACE(@str,'###','')				
			update mms_afmLaboratorySheetB set laboratorian=@str
			where ID=@tempDate					
			FETCH NEXT FROM TableCursor INTO @tempDate
		end
	CLOSE TableCursor
	DEALLOCATE TableCursor
end--------SheetB------	
begin-------SheetB2----------------------------------------
	DECLARE TableCursor CURSOR 
	LOCAL
	FOR					
	select ID   
		from mms_afmLaboratorySheetB2 
	OPEN TableCursor
	FETCH NEXT FROM TableCursor INTO @tempDate
	while @@FETCH_STATUS =0
		begin				
			select @str =laboratorian  
			from mms_afmLaboratorySheetB2 
			where ID=@tempDate
			
			set @str=@str+'###'				
			update mms_afmLaboratorySheetB2 set laboratorian=@str
			where ID=@tempDate
				
			set @str=REPLACE(@str,'###','')				
			update mms_afmLaboratorySheetB2 set laboratorian=@str
			where ID=@tempDate					
			FETCH NEXT FROM TableCursor INTO @tempDate
		end
	CLOSE TableCursor
	DEALLOCATE TableCursor
end--------SheetB------	
begin-------SheetSn----------------------------------------
	DECLARE TableCursor CURSOR 
	LOCAL
	FOR					
	select ID   
		from mms_afmLaboratorySheetSn 
	OPEN TableCursor
	FETCH NEXT FROM TableCursor INTO @tempDate
	while @@FETCH_STATUS =0
		begin				
			select @str =laboratorian  
			from mms_afmLaboratorySheetSn 
			where ID=@tempDate
			
			set @str=@str+'###'				
			update mms_afmLaboratorySheetSn set laboratorian=@str
			where ID=@tempDate
				
			set @str=REPLACE(@str,'###','')				
			update mms_afmLaboratorySheetSn set laboratorian=@str
			where ID=@tempDate					
			FETCH NEXT FROM TableCursor INTO @tempDate
		end
	CLOSE TableCursor
	DEALLOCATE TableCursor
end--------SheetSn------	
begin-------WeightSn----------------------------------------
	DECLARE TableCursor CURSOR 
	LOCAL
	FOR					
	select ID   
		from mms_afmWeightSn 
	OPEN TableCursor
	FETCH NEXT FROM TableCursor INTO @tempDate
	while @@FETCH_STATUS =0
		begin				
			select @str =statistician  
			from mms_afmWeightSn 
			where ID=@tempDate
			
			set @str=@str+'###'				
			update mms_afmWeightSn set statistician=@str
			where ID=@tempDate
				
			set @str=REPLACE(@str,'###','')				
			update mms_afmWeightSn set statistician=@str
			where ID=@tempDate					
			FETCH NEXT FROM TableCursor INTO @tempDate
		end
	CLOSE TableCursor
	DEALLOCATE TableCursor
end--------SheetSn------
go

