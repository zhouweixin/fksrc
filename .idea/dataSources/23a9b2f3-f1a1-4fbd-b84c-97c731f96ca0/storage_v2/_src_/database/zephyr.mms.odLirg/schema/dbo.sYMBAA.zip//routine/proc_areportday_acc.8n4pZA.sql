CREATE procedure [dbo].[proc_aReportDay_Acc]
@A_Date date =null
as
declare @t4 int =0
declare @t5 int =0 
declare @t6 int =0
declare @st int =0
select @t4 =T4,@t5=T5,@t6=T6,@st =st from status_aReportDay where R_date =@A_Date 

if(dbo.fn_getMin(@t4 ,@t5 ,@t6) >=1)
	begin
	-------------读取T4表，和计算-------------------------------------
		declare @yk1 decimal(18,4) =0
		declare @yk2 decimal(18,4) =0
		declare @yk3 decimal(18,4) =0
		declare @yk4 decimal(18,4) =0
		declare @yk5 decimal(18,4) =0
		declare @yk6 decimal(18,4) =0
		declare @yk7 decimal(18,4) =0
		declare @yk8 decimal(18,4) =0
		declare @yk9 decimal(18,4) =0
		declare @pbsb1 decimal(18,4) =0
		declare @pbsb2 decimal(18,4) =0
		declare @pbsb3 decimal(18,4) =0
		declare @pbsb4 decimal(18,4) =0
		declare @pbsb5 decimal(18,4) =0
		declare @pbsb6 decimal(18,4) =0
		declare @pbsb7 decimal(18,4) =0
		declare @zn1 decimal(18,4) =0
		declare @zn2 decimal(18,4) =0
		declare @zn3 decimal(18,4) =0
		declare @zn4 decimal(18,4) =0

		select @yk1=SUM(YK_1),@yk3=SUM(YK_3),@yk5=SUM(YK_5),@yk7=SUM(YK_7),@yk9=SUM(YK_9),
		@pbsb1=SUM(PbSb_1),@pbsb3=SUM(PbSb_3),@pbsb6=SUM(PbSb_6),
		@zn1=SUM(Zn_1),@zn3=SUM(Zn_3)
		  from mms_aReportDay_T4 where R_Date <=@A_Date and MONTH(R_Date)=MONTH(@A_Date)
		set @yk2=100*@yk3/nullif(@yk1,0)
		set @yk4=100*@yk5/nullif(@yk1,0)
		set @yk6=100*@yk7/nullif(@yk1,0)
		set @yk8=100*@yk9/nullif(@yk1,0)
		
		set @pbsb2=100*@pbsb3/nullif(@pbsb1,0)
		set @pbsb5=100*@pbsb6/nullif(@pbsb1,0)
		set @pbsb4=100*@pbsb3/nullif(@yk3,0)
		set @pbsb7=100*@pbsb6/nullif(@yk7,0)
		if(@zn1=0)
			set @zn2=0
		else
			set @zn2=100*@zn3/@zn1
		if(@yk5=0)
			set @zn4 =0
		else 
			set @zn4 =100*@zn3 /@yk5
		-------------读取T5表，和计算------------------------------------- 
		declare @sn_xn1 decimal(18,4) =0
		declare @sn_xn2 decimal(18,4) =0
		declare @sn_xn3 decimal(18,4) =0
		declare @sn_xn4 decimal(18,4) =0
		declare @sn_zx1 decimal(18,4) =0
		declare @sn_zx2 decimal(18,4) =0
		declare @sn_zx3 decimal(18,4) =0
		declare @sn_zx4 decimal(18,4) =0
		declare @yk_sn decimal(18,4) =0
		select @sn_xn1 =SUM(Sn_XN_1),@sn_xn3 =SUM(Sn_XN_3),@sn_zx1 =SUM(Sn_ZX_1),@sn_zx3 =SUM(Sn_ZX_3)
			 from mms_aReportDay_T5 where R_Date <=@A_Date	and MONTH(R_Date)=MONTH(@A_Date)			
		if(@sn_xn1=0)
			set @sn_xn2 =0
		else
			set @sn_xn2 =100*@sn_xn3/@sn_xn1
			
		if(@sn_zx1=0)
			set @sn_zx2=0
		else
			set @sn_zx2 =100*@sn_zx3/@sn_zx1
			
		if(@yk9 =0)
			begin
				set @sn_xn4=0
				set @sn_zx4=0
			end
		else
			begin
				set @sn_xn4 =100*@sn_xn3/@yk9	
				set @sn_zx4 =100*@sn_zx3/@yk9
			end
		-------------读取T6表，和计算------------------------------------- 	
		declare @run1 decimal(18,4) =0
		declare @run2 decimal(18,4) =0
		declare @run3 decimal(18,4) =0
		declare @run4 decimal(18,4) =0
		declare @run5 decimal(18,4) =0
		declare @run6 decimal(18,4) =0
		declare @run7 decimal(18,4) =0
		declare @run8 decimal(18,4) =0
		declare @run9 decimal(18,4) =0
		select @run1=sum(Run_1 ),@run2=sum(Run_2 ),@run3=sum(Run_3 ),@run4=sum(Run_4 ),
					@run5=sum(Run_5 ),@run6=sum(Run_6 ),@run7=sum(Run_7 )
		 from mms_aReportDay_T6 where R_Date <=@A_Date and MONTH(R_Date)=MONTH(@A_Date)
		 if(@run1=0)
			set @run8=0
		 else 
			set @run8= 100*@run2/@run1
			
		if(@run2=0)
			set @run9=0
		else
			set @run9= 24*@yk1/@run2
		-----------------------------------------------------------------------
		-----------------------------------------------------------------------		
		declare @temp_t4count int =0
		set @temp_t4count =(select COUNT(*) from mms_aReportDay_T4_Acc where R_Date =@A_Date )
		if(dbo.fn_getMin(@t4 ,@t5 ,@t6) =1 and @temp_t4count =0)
			begin	
		------------------------------T4_Acc、T7插入新值-----------------------------------------			
				insert into mms_aReportDay_T4_Acc values(@A_Date ,@yk1 ,@yk2 ,@yk3 ,@yk4 ,@yk5 ,@yk6 ,@yk7 ,@yk8 ,@yk9 ,
							@pbsb1 ,@pbsb2 ,@pbsb3 ,@pbsb4 ,@pbsb5 ,@pbsb6 ,@pbsb7 ,
							@zn1 ,@zn2 ,@zn3 ,@zn4)
				insert into mms_aReportDay_T7 
					values(@A_Date,1,5,@yk1),
					(@A_Date,2,5,@yk2),
					(@A_Date,3,5,@yk3),
					(@A_Date,4,5,@yk4),
					(@A_Date,5,5,@yk5),
					(@A_Date,6,5,@yk6),
					(@A_Date,7,5,@yk7),
					(@A_Date,8,5,@yk8),
					(@A_Date,9,5,@yk9),
					(@A_Date,10,5,@pbsb1),
					(@A_Date,11,5,@pbsb2),
					(@A_Date,12,5,@pbsb3),
					(@A_Date,13,5,@pbsb4),
					(@A_Date,14,5,@pbsb5),
					(@A_Date,15,5,@pbsb6),
					(@A_Date,16,5,@pbsb7),
					(@A_Date,17,5,@zn1),
					(@A_Date,18,5,@zn2),
					(@A_Date,19,5,@zn3),
					(@A_Date,20,5,@zn4)	
		------------------------------T5_Acc、T7插入新值-----------------------------------------					
				insert into mms_aReportDay_T5_Acc values(@A_Date ,@sn_xn1 ,@sn_xn2 ,@sn_xn3 ,@sn_xn4 ,
					@sn_zx1 ,@sn_zx2 ,@sn_zx3 ,@sn_zx4)
				insert into mms_aReportDay_T7 
					values(@A_Date,21,5,@sn_xn1),
						(@A_Date,22,5,@sn_xn2),
						(@A_Date,23,5,@sn_xn3),
						(@A_Date,24,5,@sn_xn4),
						(@A_Date,25,5,@sn_zx1),
						(@A_Date,26,5,@sn_zx2),
						(@A_Date,27,5,@sn_zx3),
						(@A_Date,28,5,@sn_zx4)	
		------------------------------T6_Acc、T7插入新值-----------------------------------------														
				insert into mms_aReportDay_T6_Acc values(@A_Date,@run1,@run2,@run3,@run4,@run5,@run6,
							@run7,@run8,@run9)
				insert into mms_aReportDay_T7
					values(@A_Date ,29,5,@run1),
					(@A_Date ,30,5,@run2),
					(@A_Date ,31,5,@run3),
					(@A_Date ,32,5,@run4),
					(@A_Date ,33,5,@run5),
					(@A_Date ,34,5,@run6),
					(@A_Date ,35,5,@run7),
					(@A_Date ,36,5,@run8),
					(@A_Date ,37,5,@run9)
		------------------------------对该日期以后的影响-----------------------------------------														
				exec proc_aReportDay_AccAfectLogic @A_Date	
			end		
		if(@temp_t4count>0)
			begin
		------------------------------T4_Acc、T7更新----------------------------------------	
			update mms_aReportDay_T4_Acc
				  set YK_1 =@yk1 ,
					YK_2 =@yk2 ,
					YK_3 =@yk3 ,
					YK_4 =@yk4 ,
					YK_5 =@yk5 ,
					YK_6 =@yk6 ,
					YK_7 =@yk7 ,
					YK_8 =@yk8 ,
					YK_9 =@yk9 ,
					PbSb_1 =@pbsb1 ,
					PbSb_2 =@pbsb2 ,
					PbSb_3 =@pbsb3 ,
					PbSb_4 =@pbsb4 ,
					PbSb_5 =@pbsb5 ,
					PbSb_6 =@pbsb6 ,
					PbSb_7 =@pbsb7 ,
					Zn_1 =@zn1 ,
					Zn_2 =@zn2 ,
					Zn_3 =@zn3 ,
					Zn_4 =@zn4 
				where R_Date =@A_Date
				
				update mms_aReportDay_T7 
					set ReportValue =@yk1
				where ReportDate =@A_Date and R_Rows =1 and R_Cols =5
				update mms_aReportDay_T7 
					set ReportValue =@yk2
				where ReportDate =@A_Date and R_Rows =2 and R_Cols =5
				update mms_aReportDay_T7 
					set ReportValue =@yk3
				where ReportDate =@A_Date and R_Rows =3 and R_Cols =5
				update mms_aReportDay_T7 
					set ReportValue =@yk4
				where ReportDate =@A_Date and R_Rows =4 and R_Cols =5
				update mms_aReportDay_T7 
					set ReportValue =@yk5
				where ReportDate =@A_Date and R_Rows =5 and R_Cols =5
				update mms_aReportDay_T7 
					set ReportValue =@yk6
				where ReportDate =@A_Date and R_Rows =6 and R_Cols =5
				update mms_aReportDay_T7 
					set ReportValue =@yk7
				where ReportDate =@A_Date and R_Rows =7 and R_Cols =5
				update mms_aReportDay_T7 
					set ReportValue =@yk8
				where ReportDate =@A_Date and R_Rows =8 and R_Cols =5
				update mms_aReportDay_T7 
					set ReportValue =@yk9
				where ReportDate =@A_Date and R_Rows =9 and R_Cols =5
				update mms_aReportDay_T7 
					set ReportValue =@pbsb1 
				where ReportDate =@A_Date and R_Rows =10 and R_Cols =5
				update mms_aReportDay_T7 
					set ReportValue =@pbsb2
				where ReportDate =@A_Date and R_Rows =11 and R_Cols =5
				update mms_aReportDay_T7 
					set ReportValue =@pbsb3
				where ReportDate =@A_Date and R_Rows =12 and R_Cols =5
				update mms_aReportDay_T7 
					set ReportValue =@pbsb4
				where ReportDate =@A_Date and R_Rows =13 and R_Cols =5
				update mms_aReportDay_T7 
					set ReportValue =@pbsb5
				where ReportDate =@A_Date and R_Rows =14 and R_Cols =5
				update mms_aReportDay_T7 
					set ReportValue =@pbsb6
				where ReportDate =@A_Date and R_Rows =15 and R_Cols =5
				update mms_aReportDay_T7 
					set ReportValue =@pbsb7
				where ReportDate =@A_Date and R_Rows =16 and R_Cols =5
				update mms_aReportDay_T7 
					set ReportValue =@zn1 
				where ReportDate =@A_Date and R_Rows =17 and R_Cols =5
				update mms_aReportDay_T7 
					set ReportValue =@zn2 
				where ReportDate =@A_Date and R_Rows =18 and R_Cols =5
				update mms_aReportDay_T7 
					set ReportValue =@zn3 
				where ReportDate =@A_Date and R_Rows =19 and R_Cols =5
				update mms_aReportDay_T7 
					set ReportValue =@zn4 
				where ReportDate =@A_Date and R_Rows =20 and R_Cols =5
	------------------------------T5_Acc、T7更新----------------------------------------
				update mms_aReportDay_T5_Acc 
					set Sn_XN_1=@sn_xn1,
					Sn_XN_2=@sn_xn2,
					Sn_XN_3=@sn_xn3,
					Sn_XN_4=@sn_xn4,
					Sn_ZX_1=@sn_zx1,
					Sn_ZX_2=@sn_zx2,
					Sn_ZX_3=@sn_zx3,
					Sn_ZX_4=@sn_zx4
				where R_Date =@A_Date 
				update mms_aReportDay_T7
					set ReportValue =@sn_xn1
				where ReportDate =@A_Date and R_Rows =21 and R_Cols =5
				update mms_aReportDay_T7
					set ReportValue =@sn_xn2
				where ReportDate =@A_Date and R_Rows =22 and R_Cols =5
				update mms_aReportDay_T7
					set ReportValue =@sn_xn3
				where ReportDate =@A_Date and R_Rows =23 and R_Cols =5
				update mms_aReportDay_T7
					set ReportValue =@sn_xn4
				where ReportDate =@A_Date and R_Rows =24 and R_Cols =5
				update mms_aReportDay_T7
					set ReportValue =@sn_zx1
				where ReportDate =@A_Date and R_Rows =25 and R_Cols =5
				update mms_aReportDay_T7
					set ReportValue =@sn_zx2
				where ReportDate =@A_Date and R_Rows =26 and R_Cols =5
				update mms_aReportDay_T7
					set ReportValue =@sn_zx3
				where ReportDate =@A_Date and R_Rows =27 and R_Cols =5
				update mms_aReportDay_T7
					set ReportValue =@sn_zx4
				where ReportDate =@A_Date and R_Rows =28 and R_Cols =5		
------------------------------T6_Acc、T7更新----------------------------------------	
				update mms_aReportDay_T6_Acc 
					set Run_1 =@run1,
					Run_2=@run2,
					Run_3=@run3,
					Run_4=@run4,
					Run_5=@run5,
					Run_6=@run6,
					Run_7=@run7,
					Run_8=@run8,
					Run_9=@run9
				where R_Date =@A_Date
				 
				update mms_aReportDay_T7
					set ReportValue =@run1
				where ReportDate =@A_Date and R_Rows =29 and R_Cols =5
				update mms_aReportDay_T7
					set ReportValue =@run2
				where ReportDate =@A_Date and R_Rows =30 and R_Cols =5	
				update mms_aReportDay_T7
					set ReportValue =@run3
				where ReportDate =@A_Date and R_Rows =31 and R_Cols =5	
				update mms_aReportDay_T7
					set ReportValue =@run4
				where ReportDate =@A_Date and R_Rows =32 and R_Cols =5	
				update mms_aReportDay_T7
					set ReportValue =@run5
				where ReportDate =@A_Date and R_Rows =33 and R_Cols =5	
				update mms_aReportDay_T7
					set ReportValue =@run6
				where ReportDate =@A_Date and R_Rows =34 and R_Cols =5	
				update mms_aReportDay_T7
					set ReportValue =@run7
				where ReportDate =@A_Date and R_Rows =35 and R_Cols =5	
				update mms_aReportDay_T7
					set ReportValue =@run8
				where ReportDate =@A_Date and R_Rows =36 and R_Cols =5	
				update mms_aReportDay_T7
					set ReportValue =@run9
				where ReportDate =@A_Date and R_Rows =37 and R_Cols =5	
	------------------------------对该日期以后的影响-----------------------------------------														
				exec proc_aReportDay_AccAfectLogic @A_Date						
			end	
	end

if(@st =0)
	begin
		delete from mms_aReportDay_T4_Acc where R_Date =@A_Date 
		delete from mms_aReportDay_T5_Acc where R_Date =@A_Date 
		delete from mms_aReportDay_T6_Acc where R_Date =@A_Date 					
		delete from mms_aReportDay_T7 where ReportDate =@A_Date and R_Cols =5 and R_Rows between 1 and 37

	end

go

