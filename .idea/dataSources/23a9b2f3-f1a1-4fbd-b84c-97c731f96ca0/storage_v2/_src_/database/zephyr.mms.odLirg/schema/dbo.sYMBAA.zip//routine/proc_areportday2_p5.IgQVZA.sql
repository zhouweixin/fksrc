CREATE procedure [dbo].[proc_aReportDay2_P5]
@D_Date date =null,
@M_Mode int =0 -----------操作模式，1插入、2更新、3删除
as

declare @sn_XN_1 DECIMAL(18,4) =0
declare @sn_XN_2 DECIMAL(18,4) =0
declare @sn_XN_3 DECIMAL(18,4) =0
declare @sn_XN_4 DECIMAL(18,4) =0
declare @sn_ZX_1 DECIMAL(18,4) =0
declare @sn_ZX_2 DECIMAL(18,4) =0
declare @sn_ZX_3 DECIMAL(18,4) =0
declare @sn_ZX_4 DECIMAL(18,4) =0
declare @yk_sn DECIMAL(18,4) =0
declare @temp_t1 int =0

select @sn_XN_1=SUM(Sn_XN_1), @sn_XN_3=sum(Sn_XN_3), @sn_ZX_1=sum(Sn_ZX_1), @sn_ZX_3=sum(Sn_ZX_3) 
	from mms_aReportDay2_T2 where R_Date =@D_Date 
if(@sn_XN_1=0)
	set @sn_XN_2=0
else
	set @sn_XN_2 =100*@sn_XN_3/@sn_XN_1

if(@sn_ZX_1=0)
	set @sn_ZX_2=0
else
	set @sn_ZX_2 =100*@sn_ZX_3/@sn_ZX_1

set @temp_t1 =(select COUNT(*) from mms_aReportDay2_T1 where R_Date =@D_Date )
if (@temp_t1 <3)
	begin
		set @sn_XN_4 =0
		set @sn_ZX_4 =0
	end
else 
	begin
		select @yk_sn =SUM(yk_9) from mms_aReportDay2_T1 where R_Date =@D_Date
		set @sn_XN_4 =100*@sn_XN_3/nullif(@yk_sn,0)
		set @sn_ZX_4 =100*@sn_ZX_3/nullif(@yk_sn,0)
	end
declare @temp_t5 int =0
set @temp_t5=(select COUNT(*) from mms_aReportDay2_T5 where R_Date =@D_Date)

if(@M_Mode =1)
	begin
		if(@temp_t5=0)	
		begin
			insert into mms_aReportDay2_T5 
				values (@D_Date ,@sn_XN_1 ,@sn_XN_2 ,@sn_XN_3 ,@sn_XN_4 ,
									@sn_ZX_1 ,@sn_ZX_2 ,@sn_ZX_3 ,@sn_ZX_4 )
			insert into mms_aReportDay2_T7 
				values (@D_Date,21,4,@sn_XN_1),
						(@D_Date,22,4,@sn_XN_2),
						(@D_Date,23,4,@sn_XN_3),
						(@D_Date,24,4,@sn_XN_4),
						(@D_Date,25,4,@sn_ZX_1),
						(@D_Date,26,4,@sn_ZX_2),
						(@D_Date,27,4,@sn_ZX_3),
						(@D_Date,28,4,@sn_ZX_4)
		end 
		else 
			begin
				update mms_aReportDay2_T5 
				set Sn_XN_1 =@sn_XN_1 ,
					Sn_XN_2 =@sn_XN_2 ,
					Sn_XN_3 =@sn_XN_3 ,
					Sn_XN_4 =@sn_XN_4 ,
					Sn_ZX_1 =@sn_ZX_1 ,	
					Sn_ZX_2 =@sn_ZX_2 ,	
					Sn_ZX_3 =@sn_ZX_3 ,	
					Sn_ZX_4 =@sn_ZX_4 	
				where R_Date =@D_Date 
				
				update mms_aReportDay2_T7 
					set ReportValue =@sn_XN_1			
				where ReportDate =@D_Date and R_Rows =21 and R_Cols =4
				update mms_aReportDay2_T7 
					set ReportValue =@sn_XN_2			
				where ReportDate =@D_Date and R_Rows =22 and R_Cols =4	
				update mms_aReportDay2_T7 
					set ReportValue =@sn_XN_3			
				where ReportDate =@D_Date and R_Rows =23 and R_Cols =4	
				update mms_aReportDay2_T7 
					set ReportValue =@sn_XN_4			
				where ReportDate =@D_Date and R_Rows =24 and R_Cols =4	
				update mms_aReportDay2_T7 
					set ReportValue =@sn_ZX_1			
				where ReportDate =@D_Date and R_Rows =25 and R_Cols =4	
				update mms_aReportDay2_T7 
					set ReportValue =@sn_ZX_2			
				where ReportDate =@D_Date and R_Rows =26 and R_Cols =4	
				update mms_aReportDay2_T7 
					set ReportValue =@sn_ZX_3			
				where ReportDate =@D_Date and R_Rows =27 and R_Cols =4	
				update mms_aReportDay2_T7 
					set ReportValue =@sn_ZX_4			
				where ReportDate =@D_Date and R_Rows =28 and R_Cols =4		
			end

	end						
if(@M_Mode =2)
	begin
		update mms_aReportDay2_T5 
			set Sn_XN_1 =@sn_XN_1 ,
				Sn_XN_2 =@sn_XN_2 ,
				Sn_XN_3 =@sn_XN_3 ,
				Sn_XN_4 =@sn_XN_4 ,
				Sn_ZX_1 =@sn_ZX_1 ,	
				Sn_ZX_2 =@sn_ZX_2 ,	
				Sn_ZX_3 =@sn_ZX_3 ,	
				Sn_ZX_4 =@sn_ZX_4 	
		where R_Date =@D_Date 
		
		update mms_aReportDay2_T7 
			set ReportValue =@sn_XN_1			
		where ReportDate =@D_Date and R_Rows =21 and R_Cols =4
		update mms_aReportDay2_T7 
			set ReportValue =@sn_XN_2			
		where ReportDate =@D_Date and R_Rows =22 and R_Cols =4	
		update mms_aReportDay2_T7 
			set ReportValue =@sn_XN_3			
		where ReportDate =@D_Date and R_Rows =23 and R_Cols =4	
		update mms_aReportDay2_T7 
			set ReportValue =@sn_XN_4			
		where ReportDate =@D_Date and R_Rows =24 and R_Cols =4	
		update mms_aReportDay2_T7 
			set ReportValue =@sn_ZX_1			
		where ReportDate =@D_Date and R_Rows =25 and R_Cols =4	
		update mms_aReportDay2_T7 
			set ReportValue =@sn_ZX_2			
		where ReportDate =@D_Date and R_Rows =26 and R_Cols =4	
		update mms_aReportDay2_T7 
			set ReportValue =@sn_ZX_3			
		where ReportDate =@D_Date and R_Rows =27 and R_Cols =4	
		update mms_aReportDay2_T7 
			set ReportValue =@sn_ZX_4			
		where ReportDate =@D_Date and R_Rows =28 and R_Cols =4		
		
	end
	
if(@M_Mode =3)
	begin
		delete from mms_aReportDay2_T5  where R_Date =@D_Date 
		delete from mms_aReportDay2_T7  where ReportDate =@D_Date and R_Cols =4 and R_Rows between 21 and 28
	end
go

