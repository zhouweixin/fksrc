CREATE VIEW dbo.View_1
AS
SELECT     a.ID, a.date, a.c1, a.c2, a.c3, a.c4, a.c5, a.c6, a.c7, a.c8, a.c9, b.ID AS Expr1, b.date AS Expr2, b.c1 AS Expr3, b.c2 AS Expr4, b.pw1, b.pw2, b.pw3, b.pw4, b.pw5, b.pw6, b.pw7, b.pw8, b.pw9, b.pw10, 
                      b.pw11, b.pw12, b.pw13, b.pw14, b.pw15, (b.pw10 - b.pw13) * (b.pw2 - b.pw14) - (b.pw1 - b.pw13) * (b.pw11 - b.pw14) AS JKCL_Pb_1, (b.pw5 - b.pw14) * (b.pw10 - b.pw13) - (b.pw4 - b.pw13) 
                      * (b.pw11 - b.pw14) + 0.000001 AS JKCL_Pb_2, a.c7 * (1 - a.c3 / 100) AS Yk_ZL, (b.pw1 - b.pw13) * (b.pw5 - b.pw14) - (b.pw2 - b.pw14) * (b.pw4 - b.pw13) AS JKCL_Zn_1, (b.pw5 - b.pw14) 
                      * (b.pw10 - b.pw13) - (b.pw4 - b.pw13) * (b.pw11 - b.pw14) + 0.000001 AS JKCL_Zn_2
FROM         dbo.mms_classquota AS a INNER JOIN
                      dbo.mms_pwquota AS b ON a.date = b.date AND a.c1 = b.c1
go

