------------------T4表上的三类触发器-------------------------------
CREATE trigger [dbo].[Trig_insert] on [dbo].[mms_afmPDWeight]
for insert
as
declare @R_DateTime datetime =null
declare @R_ValueID nvarchar(50) =''
select @R_DateTime =A_datetime,@R_ValueID =ValueID from inserted   
exec proc_PDWeight_Report @R_ValueID,@R_DateTime
go

