
CREATE procedure [dbo].[proc_aReportJKSell]
@A_Date date =null
as
delete from mms_aReportSell_T7 where ReportDate =@A_Date
delete from mms_aReportJKBalance_T7 where ReportDate =@A_Date

declare @Pb_mass1 decimal(18,4) =0
declare @Pb_mass2 decimal(18,4) =0
declare @Pb_pb decimal(18,4) =0
declare @Pb_sb decimal(18,4) =0
declare @Pb_ag decimal(18,4) =0
declare @Pb_pb_m decimal(18,4) =0
declare @Pb_sb_m decimal(18,4) =0
declare @Pb_ag_m decimal(18,4) =0

declare @Zn_mass1 decimal(18,4) =0
declare @Zn_mass2 decimal(18,4) =0
declare @Zn_zn decimal(18,4) =0
declare @Zn_zn_m decimal(18,4) =0

declare @Sn_mass1 decimal(18,4) =0
declare @Sn_mass2 decimal(18,4) =0
declare @Sn_sn decimal(18,4) =0
declare @Sn_sn_m decimal(18,4) =0

declare @zh_sn decimal(18,4) =0

declare @JK_S decimal(18,4) =0
----------------------------------------当月---------------------------------------------------------------
select @Pb_mass1 =SUM(pb_mass1), @Pb_mass2 =SUM(pb_mass2),
		@Pb_pb_m =SUM(Metal_Pb_Pb),@Pb_sb_m =SUM(Metal_pb_Sb),@Pb_ag_m =SUM(Metal_pb_ag),
		@Zn_mass1 =SUM(zn_mass1),@Zn_mass2=SUM(zn_mass2),@Zn_zn_m=SUM(Metal_zn),
		@Sn_mass1 =SUM(sn_mass1),@Sn_mass2=SUM(sn_mass2),@Sn_sn_m=SUM(Metal_sn)
from mms_afmMonthSell where convert(varchar(7),SellMonth,120)=convert(varchar(7),@A_Date,120) 
--SellMonth <=@A_Date and MONTH(SellMonth)=MONTH(@A_Date)
if(@Pb_mass2=0)
	begin
		set @Pb_pb =0
		set @Pb_sb =0
		set @Pb_ag =0
	end
else
	begin
		set @Pb_pb =100*@Pb_pb_m/@Pb_mass2
		set @Pb_sb =100*@Pb_sb_m/@Pb_mass2
		set @Pb_ag =1000*@Pb_ag_m/@Pb_mass2
	end
	
if(@Zn_mass2 =0)
	set @Zn_zn =0
else 
	set @Zn_zn =100*@Zn_zn_m/@Zn_mass2
	
if(@Sn_mass2=0)
	set @Sn_sn =0
else
	set @Sn_sn =100*@Sn_sn_m/@Sn_mass2
	
set @zh_sn= @Sn_sn_m +(@Pb_pb_m + @Pb_sb_m + @Zn_zn_m)/8

select @JK_S=SUM(g1w3) from mms_afmSSellWeightList 
	where convert(varchar(7),wl_date,120)=convert(varchar(7),@A_Date,120) 
	--wl_date <= @A_Date and MONTH(wl_date)=MONTH(@A_Date)
begin--#region--mms_aTypicalProductSell--
exec proc_CreateJKSellTypical @A_Date
update mms_aTypicalProductSell set Q3=@Pb_mass1
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0101'
update mms_aTypicalProductSell set Q3=@Pb_mass2
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0102'	
update mms_aTypicalProductSell set Q3=@Pb_pb
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0103'	
update mms_aTypicalProductSell set Q3=@Pb_sb
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0104'	
update mms_aTypicalProductSell set Q3=@Pb_ag
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0105'	
update mms_aTypicalProductSell set Q3=@Pb_pb_m
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0106'	
update mms_aTypicalProductSell set Q3=@Pb_sb_m
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0107'
update mms_aTypicalProductSell set Q3=@Pb_ag_m
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0108'
update mms_aTypicalProductSell set Q3=@Zn_mass1
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0101'
update mms_aTypicalProductSell set Q3=@Zn_mass2
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0102'	
update mms_aTypicalProductSell set Q3=@Zn_zn
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0103'	
update mms_aTypicalProductSell set Q3=@Zn_zn_m
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0104'						
update mms_aTypicalProductSell set Q3=@Sn_mass1
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0101'
update mms_aTypicalProductSell set Q3=@Sn_mass2
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0102'	
update mms_aTypicalProductSell set Q3=@Sn_sn
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0103'	
update mms_aTypicalProductSell set Q3=@Sn_sn_m
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0104'		
update mms_aTypicalProductSell set Q3=@JK_S
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0401'	
update mms_aTypicalProductSell set Q3=@zh_sn
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0501'
end---#region--mms_aTypicalProductSell----			
--insert into mms_aReportSell_T7 
--	values(@A_Date ,1,3,@Pb_mass1),
--	(@A_Date ,2,3,@Pb_mass2),
--	(@A_Date ,3,3,@Pb_pb),
--	(@A_Date ,4,3,@Pb_sb),
--	(@A_Date ,5,3,@Pb_ag),
--	(@A_Date ,6,3,@Pb_pb_m),
--	(@A_Date ,7,3,@Pb_sb_m),
--	(@A_Date ,8,3,@Pb_ag_m),
--	(@A_Date ,9,3,@Zn_mass1),
--	(@A_Date ,10,3,@Zn_mass2),
--	(@A_Date ,11,3,@Zn_zn),
--	(@A_Date ,12,3,@Zn_zn_m),
--	(@A_Date ,13,3,@Sn_mass1),
--	(@A_Date ,14,3,@Sn_mass2),
--	(@A_Date ,15,3,@Sn_sn),
--	(@A_Date ,16,3,@Sn_sn_m),
--	(@A_Date ,17,3,@JK_S),
--	(@A_Date ,18,3,@zh_sn)
begin---精矿平衡报表内容1---
--------------当月累计产量
declare @CapacityJK_Pb decimal(18,4) =0
declare @CapacityJK_Zn decimal(18,4) =0
declare @CapacityJK_Sn decimal(18,4) =0
declare @CapacityJK_S decimal(18,4) =0
declare @ZXSn1 decimal(18,4) =0
declare @XNsn1 decimal(18,4) =0

declare @StartDateTime datetime
if(day(@A_Date)<=25)
	select @StartDateTime = CONVERT(varchar(10), CONVERT(varchar(8),dateadd(month,-1,@A_Date),23)+'26' , 120)
if(day(@A_Date)>25)
	select @StartDateTime = convert(varchar(8),@A_Date,21)+'26'
	
select @CapacityJK_Pb=SUM(mm.PbSb_1),@CapacityJK_Zn=SUM(mm.Zn_1) 
	from 
	(select * from mms_aReportDay_T4 
	union 
	select * from mms_aReportDay2_T4 ) mm
	where mm.R_Date <=@A_Date and mm.R_Date >=@StartDateTime

select @ZXSn1=SUM(mm.Sn_ZX_1),@XNsn1=SUM(mm.Sn_XN_1) 
	from 
	(select * from mms_aReportDay_T5 
	union 
	select * from mms_aReportDay2_T5 ) mm
	where mm.R_Date <=@A_Date and mm.R_Date >=@StartDateTime
set @CapacityJK_Sn= @ZXSn1+@XNsn1 	

insert into mms_aReportJKBalance_T7 
		values(@A_Date,1,2,@CapacityJK_Pb),
		(@A_Date,2,2,@CapacityJK_Zn),
		(@A_Date,3,2,@CapacityJK_Sn),
		(@A_Date,4,2,0),
		(@A_Date,5,2,0),
		(@A_Date,6,2,@JK_S)	
		
insert into mms_aReportJKBalance_T7 
		values(@A_Date,1,4,@Pb_mass2),
		(@A_Date,2,4,@Zn_mass2),
		(@A_Date,3,4,@Sn_mass2),
		(@A_Date,4,4,0),
		(@A_Date,5,4,0),
		(@A_Date,6,4,@JK_S)	
end--精矿平衡报表内容---
set @Pb_mass1 =0
set @Pb_mass2 =0
set @Pb_pb =0
set @Pb_sb =0
set @Pb_ag =0
set @Pb_pb_m =0
set @Pb_sb_m =0
set @Pb_ag_m =0

set @Zn_mass1 =0
set @Zn_mass2 =0
set @Zn_zn =0
set @Zn_zn_m =0

set @Sn_mass1 =0
set @Sn_mass2 =0
set @Sn_sn =0
set @Sn_sn_m =0

set @zh_sn =0

set @JK_S =0		
----------------------------------当月年累计------------------------------------------------------
select @Pb_mass1 =SUM(pb_mass1), @Pb_mass2 =SUM(pb_mass2),
		@Pb_pb_m =SUM(Metal_Pb_Pb),@Pb_sb_m =SUM(Metal_pb_Sb),@Pb_ag_m =SUM(Metal_pb_ag),
		@Zn_mass1 =SUM(zn_mass1),@Zn_mass2=SUM(zn_mass2),@Zn_zn_m=SUM(Metal_zn),
		@Sn_mass1 =SUM(sn_mass1),@Sn_mass2=SUM(sn_mass2),@Sn_sn_m=SUM(Metal_sn)
from mms_afmMonthSell where month(SellMonth) <=month(@A_Date) and year(SellMonth)=year(@A_Date)
--convert(varchar(4),SellMonth,120)=convert(varchar(4),@A_Date,120)
--
if(@Pb_mass2=0)
	begin
		set @Pb_pb =0
		set @Pb_sb =0
		set @Pb_ag =0
	end
else
	begin
		set @Pb_pb =100*@Pb_pb_m/@Pb_mass2
		set @Pb_sb =100*@Pb_sb_m/@Pb_mass2
		set @Pb_ag =1000*@Pb_ag_m/@Pb_mass2
	end
	
if(@Zn_mass2 =0)
	set @Zn_zn =0
else 
	set @Zn_zn =100*@Zn_zn_m/@Zn_mass2
	
if(@Sn_mass2=0)
	set @Sn_sn =0
else
	set @Sn_sn =100*@Sn_sn_m/@Sn_mass2
	
set @zh_sn= @Sn_sn_m +(@Pb_pb_m + @Pb_sb_m + @Zn_zn_m)/8

select @JK_S=SUM(g1w3) from mms_afmSSellWeightList 
	where MONTH(wl_date)<=MONTH(@A_Date) and year(wl_date)<=year(@A_Date)
	--convert(varchar(4),wl_date,120)=convert(varchar(4),@A_Date,120)
--wl_date <= @A_Date and MONTH(wl_date)=MONTH(@A_Date)
begin--#region--mms_aTypicalProductSell--
exec proc_CreateJKSellTypical @A_Date
update mms_aTypicalProductSell set Q4=@Pb_mass1
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0101'
update mms_aTypicalProductSell set Q4=@Pb_mass2
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0102'	
update mms_aTypicalProductSell set Q4=@Pb_pb
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0103'	
update mms_aTypicalProductSell set Q4=@Pb_sb
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0104'	
update mms_aTypicalProductSell set Q4=@Pb_ag
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0105'	
update mms_aTypicalProductSell set Q4=@Pb_pb_m
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0106'	
update mms_aTypicalProductSell set Q4=@Pb_sb_m
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0107'
update mms_aTypicalProductSell set Q4=@Pb_ag_m
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0108'
update mms_aTypicalProductSell set Q4=@Zn_mass1
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0101'
update mms_aTypicalProductSell set Q4=@Zn_mass2
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0102'	
update mms_aTypicalProductSell set Q4=@Zn_zn
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0103'	
update mms_aTypicalProductSell set Q4=@Zn_zn_m
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0104'						
update mms_aTypicalProductSell set Q4=@Sn_mass1
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0101'
update mms_aTypicalProductSell set Q4=@Sn_mass2
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0102'	
update mms_aTypicalProductSell set Q4=@Sn_sn
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0103'	
update mms_aTypicalProductSell set Q4=@Sn_sn_m
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0104'		
update mms_aTypicalProductSell set Q4=@JK_S
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0401'	
update mms_aTypicalProductSell set Q4=@zh_sn
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0501'
end---#region--mms_aTypicalProductSell----		
--insert into mms_aReportSell_T7 
--	values(@A_Date ,1,4,@Pb_mass1),
--	(@A_Date ,2,4,@Pb_mass2),
--	(@A_Date ,3,4,@Pb_pb),
--	(@A_Date ,4,4,@Pb_sb),
--	(@A_Date ,5,4,@Pb_ag),
--	(@A_Date ,6,4,@Pb_pb_m),
--	(@A_Date ,7,4,@Pb_sb_m),
--	(@A_Date ,8,4,@Pb_ag_m),
--	(@A_Date ,9,4,@Zn_mass1),
--	(@A_Date ,10,4,@Zn_mass2),
--	(@A_Date ,11,4,@Zn_zn),
--	(@A_Date ,12,4,@Zn_zn_m),
--	(@A_Date ,13,4,@Sn_mass1),
--	(@A_Date ,14,4,@Sn_mass2),
--	(@A_Date ,15,4,@Sn_sn),
--	(@A_Date ,16,4,@Sn_sn_m),
--	(@A_Date ,17,4,@JK_S),
--	(@A_Date ,18,4,@zh_sn)

begin--精矿平衡报表内容2---
--------------年初库存	
declare @begin_Pb_mass decimal(18,4) =0
declare @begin_Zn_mass decimal(18,4) =0
declare @begin_Sn_mass decimal(18,4) =0
declare @begin_S_mass decimal(18,4) =0
select @begin_Pb_mass=pb_mass,@begin_Sn_mass=sn_mass ,
	 @begin_Zn_mass=zn_mass ,@begin_S_mass=s_mass 
	from mms_afmBeginningMassJk where b_year =YEAR(@A_Date)
--------------月累计产量
select @CapacityJK_Pb=SUM(mm.PbSb_1),@CapacityJK_Zn=SUM(mm.Zn_1) 
	from 
	(select * from mms_aReportDay_T4 
	union 
	select * from mms_aReportDay2_T4 ) mm
	where mm.R_Date <=@A_Date and year(mm.R_Date)=year(@A_Date)

select @ZXSn1=SUM(mm.Sn_ZX_1),@XNsn1=SUM(mm.Sn_XN_1) 
	from 
	(select * from mms_aReportDay_T5
	union 
	select * from mms_aReportDay2_T5 ) mm
	where mm.R_Date <=@A_Date and year(mm.R_Date)=year(@A_Date)
set @CapacityJK_Sn= @ZXSn1+@XNsn1 
--------------------月末库存
declare @EndMonth_Pb decimal(18,4) =0
declare @EndMonth_Zn decimal(18,4) =0
declare @EndMonth_Sn decimal(18,4) =0
declare @EndMonth_S decimal(18,4) =0

set @EndMonth_Pb =@begin_Pb_mass + @CapacityJK_Pb -@Pb_mass2
set @EndMonth_Zn =@begin_Zn_mass + @CapacityJK_Zn -@Zn_mass2
set @EndMonth_Sn =@begin_Sn_mass + @CapacityJK_Sn -@Sn_mass2
set @EndMonth_S=0

insert into mms_aReportJKBalance_T7 
		values(@A_Date,1,1,@begin_Pb_mass),
		(@A_Date,2,1,@begin_Zn_mass),
		(@A_Date,3,1,@begin_Sn_mass),
		(@A_Date,4,1,0),
		(@A_Date,5,1,0),
		(@A_Date,6,1,@begin_S_mass)
insert into mms_aReportJKBalance_T7 
		values(@A_Date,1,3,@CapacityJK_Pb),
		(@A_Date,2,3,@CapacityJK_Zn),
		(@A_Date,3,3,@CapacityJK_Sn),
		(@A_Date,4,3,0),
		(@A_Date,5,3,0),
		(@A_Date,6,3,@JK_S)		

insert into mms_aReportJKBalance_T7 
		values(@A_Date,1,5,@Pb_mass2),
		(@A_Date,2,5,@Zn_mass2),
		(@A_Date,3,5,@Sn_mass2),
		(@A_Date,4,5,0),
		(@A_Date,5,5,0),
		(@A_Date,6,5,@JK_S)	

insert into mms_aReportJKBalance_T7 
		values(@A_Date,1,6,@EndMonth_Pb),
		(@A_Date,2,6,@EndMonth_Zn),
		(@A_Date,3,6,@EndMonth_Sn),
		(@A_Date,4,6,0),
		(@A_Date,5,6,0),
		(@A_Date,6,6,@EndMonth_S)	
end--精矿平衡报表内容2---
----------------------------------------去年、当月---------------------------------------------------------------
set @Pb_mass1 =0
set @Pb_mass2 =0
set @Pb_pb =0
set @Pb_sb =0
set @Pb_ag =0
set @Pb_pb_m =0
set @Pb_sb_m =0
set @Pb_ag_m =0

set @Zn_mass1 =0
set @Zn_mass2 =0
set @Zn_zn =0
set @Zn_zn_m =0

set @Sn_mass1 =0
set @Sn_mass2 =0
set @Sn_sn =0
set @Sn_sn_m =0

set @zh_sn =0

set @JK_S =0
select @Pb_mass1 =SUM(pb_mass1), @Pb_mass2 =SUM(pb_mass2),
		@Pb_pb_m =SUM(Metal_Pb_Pb),@Pb_sb_m =SUM(Metal_pb_Sb),@Pb_ag_m =SUM(Metal_pb_ag),
		@Zn_mass1 =SUM(zn_mass1),@Zn_mass2=SUM(zn_mass2),@Zn_zn_m=SUM(Metal_zn),
		@Sn_mass1 =SUM(sn_mass1),@Zn_mass2=SUM(zn_mass2),@Sn_sn_m=SUM(Metal_zn)
from mms_afmMonthSell 
	where convert(varchar(7),SellMonth,120)=convert(varchar(7),dateadd(year,-1,@A_Date),120)
-- year(SellMonth)=year(@A_Date)-1 and MONTH(SellMonth)=MONTH(@A_Date)
if(@Pb_mass2=0)
	begin
		set @Pb_pb =0
		set @Pb_sb =0
		set @Pb_ag =0
	end
else
	begin
		set @Pb_pb =100*@Pb_pb_m/@Pb_mass2
		set @Pb_sb =100*@Pb_sb_m/@Pb_mass2
		set @Pb_ag =1000*@Pb_ag_m/@Pb_mass2
	end
	
if(@Zn_mass2 =0)
	set @Zn_zn =0
else 
	set @Zn_zn =100*@Zn_zn_m/@Zn_mass2
	
if(@Sn_mass2=0)
	set @Sn_sn =0
else
	set @Sn_sn =100*@Sn_sn_m/@Zn_mass2
	
set @zh_sn= @Sn_sn_m +(@Pb_pb_m + @Pb_sb_m + @Zn_zn_m)/8

select @JK_S=SUM(g1w3) from mms_afmSSellWeightList 
	where convert(varchar(7),wl_date,120)=convert(varchar(7),dateadd(year,-1,@A_Date),120)
	--wl_date <= @A_Date and MONTH(wl_date)=MONTH(@A_Date)
begin--#region--mms_aTypicalProductSell--
update mms_aTypicalProductSell set Q1=@Pb_mass1
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0101'
update mms_aTypicalProductSell set Q1=@Pb_mass2
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0102'	
update mms_aTypicalProductSell set Q1=@Pb_pb
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0103'	
update mms_aTypicalProductSell set Q1=@Pb_sb
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0104'	
update mms_aTypicalProductSell set Q1=@Pb_ag
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0105'	
update mms_aTypicalProductSell set Q1=@Pb_pb_m
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0106'	
update mms_aTypicalProductSell set Q1=@Pb_sb_m
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0107'
update mms_aTypicalProductSell set Q1=@Pb_ag_m
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0108'
update mms_aTypicalProductSell set Q1=@Zn_mass1
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0101'
update mms_aTypicalProductSell set Q1=@Zn_mass2
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0102'	
update mms_aTypicalProductSell set Q1=@Zn_zn
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0103'	
update mms_aTypicalProductSell set Q1=@Zn_zn_m
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0104'						
update mms_aTypicalProductSell set Q1=@Sn_mass1
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0101'
update mms_aTypicalProductSell set Q1=@Sn_mass2
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0102'	
update mms_aTypicalProductSell set Q1=@Sn_sn
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0103'	
update mms_aTypicalProductSell set Q1=@Sn_sn_m
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0104'		
update mms_aTypicalProductSell set Q1=@JK_S
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0401'	
update mms_aTypicalProductSell set Q1=@zh_sn
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0501'
end---#region--mms_aTypicalProductSell----		
--insert into mms_aReportSell_T7 
--	values(@A_Date ,1,1,@Pb_mass1),
--	(@A_Date ,2,1,@Pb_mass2),
--	(@A_Date ,3,1,@Pb_pb),
--	(@A_Date ,4,1,@Pb_sb),
--	(@A_Date ,5,1,@Pb_ag),
--	(@A_Date ,6,1,@Pb_pb_m),
--	(@A_Date ,7,1,@Pb_sb_m),
--	(@A_Date ,8,1,@Pb_ag_m),
--	(@A_Date ,9,1,@Zn_mass1),
--	(@A_Date ,10,1,@Zn_mass2),
--	(@A_Date ,11,1,@Zn_zn),
--	(@A_Date ,12,1,@Zn_zn_m),
--	(@A_Date ,13,1,@Sn_mass1),
--	(@A_Date ,14,1,@Sn_mass2),
--	(@A_Date ,15,1,@Sn_sn),
--	(@A_Date ,16,1,@Sn_sn_m),
--	(@A_Date ,17,1,@JK_S),
--	(@A_Date ,18,1,@zh_sn)
----------------------------------去年、当月年累计------------------------------------------------------
set @Pb_mass1 =0
set @Pb_mass2 =0
set @Pb_pb =0
set @Pb_sb =0
set @Pb_ag =0
set @Pb_pb_m =0
set @Pb_sb_m =0
set @Pb_ag_m =0

set @Zn_mass1 =0
set @Zn_mass2 =0
set @Zn_zn =0
set @Zn_zn_m =0

set @Sn_mass1 =0
set @Sn_mass2 =0
set @Sn_sn =0
set @Sn_sn_m =0

set @zh_sn =0

set @JK_S =0
select @Pb_mass1 =SUM(pb_mass1), @Pb_mass2 =SUM(pb_mass2),
		@Pb_pb_m =SUM(Metal_Pb_Pb),@Pb_sb_m =SUM(Metal_pb_Sb),@Pb_ag_m =SUM(Metal_pb_ag),
		@Zn_mass1 =SUM(zn_mass1),@Zn_mass2=SUM(zn_mass2),@Zn_zn_m=SUM(Metal_zn),
		@Sn_mass1 =SUM(sn_mass1),@Zn_mass2=SUM(zn_mass2),@Sn_sn_m=SUM(Metal_zn)
from mms_afmMonthSell where  YEAR(SellMonth)=convert(varchar(4),dateadd(year,-1,@A_Date),120)
and MONTH(SellMonth)<=MONTH(@A_Date)
--year(SellMonth)=year(@A_Date)-1 and MONTH(SellMonth)<=MONTH(@A_Date)
if(@Pb_mass2=0)
	begin
		set @Pb_pb =0
		set @Pb_sb =0
		set @Pb_ag =0
	end
else
	begin
		set @Pb_pb =100*@Pb_pb_m/@Pb_mass2
		set @Pb_sb =100*@Pb_sb_m/@Pb_mass2
		set @Pb_ag =1000*@Pb_ag_m/@Pb_mass2
	end
	
if(@Zn_mass2 =0)
	set @Zn_zn =0
else 
	set @Zn_zn =100*@Zn_zn_m/@Zn_mass2
	
if(@Sn_mass2=0)
	set @Sn_sn =0
else
	set @Sn_sn =100*@Sn_sn_m/@Zn_mass2
	
set @zh_sn= @Sn_sn_m +(@Pb_pb_m + @Pb_sb_m + @Zn_zn_m)/8

select @JK_S=SUM(g1w3) from mms_afmSSellWeightList where YEAR(wl_date)=convert(varchar(4),dateadd(year,-1,@A_Date),120)
and MONTH(wl_date)<=MONTH(@A_Date)
--wl_date <= @A_Date and MONTH(wl_date)=MONTH(@A_Date)


begin--#region--mms_aTypicalProductSell--
update mms_aTypicalProductSell set Q2=@Pb_mass1
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0101'
update mms_aTypicalProductSell set Q2=@Pb_mass2
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0102'	
update mms_aTypicalProductSell set Q2=@Pb_pb
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0103'	
update mms_aTypicalProductSell set Q2=@Pb_sb
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0104'	
update mms_aTypicalProductSell set Q2=@Pb_ag
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0105'	
update mms_aTypicalProductSell set Q2=@Pb_pb_m
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0106'	
update mms_aTypicalProductSell set Q2=@Pb_sb_m
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0107'
update mms_aTypicalProductSell set Q2=@Pb_ag_m
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0108'
update mms_aTypicalProductSell set Q2=@Zn_mass1
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0101'
update mms_aTypicalProductSell set Q2=@Zn_mass2
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0102'	
update mms_aTypicalProductSell set Q2=@Zn_zn
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0103'	
update mms_aTypicalProductSell set Q2=@Zn_zn_m
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0104'						
update mms_aTypicalProductSell set Q2=@Sn_mass1
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0101'
update mms_aTypicalProductSell set Q2=@Sn_mass2
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0102'	
update mms_aTypicalProductSell set Q2=@Sn_sn
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0103'	
update mms_aTypicalProductSell set Q2=@Sn_sn_m
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0104'		
update mms_aTypicalProductSell set Q2=@JK_S
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0401'	
update mms_aTypicalProductSell set Q2=@zh_sn
	where MonthChar=convert(varchar(7),@A_Date,120) and OrderCode='0501'
end---#region--mms_aTypicalProductSell----		
--insert into mms_aReportSell_T7 
--	values(@A_Date ,1,2,@Pb_mass1),
--	(@A_Date ,2,2,@Pb_mass2),
--	(@A_Date ,3,2,@Pb_pb),
--	(@A_Date ,4,2,@Pb_sb),
--	(@A_Date ,5,2,@Pb_ag),
--	(@A_Date ,6,2,@Pb_pb_m),
--	(@A_Date ,7,2,@Pb_sb_m),
--	(@A_Date ,8,2,@Pb_ag_m),
--	(@A_Date ,9,2,@Zn_mass1),
--	(@A_Date ,10,2,@Zn_mass2),
--	(@A_Date ,11,2,@Zn_zn),
--	(@A_Date ,12,2,@Zn_zn_m),
--	(@A_Date ,13,2,@Sn_mass1),
--	(@A_Date ,14,2,@Sn_mass2),
--	(@A_Date ,15,2,@Sn_sn),
--	(@A_Date ,16,2,@Sn_sn_m),
--	(@A_Date ,17,2,@JK_S),
--	(@A_Date ,18,2,@zh_sn)
go

